%% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)
% ============================================================================================================

%% Add LRC vs Add Layers (Figure 2g)
disp('=================================================================')
disp('Result1_2 : Add LRC vs Add Layers')
disp('=================================================================')
%% Set parameter 
output_cell_num_mod = numClass_mod;

MaxEpoch = 2000;
MiniBatchSize = 1000;
Valid_f = numTrain_mod/MiniBatchSize;
array_penalty_lambda = [0];
layer_str = {'FF_Layer_Conv','FF_Layer2_Conv'};

ind_img = 3;

array_addlayer_accu_trial = zeros(N_trial,length(layer_str),MaxEpoch+1);

%% Generate model & Train networks
disp('Generate model & Train networks...');
for nn = 1:N_trial
    disp(['%% Trial : ',num2str(nn)]);
    
    ori_weight_w0 = (randn(hidden_cell_num, input_cell_num) * 0.05);
    ori_weight_wh = (randn(hidden_cell_num, hidden_cell_num) * 1);
    ori_weight_w1 = (randn(output_cell_num_mod, hidden_cell_num) * 0.05);
    
    connection_w0_layer = fun_generate_conn_conv_rewireLRC_SRC_LSp(input_cell_num,hidden_cell_num,output_cell_num_mod,...
        convergence_range,3,V1_dim,...
        0,threshold_lrc,...
        p_total_conn,1);
    
    connection_w0_2_layer = fun_generate_conn_conv_rewireLRC_SRC_LSp(input_cell_num,hidden_cell_num,output_cell_num_mod,...
        convergence_range,3,V1_dim,...
        0,threshold_lrc,...
        p_total_conn,1);
    
    for cc = 1:length(layer_str)
        disp(['addlayer type : ',layer_str{cc}]);
        switch cc
            case 1
                connection_w0 = connection_w0_ori;
                connection_w01 = connection_w0_layer;
                MAT_conn = {connection_w0,connection_w01,connection_w1,0};
                save('connectivity.mat','MAT_conn');
                
                layers = [...
                    imageInputLayer([x_dim y_dim 1],'Normalization','none') % Normalization -> zerocenter
                    
                    fullyConnectedLayer(hidden_cell_num)
                    reluLayer
                    fullyConnectedLayer(hidden_cell_num)
                    reluLayer
                    
                    fullyConnectedLayer(output_cell_num_mod)
                    softmaxLayer
                    classificationLayer];
                
                layers(2).Weights = (ori_weight_w0).*connection_w0;
                layers(4).Weights = (ori_weight_w0).*connection_w01;
                layers(6).Weights = (ori_weight_w1).*connection_w1;
                
                opts = trainingOptions2('sgdm_conv4',...
                    'MaxEpochs',MaxEpoch,'MiniBatchSize',MiniBatchSize,'Shuffle','every-epoch',...
                    'ValidationData',{IMAGE_mod{ind_img,2},LABEL_mod{ind_img,2}},'ValidationFrequency',Valid_f,'ValidationPatience',Inf,... % early stopping
                    'InitialLearnRate',0.1,...
                    'L2Regularization',array_penalty_lambda(1),'Momentum',0,...
                    'ExecutionEnvironment',enVirn,...
                    'Verbose',false);
                
            case 2
                connection_w0 = connection_w0_ori;
                connection_w01 = connection_w0_layer;
                connection_w02 = connection_w0_2_layer;
                MAT_conn = {connection_w0,connection_w01,connection_w02,connection_w1,0};
                save('connectivity.mat','MAT_conn');
                
                layers = [...
                    imageInputLayer([x_dim y_dim 1],'Normalization','none') % Normalization -> zerocenter
                    
                    fullyConnectedLayer(hidden_cell_num)
                    reluLayer
                    fullyConnectedLayer(hidden_cell_num)
                    reluLayer
                    fullyConnectedLayer(hidden_cell_num)
                    reluLayer
                    
                    fullyConnectedLayer(output_cell_num_mod)
                    softmaxLayer
                    classificationLayer];
                
                layers(2).Weights = (ori_weight_w0).*connection_w0;
                layers(4).Weights = (ori_weight_w0).*connection_w01;
                layers(6).Weights = (ori_weight_w0).*connection_w02;
                layers(8).Weights = (ori_weight_w1).*connection_w1;
                
                opts = trainingOptions2('sgdm_conv5',...
                    'MaxEpochs',MaxEpoch,'MiniBatchSize',MiniBatchSize,'Shuffle','every-epoch',...
                    'ValidationData',{IMAGE_mod{ind_img,2},LABEL_mod{ind_img,2}},'ValidationFrequency',Valid_f,'ValidationPatience',Inf,... % early stopping
                    'InitialLearnRate',0.1,...
                    'L2Regularization',array_penalty_lambda(1),'Momentum',0,...
                    'ExecutionEnvironment',enVirn,...
                    'Verbose',false);
        end
        
        
        
        [net, tr] = trainNetwork2(IMAGE_mod{ind_img,1},LABEL_mod{ind_img,1},layers,opts);
        
        ind = [1 opts.ValidationFrequency:opts.ValidationFrequency:Valid_f*MaxEpoch];
        array_va_iter = tr.ValidationAccuracy; array_va_epoch = array_va_iter(ind);
        
        array_addlayer_accu_trial(nn,cc,:) = array_va_epoch;
        disp(['Accuracy : ',num2str(array_va_epoch(end))]);
        
    end
end

%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Classification accuracy of networks'; 'with various types of hierachical structures (Figure 2g)'},'FontSize',fontSize_title) 
hold on
plot(0:MaxEpoch,squeeze(array_addconn_accu_trial(1,1,1,:)),'k','linewidth',3)
plot(0:MaxEpoch,squeeze(array_addconn_accu_trial(1,2,find(array_conn_num == 1e+4),:)),'r','linewidth',3)
plot(0:MaxEpoch,squeeze(array_addlayer_accu_trial(1,1,:)),'b','linewidth',3);
plot(0:MaxEpoch,squeeze(array_addlayer_accu_trial(1,2,:)),'color',[0 0.9 0.9],'linewidth',3);
xlim([0 MaxEpoch]); xticks([0:500:MaxEpoch]); ylim([10 90]) 
xlabel('Training epoch','FontSize',fontSize_label)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)
legend('3layer','3layer + LRC','4layer','5layer','FontSize',fontSize_legend,'Location','southeast')
