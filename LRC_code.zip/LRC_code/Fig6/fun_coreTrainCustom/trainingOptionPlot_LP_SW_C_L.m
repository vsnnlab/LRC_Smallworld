function [lineAccuracyTrain,lineLossTrain,...
    lineAccuracyValidation,lineLossValidation,...
    lineTotalLengthSum,lineLRCratio,...
    lineSW1,lineL1,lineC1,...
    lineSW2,lineL2,lineC2,lineSW3,lineSW4] = trainingOptionPlot_LP_SW_C_L(flag_valid)

figure; set(gcf,'units','normalized','outerposition',[0 0 1 1])
subplot(2,5,1)
lineAccuracyTrain = animatedline('Color',[1 0.7 0.7],'LineWidth',0.5);
xlim([0 inf]);ylim([0 inf])
ylabel("Accuracy (%)")

subplot(2,5,6)
lineLossTrain = animatedline('Color',[0.7 0.7 1],'LineWidth',0.5);
xlabel("Iteration")
ylabel("Loss")
xlim([0 inf]);ylim([0 inf])

if flag_valid
    subplot(2,5,1)
    lineAccuracyValidation = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    
    subplot(2,5,6)
    lineLossValidation = animatedline('Color',[0 0 1],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[0 0 1]);
    
    subplot(2,5,2)
    lineLRCratio = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 1])
    ylabel("LRC ratio")
    
    subplot(2,5,7)
    lineTotalLengthSum = animatedline('Color',[0 0 1],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[0 0 1]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("Length")
    
    subplot(2,5,3)
    lineSW1 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("SW1")
    
    subplot(2,5,8)
    colororder({'r','b'})
    yyaxis left 
    lineL1 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("L/L_r_a_n_d")
    yyaxis right 
    lineC1 = animatedline('Color',[0 0 1],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[0 0 1]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("C/C_r_a_n_d")
    
    subplot(2,5,4)
    lineSW2 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("SW2")
    
    subplot(2,5,9)
    colororder({'r','b'})
    yyaxis left 
    lineL2 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 1])
    ylabel("L_r_e_g")
    yyaxis right 
    lineC2 = animatedline('Color',[0 0 1],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[0 0 1]);
    xlim([0 inf]);ylim([0 1])
    ylabel("C_r_e_g")
    
    subplot(2,5,5)
    lineSW3 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("SW3")
    
    subplot(2,5,10)
    lineSW4 = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    xlim([0 inf]);ylim([0 inf])
    ylabel("SW4")
    
end

end