function [checkpointPath] = trainingOptionSaveTrainingNet(checkfolderName,dirRes)
    checkpointPath = fullfile(dirRes,checkfolderName);
    if ~exist(checkpointPath,"dir"); mkdir(checkpointPath); end
end