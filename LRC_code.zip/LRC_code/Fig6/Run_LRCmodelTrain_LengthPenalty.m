clc; clear; close all;
addpath('Run_BioParam'); load('V1size_dim32.mat')
addpath('fun_coreConn'); addpath('fun_coreTrainCustom'); 
addpath('fun_stimulus\MNIST');


switch_learning = 1;
nameIMG = 'MNIST_LocGlo';
dirRes = ['Res_',nameIMG]; 
versions = 'v220511_v1';
switch_save = 1; if switch_save == 1; if ~exist(dirRes,'dir'); mkdir(dirRes); end; end
switch_figure_IMG = 1;
if switch_save == 1
    dirFoldName = [dirRes,'\Result','_dataType','_',versions]; 
    if ~exist(dirFoldName,'dir'); mkdir(dirFoldName); end
end

%% Image parameter
dirIMG = 'fun_stimulus\MNIST';

img_dim = 32; % full width or height of a image
reimg_dim = 5; % width or height of small mnist
noise_Back_Amp = 0.00; % Background noise
noise_Digit_cen_p = 0.0; % Pixel noise at center object
noise_Digit_sur_p = 0.0; % Pixel noise at surround object
noise_Pos = 0; % Positional noise
dist_digit = [9]; % distance from center to dot center

x_pos_cen = round((img_dim-reimg_dim)/2); x_pos = x_pos_cen+floor(reimg_dim/2);
y_pos_cen = round((img_dim-reimg_dim)/2); y_pos = y_pos_cen+floor(reimg_dim/2);
dot_size_sur = 3.0;
max_Amp_sur = 0.8;

idx_Loc = [0,1,7,9];

Type_img = 3;
Type_label = Type_img; % 1: local, 2: global, 3: loc & glob
STR_IMG = {'Shape', 'Position', 'Both'};

%% Image generation
num_Train = 10000;
switch Type_img
    case 1
        [IMAGE,LABEL] = fun_LocF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
    case 2
        [IMAGE,LABEL] = fun_GloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
    case 3
         [IMAGE,~,~,LABEL_lg] = fun_LocGloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
end

if Type_img == 3
    switch Type_label % 1: local, 2: global, 3: loc & glob
        case 1
            XTrain = IMAGE{1,1}; YTrain = LABEL_l{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_l{1,2};
        case 2
            XTrain = IMAGE{1,1}; YTrain = LABEL_g{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_g{1,2};
        case 3
            XTrain = IMAGE{1,1}; YTrain = LABEL_lg{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_lg{1,2};
    end
else
    XTrain = IMAGE{1,1}; YTrain = LABEL{1,1};
    XValid = IMAGE{1,2}; YValid = LABEL{1,2};
end

classes = categories(YTrain); numClasses = numel(classes);

if switch_figure_IMG == 1
    %visualizing
    figure('units','normalized','outerposition',[0 0 1 1]); sgtitle(STR_IMG{Type_label});
    for c = 1:numClasses
        ind = find(double(YTrain) == c); ind = ind(randperm(length(ind),length(ind)));
        for i = 1:8
            %         iStep = iStep+1;
            subplot(8,numClasses,numClasses*(i-1)+c)
            imagesc(1-XTrain(:,:,:,ind(i))); axis image off; colormap(gray);
        end
    end
end

%% Parameter
% training
numEpochs = 500;
learnRate = 0.1;

% minibatch
miniBatchSize = 256*2;
numObservations = numel(YTrain);
numIterationsPerEpoch = floor(numObservations./miniBatchSize);

% validation
validationFrequency = numIterationsPerEpoch;
validationData = {XValid, YValid};
dlXValid = dlarray(single(XValid),'SSCB');
YValid_re = zeros(numClasses, length(YValid), 'single');
for c = 1:numClasses; YValid_re(c,YValid==classes(c)) = 1; end

% trainingOption
regularization = "l2_len";
executionEnvironment = "gpu";
saveTrainingNet = "yes";
plots = "training-progress";

if (executionEnvironment == "auto" && canUseGPU) || executionEnvironment == "gpu"; dlXValid = gpuArray(dlXValid);end

%% Network parameter
Xsize = img_dim; Ysize = img_dim;  % size of image
input_cell_num = Xsize*Ysize;    % # of neuron on the input layer
output_cell_num = numClasses;    % # of neuron on the output layer
convergence_range = 2; convergence_range_RO = 2;
array_phid = [3]; % The number of input to hid connection; very sparse phid=3 -> p_FF=0.07
pout = 0.9999;
weight_init = 0.05; weight_thr = 0.01;
TT_iter = 1;
threshold_lrc = 10; threshold_local = 9;
p_lateral = 1; %

array_V1 = [32]; % 13,17,21,25,29,32
V1_min_width = 12; % 13-1
len_V1_min = 15;
C_balance = len_V1_min/weight_init;

%% Generate connectivity
NN = 20;
array_lambda = [0.5];

for nn = 1:NN
    tic
    disp(['%%% Trial : ',num2str(nn)]); rng(nn);
    dirFoldTrial = [dirFoldName,'\Weight_N',num2str(nn)]; mkdir(dirFoldTrial);

    for vv = 1:length(array_V1)
        disp(['%% V1 : ',num2str(array_V1(vv))])

        outXsize = array_V1(vv); outYsize = outXsize;
        hidden_cell_num = outXsize*outYsize;   % # of neuron on the hidden layer

        init_w0 = randn(input_cell_num,hidden_cell_num).*weight_init;
        init_wlrc = randn(hidden_cell_num,hidden_cell_num).*weight_init;
        init_w1 = randn(hidden_cell_num,hidden_cell_num).*weight_init;
        MAT_ConnW = {init_w0;init_wlrc;init_w1};

        % FF connections
        num_hid = array_phid(1)*array_V1(vv)^2;
        [connection_FF_origin,connection_FF,connection_RO_origin,connection_RO,connection_RO2] = fun_generate_V1size_divergence_sparse_ConvRO_sel3(input_cell_num,hidden_cell_num,output_cell_num,x_pos,y_pos,...
            convergence_range,convergence_range_RO,num_hid,pout);
        MAT_ConnFF{1} = connection_FF; MAT_ConnFF{2} = connection_RO; MAT_ConnFF{3} = connection_RO2;

        % Lateral connections
        temp_connection_lrc = ones(hidden_cell_num,hidden_cell_num);
        length_matrix = fun_cal_len_LRC(temp_connection_lrc,0);
        connection_LRC_len_tmp = length_matrix; connection_LRC_len_tmp(connection_LRC_len_tmp>len_V1_min) = 0;
        x=[1:V1_min_width*sqrt(2)]; 
%         connection_LRC_p = poisspdf(connection_LRC_len_tmp,mean(x)); 
        connection_LRC_p = normpdf(connection_LRC_len_tmp,mean(x),3); 
        connection_LRC_p = connection_LRC_p.*(connection_LRC_len_tmp>0);
        connection_LRC_p = connection_LRC_p./max(max(connection_LRC_p));

        connection_LRC = rand(size(connection_LRC_p))<connection_LRC_p; length(find(connection_LRC))
        connection_LRC_len = fun_cal_len_LRC(connection_LRC,0);

        %         connection_LRC_len = length_matrix;

        if nn == 1
            edge = [1:1:ceil(array_V1(end)*sqrt(2))];
            array_hist_count = histcounts(connection_LRC_len(connection_LRC_len>0),edge, 'Normalization', 'count');
            array_hist_count_ori = histcounts(length_matrix(length_matrix>0),edge, 'Normalization', 'count');
            figure; hold on; set(gca,'TickDir','out'); set(gca, 'YScale', 'log');
            e = bar(edge(1:end-1)-0.5,array_hist_count_ori,1); e.EdgeColor = 'none'; e.FaceColor = 'k'; e.FaceAlpha = 0.3;
            e = bar(edge(1:end-1)-0.5,array_hist_count,1); e.EdgeColor = 'none'; e.FaceColor = 'r'; e.FaceAlpha = 0.3;
            line([len_V1_min len_V1_min],[1e1 1e5])
            xlim([0 45]); ylim([1e1 1e5]);
            title(['V1 size :',num2str(array_V1(vv))])
        end


        connection_LRC_len = connection_LRC_len./C_balance;

        MAT_BackBone{1} = connection_FF; MAT_BackBone{2} = connection_LRC; MAT_BackBone{3} = connection_RO; MAT_BackBone{4} = connection_RO2;

        x_range = [1:ceil(array_V1(vv)*sqrt(2))]; x_range_lrc = [threshold_lrc:ceil(array_V1(vv)*sqrt(2))]; x_range_local = [1:threshold_local]; 

        for ll = 1:length(array_lambda)
            disp(['%% Lambda : ',num2str(array_lambda(ll))])
            l2Regularization = array_lambda(ll);

            %% Training setting
            if saveTrainingNet == "yes"
                checkfolderName = ['V1_',num2str(array_V1(vv)),'_Lambda_',num2str(l2Regularization)];
                [checkpointPath] = trainingOptionSaveTrainingNet(checkfolderName,dirFoldTrial);
            end

            if (nn <= 3) && (plots == "training-progress")
                if regularization == "l2_len"
                    [lineAccuracyTrain,lineLossTrain,...
                        lineAccuracyValidation,lineLossValidation,...
                        lineTotalLengthSum,lineLRCratio,...
                        lineSW1,lineL1,lineC1,...
                        lineSW2,lineL2,lineC2,lineSW3,lineSW4] = trainingOptionPlot_LP_SW_C_L(~isempty(validationData));
                else
                    [lineAccuracyTrain,lineLossTrain,...
                        lineAccuracyValidation,lineLossValidation] = trainingOptionPlot(~isempty(validationData));
                end
                title(['Lambda ',num2str(l2Regularization),' V1 size ',num2str(array_V1(vv))])
            end

            %% Network training
            MAT_valid_accu = zeros(numEpochs+1,1);
            MAT_valid_loss = zeros(numEpochs+1,1);
            MAT_numConn = zeros(numEpochs+1,3);
            MAT_sumLength = zeros(numEpochs+1,1);
            MAT_BackBone = cell(4,1);
            MAT_Coeff_L = zeros(numEpochs+1,3); % lattice / real / random network
            MAT_Coeff_C = zeros(numEpochs+1,3); % lattice / real / random network
            MAT_Coeff_SW = zeros(numEpochs+1,4);

            if switch_learning == 1
                L = fun_setLayers(Ysize,Xsize,outYsize,outXsize,numClasses,TT_iter,MAT_ConnW,MAT_ConnFF,connection_LRC);
                lgraph = layerGraph(L); dlnet = dlnetwork(lgraph); dlnet_init = dlnet;

                array_valid_accu = zeros(numEpochs+1,1);
                array_valid_loss = zeros(numEpochs+1,1);
                array_numConn = zeros(numEpochs+1,3);
                array_sumLength = zeros(numEpochs+1,1);
                array_Coeff_L = zeros(numEpochs+1,3);
                array_Coeff_C = zeros(numEpochs+1,3);
                array_Coeff_SW = zeros(numEpochs+1,4);

                iteration = 0;
                start = tic;

                for epoch = 0:numEpochs
                    
                    %% 0) Measure valid accuracy & loss before training
                    if epoch == 0
                        if ~isempty(validationData) && (mod(iteration,validationFrequency) == 0)
                            % accuracy
                            dlYPred = predict(dlnet,dlXValid);[~,idx_ans] = max(extractdata(dlYPred),[],1);
                            YPred = classes(idx_ans); accu_valid = mean(YPred==YValid)*100;
                            array_valid_accu(1) = accu_valid;
                            
                            % loss
                            loss_valid = crossentropy(dlYPred,YValid_re);
                            array_valid_loss(1) = loss_valid;
                            
                            % (Optional) Display length progress.
                            temp_lateral = fun_cal_len_LRC(dlnet.Layers(3).Weights,weight_thr); temp_lateral_mat = temp_lateral;
                            array_sumLength(1) = sum(sum(temp_lateral_mat,1),2);
                            array_numConn(1,1) = length(find((temp_lateral>=x_range_lrc(1))&(temp_lateral<x_range_lrc(end))));
                            array_numConn(1,2) = length(find((temp_lateral>=x_range_local(1))&(temp_lateral<x_range_local(end))));
                            array_numConn(1,3) = length(find((temp_lateral>=x_range(1))&(temp_lateral<x_range(end))));
                            
                            % connectivity ================================
                            tmpLAT = fun_cal_len_LRC(ones(array_V1(vv)^2,array_V1(vv)^2),0); 
                            indTotal = find(tmpLAT); [orderLen,orderLenIND] = sort(tmpLAT(indTotal)); 
                            
                            orderLen_unq = unique(orderLen);
                            orederLenIND_Tot = [];
                            for l = 1:length(orderLen_unq)
                                tmp_idx = find(orderLen == orderLen_unq(l));
                                tmp_idx = tmp_idx(randperm(length(tmp_idx)));
                                orederLenIND_Tot = [orederLenIND_Tot; orderLenIND(tmp_idx)];
                            end
                            
                            % raw network
                            wlrc = double(logical(fun_cal_len_LRC(dlnet.Layers(3).Weights,weight_thr)));
                            wlrc = double(logical(wlrc-eye(size(wlrc,1))>0));
                            
                            % regular network
                            wlrc_reg = zeros(size(wlrc));
                            wlrc_reg(indTotal(orederLenIND_Tot(1:length(find(wlrc))))) = 1;
                            wlrc_reg = double(logical(wlrc_reg-eye(size(wlrc_reg,1))>0));
                            
                            tmpD = distance_bin(wlrc_reg); tmpD(isinf(tmpD)) = 0; tmp_inf_dist = max(max(tmpD));

                            % random network
                            wlrc_rand = zeros(size(wlrc));
                            wlrc_rand(indTotal(randperm(length(indTotal),min(length(indTotal),length(find(wlrc)))))) = 1;
                            wlrc_rand = double(logical(wlrc_rand-eye(size(wlrc_rand,1))>0));

                            array_Coeff_C(1,1) = mean(clustering_coef_bd(wlrc_reg'));
                            tmpD = distance_bin(wlrc_reg'); tmpD(isinf(distance_bin(wlrc_reg'))) = tmp_inf_dist;
                            array_Coeff_L(1,1) = charpath(tmpD,0,0);
                            
                            array_Coeff_C(1,2) = mean(clustering_coef_bd(wlrc'));
                            tmpD = distance_bin(wlrc'); tmpD(isinf(distance_bin(wlrc'))) = tmp_inf_dist;
                            array_Coeff_L(1,2) = charpath(tmpD,0,0);
                            
                            array_Coeff_C(1,3) = mean(clustering_coef_bd(wlrc_rand'));
                            tmpD = distance_bin(wlrc_rand'); tmpD(isinf(distance_bin(wlrc_rand'))) = tmp_inf_dist;
                            array_Coeff_L(1,3) = charpath(tmpD,0,0);
                            
                            array_Coeff_SW(1,1) = (array_Coeff_C(1,2)/array_Coeff_C(1,3))./(array_Coeff_L(1,2)/array_Coeff_L(1,3));
                            array_Coeff_SW(1,2) = (array_Coeff_C(1,2)/array_Coeff_C(1,1))./(array_Coeff_L(1,2)/array_Coeff_L(1,1));
                            array_Coeff_SW(1,3) = ((array_Coeff_C(1,2)-array_Coeff_C(1,3))./(array_Coeff_C(1,1)-array_Coeff_C(1,3)))...
                                .*((array_Coeff_L(1,2)-array_Coeff_L(1,1))./(array_Coeff_L(1,3)-array_Coeff_L(1,1)));

                            dC = squeeze((array_Coeff_C(1,1)-array_Coeff_C(1,2))./(array_Coeff_C(1,1)-array_Coeff_C(1,3)));
                            dL = squeeze((array_Coeff_L(1,2)-array_Coeff_L(1,3))./(array_Coeff_L(1,1)-array_Coeff_L(1,3)));
                            array_Coeff_SW(1,4) = 1-sqrt((dC.^2+dL.^2)./2);
                            % =============================================
                        end
                        
                        % (Optional) Display the training progress.
                        if (nn <= 3) && (plots == "training-progress")
                            D = duration(0,0,toc(start),'Format','hh:mm:ss');
                            % accuracy
                            if ~isempty(validationData) && (mod(iteration,validationFrequency) == 0)
                                subplot(2,5,1); hold on
                                addpoints(lineAccuracyValidation,iteration,accu_valid); drawnow
                            end
                            % loss
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,6); hold on
                                addpoints(lineLossValidation,iteration,double(gather(extractdata(loss_valid)))); drawnow
                            end
                            % LRC ratio
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,2); hold on
                                addpoints(lineLRCratio,iteration,sum(array_numConn(1,1),2)./sum(array_numConn(1,3),2)); drawnow
                            end
                            % length
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,7); hold on
                                addpoints(lineTotalLengthSum,iteration,array_sumLength(1)); drawnow
                            end
                            % SW1
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,3); hold on
                                addpoints(lineSW1,iteration,array_Coeff_SW(1,1)); drawnow
                            end
                            % L,C1
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,8); hold on
                                addpoints(lineL1,iteration,array_Coeff_L(1,2)./array_Coeff_L(1,3)); drawnow
                                addpoints(lineC1,iteration,array_Coeff_C(1,2)./array_Coeff_C(1,3)); drawnow
                            end
                            % SW2
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,4); hold on
                                addpoints(lineSW2,iteration,array_Coeff_SW(1,2)); drawnow
                            end
                            % L,C2
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,9); hold on
                                addpoints(lineL2,iteration,array_Coeff_L(1,2)./array_Coeff_L(1,1)); drawnow
                                addpoints(lineC2,iteration,array_Coeff_C(1,2)./array_Coeff_C(1,1)); drawnow
                            end
                            % SW3
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,5); hold on
                                addpoints(lineSW3,iteration,array_Coeff_SW(1,3)); drawnow
                            end
                            % SW4
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,10); hold on
                                addpoints(lineSW4,iteration,array_Coeff_SW(1,4)); drawnow
                            end
                            
                            sgtitle("Epoch: " + (epoch) + ", Elapsed: " + string(D)); drawnow
                        end
                        continue;
                    end
                    %% ==========================================================
                    % (Optional) Shuffle data.
                    idx = randperm(numel(YTrain));
                    XTrain = XTrain(:,:,:,idx);
                    YTrain = YTrain(idx);
                    
                    for i = 1:numIterationsPerEpoch
                        iteration = iteration + 1;
                        
                        %% 1) Read mini-batch of data and convert the labels to dummy variables.
                        idx_mini = (i-1)*miniBatchSize+1:i*miniBatchSize; X = XTrain(:,:,:,idx_mini);
                        Y = zeros(numClasses, miniBatchSize, 'single');
                        for c = 1:numClasses; Y(c,YTrain(idx_mini)==classes(c)) = 1; end
                        
                        % Convert mini-batch of data to dlarray.
                        dlX = dlarray(single(X),'SSCB');
                        % If training on a GPU, then convert data to a gpuArray.
                        if (executionEnvironment == "auto" && canUseGPU) || executionEnvironment == "gpu"
                            dlX = gpuArray(dlX);
                        end
                        %% ==========================================================
                        
                        %% 2) Evaluate the model gradients and loss
                        [gradients,loss] = dlfeval(@modelGradients,dlnet,dlX,Y);
                        switch regularization
                            case "l2norm"
                                idx_layer = (dlnet.Learnables.Parameter == "Weights");
                                gradients(idx_layer,:) = dlupdate(@(g,w) g + l2Regularization.*w, gradients(idx_layer,:), dlnet.Learnables(idx_layer,:));
                            case "l2_len"
                                idx_layer = (dlnet.Learnables.Parameter == "Weights") & (dlnet.Learnables.Layer == "Llat");
                                gradients(idx_layer,:) = dlupdate(@(g,w) (1-l2Regularization)*g + l2Regularization*w.*(connection_LRC_len'), gradients(idx_layer,:), dlnet.Learnables(idx_layer,:));
                            otherwise
                        end
                        
                        idx_fc2 = find(dlnet.Connections.Source == "fc2");
                        idx_layer = (dlnet.Learnables.Layer == "fc2") & (dlnet.Learnables.Parameter == "Weights");
                        if dlnet.Layers(idx_fc2).WeightLearnRateFactor == 0
                            gradients(idx_layer,3) = {dlarray(zeros(size(gradients(idx_layer,:).Value{1})))};
                        end
                        
                        idx_layer = (dlnet.Learnables.Layer == "fc2") & (dlnet.Learnables.Parameter == "Bias");
                        if dlnet.Layers(idx_fc2).BiasLearnRateFactor == 0
                            gradients(idx_layer,3) = {dlarray(zeros(size(gradients(idx_layer,:).Value{1})))};
                        end
                        %% ==========================================================
                        
                        %% 3) Update gradient
                        updateFcn = @(dlnet,gradients) sgdFunction(dlnet,gradients,learnRate);
                        dlnet = dlupdate(updateFcn,dlnet,gradients);
                        %% ==========================================================
                        
                        %% 4) Measure valid accuracy & loss
                        if ~isempty(validationData) && (mod(iteration,validationFrequency) == 0)
                            % accuracy
                            dlYPred = predict(dlnet,dlXValid);[~,idx_ans] = max(extractdata(dlYPred),[],1);
                            YPred = classes(idx_ans); accu_valid = mean(YPred==YValid)*100;
                            array_valid_accu(epoch+1) = accu_valid;
                            
                            % loss
                            loss_valid = crossentropy(dlYPred,YValid_re);
                            array_valid_loss(epoch+1) = loss_valid;
                            
                            % (Optional) Display length progress.
                            temp_lateral = fun_cal_len_LRC(dlnet.Layers(3).Weights,weight_thr); temp_lateral_mat = temp_lateral;
                            array_sumLength(epoch+1) = sum(sum(temp_lateral_mat,1),2);
                            array_numConn(epoch+1,1) = length(find((temp_lateral>=x_range_lrc(1))&(temp_lateral<x_range_lrc(end))));
                            array_numConn(epoch+1,2) = length(find((temp_lateral>=x_range_local(1))&(temp_lateral<x_range_local(end))));
                            array_numConn(epoch+1,3) = length(find((temp_lateral>=x_range(1))&(temp_lateral<x_range(end))));
                            
                            % connectivity ================================
                            tmpLAT = fun_cal_len_LRC(ones(array_V1(vv)^2,array_V1(vv)^2),0); 
                            indTotal = find(tmpLAT); [orderLen,orderLenIND] = sort(tmpLAT(indTotal)); 
                            
                            orderLen_unq = unique(orderLen);
                            orederLenIND_Tot = [];
                            for l = 1:length(orderLen_unq)
                                tmp_idx = find(orderLen == orderLen_unq(l));
                                tmp_idx = tmp_idx(randperm(length(tmp_idx)));
                                orederLenIND_Tot = [orederLenIND_Tot; orderLenIND(tmp_idx)];
                            end
                            
                            % raw network
                            wlrc = double(logical(fun_cal_len_LRC(dlnet.Layers(3).Weights,weight_thr)));
                            wlrc = double(logical(wlrc-eye(size(wlrc,1))>0));

                            % regular network
                            wlrc_reg = zeros(size(wlrc));
                            wlrc_reg(indTotal(orederLenIND_Tot(1:length(find(wlrc))))) = 1;
                            wlrc_reg = double(logical(wlrc_reg-eye(size(wlrc_reg,1))>0));

                            tmpD = distance_bin(wlrc_reg'); tmpD(isinf(tmpD)) = 0; tmp_inf_dist = max(max(tmpD));

                            % random network
                            wlrc_rand = zeros(size(wlrc));
                            wlrc_rand(indTotal(randperm(length(indTotal),min(length(indTotal),length(find(wlrc)))))) = 1;
                            wlrc_rand = double(logical(wlrc_rand-eye(size(wlrc_rand,1))>0));

                            array_Coeff_C(epoch+1,1) = mean(clustering_coef_bd(wlrc_reg'));
                            tmpD = distance_bin(wlrc_reg'); tmpD(isinf(distance_bin(wlrc_reg'))) = tmp_inf_dist;
                            array_Coeff_L(epoch+1,1) = charpath(tmpD,0,0);
                            
                            array_Coeff_C(epoch+1,2) = mean(clustering_coef_bd(wlrc'));
                            tmpD = distance_bin(wlrc'); tmpD(isinf(distance_bin(wlrc'))) = tmp_inf_dist;
                            array_Coeff_L(epoch+1,2) = charpath(tmpD,0,0);
                            
                            array_Coeff_C(epoch+1,3) = mean(clustering_coef_bd(wlrc_rand'));
                            tmpD = distance_bin(wlrc_rand'); tmpD(isinf(distance_bin(wlrc_rand'))) = tmp_inf_dist;
                            array_Coeff_L(epoch+1,3) = charpath(tmpD,0,0);
                            
                            array_Coeff_SW(epoch+1,1) = (array_Coeff_C(epoch+1,2)/array_Coeff_C(epoch+1,3))./(array_Coeff_L(epoch+1,2)/array_Coeff_L(epoch+1,3));
                            array_Coeff_SW(epoch+1,2) = (array_Coeff_C(epoch+1,2)/array_Coeff_C(epoch+1,1))./(array_Coeff_L(epoch+1,2)/array_Coeff_L(epoch+1,1));
                            array_Coeff_SW(epoch+1,3) = ((array_Coeff_C(epoch+1,2)-array_Coeff_C(epoch+1,3))./(array_Coeff_C(epoch+1,1)-array_Coeff_C(epoch+1,3)))...
                                .*((array_Coeff_L(epoch+1,2)-array_Coeff_L(epoch+1,1))./(array_Coeff_L(epoch+1,3)-array_Coeff_L(epoch+1,1)));
                            
                            dC = squeeze((array_Coeff_C(epoch+1,1)-array_Coeff_C(epoch+1,2))./(array_Coeff_C(epoch+1,1)-array_Coeff_C(epoch+1,3)));
                            dL = squeeze((array_Coeff_L(epoch+1,2)-array_Coeff_L(epoch+1,3))./(array_Coeff_L(epoch+1,1)-array_Coeff_L(epoch+1,3)));
                            array_Coeff_SW(epoch+1,4) = 1-sqrt((dC.^2+dL.^2)./2);
                            % =============================================
                        end
                        %% ==========================================================
                        
                        %% (Optional) Display the training progress.
                        if (nn <= 3) && (plots == "training-progress")
                            D = duration(0,0,toc(start),'Format','hh:mm:ss');
                            
                            % accuracy
                            dlYPred = predict(dlnet,dlX);[~,idx_ans] = max(extractdata(dlYPred),[],1);
                            YPred = classes(idx_ans); accu_train = mean(YPred==YTrain(idx_mini))*100;

                            % accuracy
                            subplot(2,5,1); hold on
                            addpoints(lineAccuracyTrain,iteration,accu_train); drawnow
                            if ~isempty(validationData) && (mod(iteration,validationFrequency) == 0)
                                subplot(2,5,1); hold on
                                addpoints(lineAccuracyValidation,iteration,accu_valid); drawnow
                            end
                            % loss
                            subplot(2,5,6); hold on
                            addpoints(lineLossTrain,iteration,double(gather(extractdata(loss)))); drawnow
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,6); hold on
                                addpoints(lineLossValidation,iteration,double(gather(extractdata(loss_valid)))); drawnow
                            end
                            % LRC ratio
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,2); hold on
                                addpoints(lineLRCratio,iteration,sum(array_numConn(epoch+1,1),2)./sum(array_numConn(epoch+1,3),2)); drawnow
                            end
                            % length
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,7); hold on
                                addpoints(lineTotalLengthSum,iteration,array_sumLength(epoch+1)); drawnow
                            end
                            % SW1
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,3); hold on
                                addpoints(lineSW1,iteration,array_Coeff_SW(epoch+1,1)); drawnow
                            end
                            % L,C1
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,8); hold on
                                addpoints(lineL1,iteration,array_Coeff_L(epoch+1,2)./array_Coeff_L(epoch+1,3)); drawnow
                                addpoints(lineC1,iteration,array_Coeff_C(epoch+1,2)./array_Coeff_C(epoch+1,3)); drawnow
                            end
                            % SW2
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,4); hold on
                                addpoints(lineSW2,iteration,array_Coeff_SW(epoch+1,2)); drawnow
                            end
                            % L,C2
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,9); hold on
                                addpoints(lineL2,iteration,array_Coeff_L(epoch+1,2)./array_Coeff_L(epoch+1,1)); drawnow
                                addpoints(lineC2,iteration,array_Coeff_C(epoch+1,2)./array_Coeff_C(epoch+1,1)); drawnow
                            end
                            % SW3
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,5); hold on
                                addpoints(lineSW3,iteration,array_Coeff_SW(epoch+1,3)); drawnow
                            end
                            % SW4
                            if ~isempty(validationData) && (iteration == 1 || mod(iteration,validationFrequency) == 0)
                                subplot(2,5,10); hold on
                                addpoints(lineSW4,iteration,array_Coeff_SW(epoch+1,4)); drawnow
                            end

                            sgtitle("Epoch: " + (epoch) + ", Elapsed: " + string(D)); drawnow
                        end
                        %% ==========================================================
                    end
                    %% (Optional) Save trained network every epoch.
                    if saveTrainingNet == "yes"
                        D = datestr(now,'yyyy_mm_dd__HH_MM_SS');
                        filename = "dlnet_checkpoint__" + iteration + "__" + D + ".mat";
                        save([char(dirFoldTrial),'\',char(checkfolderName),'\',char(filename)],'dlnet')
                    end
                    %% ==========================================================
                end
                MAT_valid_accu(:,1) = array_valid_accu;
                MAT_valid_loss(:,1) = array_valid_loss;
                MAT_sumLength(:,1) = array_sumLength;
                MAT_numConn(:,:) = array_numConn;
                MAT_Coeff_L(:,:) = array_Coeff_L;
                MAT_Coeff_C(:,:) = array_Coeff_C;
                MAT_Coeff_SW(:,:) = array_Coeff_SW;
            end
            save([dirFoldName,'\Result_V1_',num2str(array_V1(vv)),'_Lambda',num2str(l2Regularization),'_N',num2str(nn),'.mat'],'MAT_valid_accu','MAT_valid_loss','MAT_sumLength','MAT_numConn','MAT_BackBone','MAT_Coeff_L','MAT_Coeff_C','MAT_Coeff_SW','-v7.3')
        end
    end
    toc
end




% %%
% % weight = net.Layers(2).Weight;
% % amp_mat = zeros(4096,1);
% % lambda_mat = zeros(4096,1);
% % phase_mat = zeros(4096,1);
% % theta_mat = zeros(4096,1);
% % r2_mat = zeros(4096,1);
% % xi_size = 32;   yi_size = 32;
% % xo_size = 64;	yo_size = 64;
% %
% % for ii = 1:4096
% %
% %     weight_temp = double(reshape(weight(:,ii),[yi_size xi_size]));
% %
% %     abs_fft = abs(fftshift(fft2(weight_temp)));
% %     [~,max_ind] = max(abs_fft(:));
% %     [max_yy,max_xx] = ind2sub([yi_size xi_size], max_ind);
% %     exp_angle = angle(max_xx-(xi_size+1)/2 + 1i*(max_yy-(yi_size+1)/2));
% %
% %     [xx,yy] = meshgrid(1:xi_size,1:yi_size);
% %     [x_pos,y_pos] = meshgrid(linspace(1,xi_size,xo_size),linspace(1,yi_size,yo_size));
% %     xy_pos = x_pos + 1i*y_pos;
% %     xy_pos = xy_pos(:);
% %     xx = xx-real(xy_pos(ii));
% %     yy = yy-imag(xy_pos(ii));
% %
% %     [xData, yData, zData] = prepareSurfaceData( xx, yy, weight_temp );
% %
% %     % Set up fittype and options.
% %     ft = fittype( 'amp*exp(-((x*cos(theta) + y*sin(theta)).^2+(-x*sin(theta) + y*cos(theta)).^2)/2/2.5^2).*cos(2*pi*(x*cos(theta) + y*sin(theta))/lambda+phase)', 'independent', {'x', 'y'}, 'dependent', 'z' );
% %     opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
% %     opts.Display = 'Off';
% %     opts.Lower = [-1 0 0 -3.15];
% %     opts.StartPoint = [0.15 5 0.5 exp_angle];
% %     opts.Upper = [1 inf 6.3 3.15];
% %
% %     % Fit model to data.
% %     [fitresult, gof] = fit( [xData, yData], zData, ft, opts );
% %     amp_mat(ii) = fitresult.amp;
% %     lambda_mat(ii) = fitresult.lambda;
% %     phase_mat(ii) = fitresult.phase;
% %     theta_mat(ii) = fitresult.theta;
% %     r2_mat(ii) = gof.rsquare;
% % end
% % theta_mat(theta_mat<0) = theta_mat(theta_mat<0)+pi;
%
