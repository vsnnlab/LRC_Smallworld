%% Result 2 : Long-Range Connections Integrate Global Features (Figure 3)

%% Generate dataset
if ~exist('IMAGE_mod')
    tic
    disp('generating modified MNIST ...(~ 30 sec)')
    [IMAGE_mod,LABEL_mod] = fun_generate_mMNIST(numTrain_mod);
    toc
end

%% Show dataset
disp('Showing stimulus (Classs X Examples) ... (~ 5 sec)')
imagesPerClass = 5;
img_str = {'Shape','Position','Shape-Position'};
tic
for i = 1:3
    ind_img = i;
    img = IMAGE_mod{ind_img,1}; lab = LABEL_mod{ind_img,1};
    imagesInMontage = cell(imagesPerClass,numClass_mod);
    
    figure('units','normalized','outerposition',[0 0 0.5 1])
    for cc = 1:numClass_mod
        idx = find(double(lab) == cc);
        ind_pick = idx(randperm(length(idx),imagesPerClass));
        
        for ii = 1:imagesPerClass
            subplot(numClass_mod,imagesPerClass,ii+(cc-1)*imagesPerClass)
            imshow(1-img(:,:,1,ind_pick(ii)))
        end
    end
    sgtitle(['Modified MNIST - Type ',num2str(i),' : ',img_str{i}],'FontSize',15)
end
toc
% ============================================================================================================

%% Classification performance for each dataset with a variation of the LRC ratio (Figure 3c)
disp('=================================================================')
disp('Result2 : Accuracy for ''Shape'',''Position'',''Shape Position''')
disp('=================================================================')
%% Set parameter 
output_cell_num_mod = numClass_mod;

MaxEpoch = 2000;
MiniBatchSize = 1000;
Valid_f = numTrain_mod/MiniBatchSize;
array_penalty_lambda = [0];
img_str = {'Shape','Position','Shape-Position'};
ind_connRange = 2; 
ind_pdf = 2;

edge = [1:40];
array_p_lateral = [0 0.2 0.97];
array_rewiring_accu_trial = zeros(N_trial,length(img_str),length(array_p_lateral),MaxEpoch+1);

%% Generate model & Train networks
disp('Generate model & Train networks...');
for nn = 1:N_trial
    disp(['%% Trial : ',num2str(nn)]);
    
    ori_weight_w0 = (randn(hidden_cell_num, input_cell_num) * 0.05);
    ori_weight_wh = (randn(hidden_cell_num, hidden_cell_num) * 1);
    ori_weight_w1 = (randn(output_cell_num_mod, hidden_cell_num) * 0.05);
    
    [connection_w0_ori, ~, ...
        ~, ~,~,~,...
        connection_w1, ~] = fun_generate_conn_conv_rewireLRC_SRC_LSp(input_cell_num,hidden_cell_num,output_cell_num_mod,...
        convergence_range,3,V1_dim,...
        0,threshold_lrc,...
        p_total_conn,1);
    
    for cc = 1:length(img_str)
        disp(['Type ',num2str(cc),': ',img_str{cc}]);
        for ll = 1:length(array_p_lateral)
            disp(['p rewiring : ',num2str(array_p_lateral(ll))]);
            p_lateral = array_p_lateral(ll);
            [connection_w0,connection_lrc] = fun_delFF_rewireLRC(connection_w0_ori,length_matrix,...
                p_lateral,convergence_range,edge,ind_connRange,ind_pdf);
            
            MAT_conn = {connection_w0,connection_lrc,connection_w1,0};
            save('connectivity.mat','MAT_conn');
            
            layers = [...
                imageInputLayer([x_dim y_dim 1],'Normalization','none') % Normalization -> zerocenter
                
                fullyConnectedLayer(hidden_cell_num)
                
                fullyConnectedLayer(hidden_cell_num)
                reluLayer
                
                fullyConnectedLayer(output_cell_num_mod)
                softmaxLayer
                classificationLayer];
            layers(2).Weights = (ori_weight_w0).*connection_w0;
            layers(3).Weights = (ori_weight_wh).*(connection_lrc + diag(ones(1,hidden_cell_num)));
            layers(5).Weights = (ori_weight_w1).*connection_w1;
            
            opts = trainingOptions2('sgdm_conv3_LRC',...
                'MaxEpochs',MaxEpoch,'MiniBatchSize',MiniBatchSize,'Shuffle','every-epoch',...
                'ValidationData',{IMAGE_mod{cc,2},LABEL_mod{cc,2}},'ValidationFrequency',Valid_f,'ValidationPatience',Inf,... % early stopping
                'InitialLearnRate',0.1,...
                'L2Regularization',array_penalty_lambda(1),'Momentum',0,...
                'ExecutionEnvironment',enVirn,...
                'Verbose',false);
            
            [net, tr] = trainNetwork2(IMAGE_mod{cc,1},LABEL_mod{cc,1},layers,opts);
            ind = [1 opts.ValidationFrequency:opts.ValidationFrequency:Valid_f*MaxEpoch];
            array_va_iter = tr.ValidationAccuracy; array_va_epoch = array_va_iter(ind);
            array_rewiring_accu_trial(nn,cc,ll,:) = array_va_epoch;
            disp(['Accuracy : ',num2str(array_va_epoch(end))]);
        end
    end
end

%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
sgtitle({'Classification accuracy for each datasets';'with variation of LRC ratios (Figure 3c)'},'FontSize',fontSize_title) 
subplot(1,3,1)
hold on
bar([1],array_rewiring_accu_trial(1,1,1,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,1,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,1,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)

subplot(1,3,2)
hold on
bar([1],array_rewiring_accu_trial(1,1,2,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,2,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,2,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)

subplot(1,3,3)
hold on
bar([1],array_rewiring_accu_trial(1,1,3,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,3,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,3,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)

