function [IMAGE,LABEL] = fun_LocB_2(num_train,num_valid,num_test,ori_dim,redim,idx_Loc,pDigitNosie,max_Amp,pos_noise,dist2cen,dir)
                                    
XTrain = loadMNISTImages(strcat(dir,'\train-images-idx3-ubyte'));
idx_Train = 1:floor(size(XTrain,4)/2); idx_Valid = floor(size(XTrain,4)/2)+1:size(XTrain,4);
XValid = XTrain(:,:,:,idx_Valid); XTrain = XTrain(:,:,:,idx_Train);
XTest = loadMNISTImages(strcat(dir,'\t10k-images-idx3-ubyte'));

YTrain = loadMNISTLabels(strcat(dir,'\train-labels-idx1-ubyte'));
YValid = YTrain(idx_Valid); YTrain = YTrain(idx_Train);
YTest = loadMNISTLabels(strcat(dir,'\t10k-labels-idx1-ubyte'));

% normalized
XTrain = double(XTrain)./255 ;
XTest = double(XTest)./255;

%% parameter setting
x_dim = ori_dim;
y_dim = ori_dim;
num_Glo_type = 1; num_Loc_type = length(idx_Loc); 
num_LocGlo_type = num_Loc_type*num_Glo_type;

%% image matrix
train_imgs = zeros(x_dim,y_dim,1,num_train);
train_labels = zeros(num_train,1);

valid_imgs = zeros(x_dim,y_dim,1,num_valid);
valid_labels = zeros(num_valid,1);

test_imgs = zeros(x_dim,y_dim,1,num_test);
test_labels = zeros(num_test,1);

for ii = 1:num_train
    type_num = mod(ii-1,num_LocGlo_type)+1;
    type_Loc = mod(ii-1,num_Loc_type)+1;
    
    % Local
    tmpIdxLoc = find(YTrain == idx_Loc(type_Loc));
    tmpIMG_Loc = imresize(XTrain(:,:,1,tmpIdxLoc(randperm(length(tmpIdxLoc),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Loc<0); tmpIMG_Loc(neg_ind)=0;
    tmpIMG_Loc = reshape(tmpIMG_Loc,redim,redim)/max(max(tmpIMG_Loc));
    
    y_pos_Loc = round((y_dim-redim)/2); x_pos_Loc = round((x_dim-redim)/2);
    
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Loc+randi([-pos_noise pos_noise]); JJ = J+x_pos_Loc+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero(II,JJ) = tmpIMG_Loc(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie))); 
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
        
    train_imgs(:,:,:,ii) = tmp_zero;
    train_labels(ii) = type_num;
end

for ii = 1:num_valid
    type_num = mod(ii-1,num_LocGlo_type)+1;
    type_Loc = mod(ii-1,num_Loc_type)+1;
    
    % Local
    tmpIdxLoc = find(YValid == idx_Loc(type_Loc));
    tmpIMG_Loc = imresize(XValid(:,:,1,tmpIdxLoc(randperm(length(tmpIdxLoc),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Loc<0); tmpIMG_Loc(neg_ind)=0;
    tmpIMG_Loc = reshape(tmpIMG_Loc,redim,redim)/max(max(tmpIMG_Loc));
    
    y_pos_Loc = round((y_dim-redim)/2); x_pos_Loc = round((x_dim-redim)/2);
    
   
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Loc+randi([-pos_noise pos_noise]); JJ = J+x_pos_Loc+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero(II,JJ) = tmpIMG_Loc(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie))); 
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
        
    valid_imgs(:,:,:,ii) = tmp_zero;
    valid_labels(ii) = type_num;
end

for ii = 1:num_test
    type_num = mod(ii-1,num_LocGlo_type)+1;
    type_Loc = mod(ii-1,num_Loc_type)+1;
    
    % Local
    tmpIdxLoc = find(YTest == idx_Loc(type_Loc));
    tmpIMG_Loc = imresize(XTest(:,:,1,tmpIdxLoc(randperm(length(tmpIdxLoc),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Loc<0); tmpIMG_Loc(neg_ind)=0;
    tmpIMG_Loc = reshape(tmpIMG_Loc,redim,redim)/max(max(tmpIMG_Loc));
    
    y_pos_Loc = round((y_dim-redim)/2); x_pos_Loc = round((x_dim-redim)/2);
    
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Loc+randi([-pos_noise pos_noise]); JJ = J+x_pos_Loc+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero(II,JJ) = tmpIMG_Loc(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie))); 
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
        
    valid_imgs(:,:,:,ii) = tmp_zero;
    test_labels(ii) = type_num;
end

IMAGE = {train_imgs, valid_imgs, test_imgs};
LABEL = {categorical(train_labels), categorical(valid_labels), categorical(test_labels)};
    
end