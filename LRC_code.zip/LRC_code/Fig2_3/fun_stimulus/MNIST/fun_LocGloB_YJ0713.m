function [IMAGE,LABEL_l,LABEL_g,LABEL_lg] = fun_LocGloB_YJ0713(num_train,num_valid,num_test,ori_dim,redim,idx_Loc,pDigitNosie,max_Amp,pos_noise,dist2cen,dir)

% ver 210713
% This code generate 1 common image dataset, 3 different labels (local,global,loc_glb)
% num_Glo_type / num_Loc_type 은 반드시 coprime (공통약수가 1) 이어야 함!! (예: 4,5)
% 그렇지 않으면 특정 숫자가 항상 같은 위치에만 나오게 됨


XTrain = loadMNISTImages(strcat(dir,'\train-images-idx3-ubyte'));
idx_Train = 1:floor(size(XTrain,4)/2); idx_Valid = floor(size(XTrain,4)/2)+1:size(XTrain,4);
XValid = XTrain(:,:,:,idx_Valid); XTrain = XTrain(:,:,:,idx_Train);
XTest = loadMNISTImages(strcat(dir,'\t10k-images-idx3-ubyte'));

YTrain = loadMNISTLabels(strcat(dir,'\train-labels-idx1-ubyte'));
YValid = YTrain(idx_Valid); YTrain = YTrain(idx_Train);
YTest = loadMNISTLabels(strcat(dir,'\t10k-labels-idx1-ubyte'));

classes = categories(categorical(YTrain)); numClasses = numel(classes);

% normalized
XTrain = double(XTrain)./255 ;
XTest = double(XTest)./255;


%% parameter setting
x_dim = ori_dim;
y_dim = ori_dim;
num_Glo_type = 4; num_Loc_type = length(idx_Loc);
% if gcd(num_Glo_type,num_Loc_type)~=1
%     disp('warning: N_Glo_type and N_Loc type should be coprime ');
% end

num_LocGlo_type = num_Loc_type*num_Glo_type;

%% image matrix
train_imgs = zeros(x_dim,y_dim,1,num_train);
train_labels_g = zeros(num_train,1);
train_labels_l = zeros(num_train,1);
train_labels_lg = zeros(num_train,1);

valid_imgs = zeros(x_dim,y_dim,1,num_valid);
valid_labels_g = zeros(num_valid,1);
valid_labels_l = zeros(num_valid,1);
valid_labels_lg = zeros(num_valid,1);

test_imgs = zeros(x_dim,y_dim,1,num_test);
test_labels_g = zeros(num_test,1);
test_labels_l = zeros(num_test,1);
test_labels_lg = zeros(num_test,1);


%% training set
for ii = 1:num_train
    
    type_LG = mod(ii-1,num_LocGlo_type)+1;
    type_Glo = mod(ii-1,num_Glo_type)+1;
    
    if gcd(num_Glo_type,num_Loc_type)~=1 % num_Glo_type / num_Loc_type 가 coprime이 아닌 경우... LG에서 모든 경우의 수를 다 만들어야 함
        temp_idx = fix((type_LG-1)/num_Glo_type); % 1234->0, 5678->1, ...
        type_Loc = mod(mod(ii-1,num_Loc_type) +temp_idx , num_Loc_type)+1; % 1234 / 2341 / 3412 / 4123 ....
%         disp(type_Loc)
    else
        type_Loc = mod(ii-1,num_Loc_type)+1; % coprime이면 그냥 차례대로 쭉 인덱싱해도 모든 경우의수가 다 나옴
    end
    

    
    
    % generate image
    tmpIdxGlo = find(YTrain == idx_Loc(type_Loc));
    tmpIMG_Glo = imresize(XTrain(:,:,1,tmpIdxGlo(randperm(length(tmpIdxGlo),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Glo<0); tmpIMG_Glo(neg_ind)=0;
    tmpIMG_Glo = reshape(tmpIMG_Glo,redim,redim)/max(max(tmpIMG_Glo));
    
    switch type_Glo
        case 1
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2);
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2);
        case 2
            y_pos_Glo1 = round((ori_dim/2-redim)/2); x_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2); x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
        case 3
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2;
        case 4
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo2 = round((ori_dim/2-redim)/2)+dist2cen;
    end
    
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo1+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo1+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero2(II,JJ) = tmpIMG_Glo(I,J);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo2+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo2+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero3(II,JJ) = tmpIMG_Glo(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie)));
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
    
    train_imgs(:,:,:,ii) = tmp_zero;
    
    train_labels_g(ii) = type_Glo;
    train_labels_l(ii) = type_Loc;
    train_labels_lg(ii) = type_LG;
end


%% validation set
for ii = 1:num_valid
    type_LG = mod(ii-1,num_LocGlo_type)+1;
    type_Glo = mod(ii-1,num_Glo_type)+1;
    
    if gcd(num_Glo_type,num_Loc_type)~=1 % num_Glo_type / num_Loc_type 가 coprime이 아닌 경우... LG에서 모든 경우의 수를 다 만들어야 함
        temp_idx = fix((type_LG-1)/num_Glo_type); % 1234->0, 5678->1, ...
        type_Loc = mod(mod(ii-1,num_Loc_type) +temp_idx , num_Loc_type)+1; % 1234 / 2341 / 3412 / 4123 ....
%         disp(type_Loc)
    else
        type_Loc = mod(ii-1,num_Loc_type)+1; % coprime이면 그냥 차례대로 쭉 인덱싱해도 모든 경우의수가 다 나옴
    end
    
    
    % generate image
    tmpIdxGlo = find(YTrain == idx_Loc(type_Loc));
    tmpIMG_Glo = imresize(XTrain(:,:,1,tmpIdxGlo(randperm(length(tmpIdxGlo),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Glo<0); tmpIMG_Glo(neg_ind)=0;
    tmpIMG_Glo = reshape(tmpIMG_Glo,redim,redim)/max(max(tmpIMG_Glo));
    
    switch type_Glo
        case 1
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2);
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2);
        case 2
            y_pos_Glo1 = round((ori_dim/2-redim)/2); x_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2); x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
        case 3
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2;
        case 4
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo2 = round((ori_dim/2-redim)/2)+dist2cen;
    end
    
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo1+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo1+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero2(II,JJ) = tmpIMG_Glo(I,J);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo2+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo2+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero3(II,JJ) = tmpIMG_Glo(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie)));
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
    
    valid_imgs(:,:,:,ii) = tmp_zero;
    
    valid_labels_g(ii) = type_Glo;
    valid_labels_l(ii) = type_Loc;
    valid_labels_lg(ii) = type_LG;    
end


%% test set
for ii = 1:num_test
    type_LG = mod(ii-1,num_LocGlo_type)+1;
    type_Glo = mod(ii-1,num_Glo_type)+1;
    
    if gcd(num_Glo_type,num_Loc_type)~=1 % num_Glo_type / num_Loc_type 가 coprime이 아닌 경우... LG에서 모든 경우의 수를 다 만들어야 함
        temp_idx = fix((type_LG-1)/num_Glo_type); % 1234->0, 5678->1, ...
        type_Loc = mod(mod(ii-1,num_Loc_type) +temp_idx , num_Loc_type)+1; % 1234 / 2341 / 3412 / 4123 ....
%         disp(type_Loc)
    else
        type_Loc = mod(ii-1,num_Loc_type)+1; % coprime이면 그냥 차례대로 쭉 인덱싱해도 모든 경우의수가 다 나옴
    end
    
    
    % generate image
    tmpIdxGlo = find(YTrain == idx_Loc(type_Loc));
    tmpIMG_Glo = imresize(XTrain(:,:,1,tmpIdxGlo(randperm(length(tmpIdxGlo),1))),'Outputsize',[redim redim]);
    neg_ind = find(tmpIMG_Glo<0); tmpIMG_Glo(neg_ind)=0;
    tmpIMG_Glo = reshape(tmpIMG_Glo,redim,redim)/max(max(tmpIMG_Glo));
    
    switch type_Glo
        case 1
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2);
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2);
        case 2
            y_pos_Glo1 = round((ori_dim/2-redim)/2); x_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2); x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
        case 3
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+dist2cen; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen; x_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2;
        case 4
            y_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo1 = round((ori_dim/2-redim)/2)+ori_dim/2-dist2cen;
            y_pos_Glo2 = round((ori_dim/2-redim)/2)+ori_dim/2; x_pos_Glo2 = round((ori_dim/2-redim)/2)+dist2cen;
    end
    
    tmp_zero = zeros(y_dim,x_dim); tmp_zero2 = zeros(y_dim,x_dim); tmp_zero3 = zeros(y_dim,x_dim);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo1+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo1+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero2(II,JJ) = tmpIMG_Glo(I,J);
    
    [J,I]= meshgrid(1:redim,1:redim);
    II = I+y_pos_Glo2+randi([-pos_noise pos_noise]); JJ = J+x_pos_Glo2+randi([-pos_noise pos_noise]);
    I=I(:); J=J(:); II=II(:); JJ=JJ(:);
    tmp_zero3(II,JJ) = tmpIMG_Glo(I,J);
    
    tmp_zero = tmp_zero+tmp_zero2+tmp_zero3; tmp_zero(tmp_zero>1)=1;
    
    ind_pixel = find(tmp_zero); ind_pixel = ind_pixel(randperm(length(ind_pixel),floor(length(ind_pixel)*pDigitNosie)));
    tmp_zero(ind_pixel) = rand(length(ind_pixel),1); tmp_zero = reshape(tmp_zero,[y_dim,x_dim]);
    
    tmp_zero = tmp_zero + max_Amp.*rand(size(tmp_zero,1),size(tmp_zero,2));
    tmp_zero = tmp_zero./max(max(tmp_zero));
    
    test_imgs(:,:,:,ii) = tmp_zero;
    
    test_labels_g(ii) = type_Glo;
    test_labels_l(ii) = type_Loc;
    test_labels_lg(ii) = type_LG;    
end

IMAGE = {train_imgs, valid_imgs, test_imgs};
LABEL_g = {categorical(train_labels_g), categorical(valid_labels_g), categorical(test_labels_g)};
LABEL_l = {categorical(train_labels_l), categorical(valid_labels_l), categorical(test_labels_l)};
LABEL_lg = {categorical(train_labels_lg), categorical(valid_labels_lg), categorical(test_labels_lg)};

end