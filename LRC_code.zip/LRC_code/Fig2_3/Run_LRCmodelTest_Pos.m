% ver 211018
clc; clear; %close all;
%% Preprocess
addpath('Run_BioParam'); load('V1size_dim32.mat')
addpath('fun_coreConn'); addpath('fun_coreTrainCustom'); 
addpath('fun_stimulus\MNIST');
nameIMG = 'MNIST_LocGlo';
dirRes = ['Res_',nameIMG]; 

Type_img = 2; NN = 20; 
array_V1 = [32]; pLat = 0.5;
s_dot = 3.0; idx_Loc = [0:9];

if (Type_img == 1)||(Type_img == 3)
    numLabel_Loc = 4; numSubSet_Loc = nchoosek(length(idx_Loc),numLabel_Loc);
end

switch_result = 1;
switch_figure_IMG = 0;
switch_save = 1; %if switch_save == 1; if ~exist(dirRes,'dir'); mkdir(dirRes); end; end

%% Image parameter
dirIMG = 'fun_stimulus\MNIST'; 

img_dim = 32; % full width or height of a image
reimg_dim = 5; % width or height of small mnist
noise_Back_Amp = 0.00; % Background noise
noise_Digit_cen_p = 0.0;  % Pixel noise at center object
noise_Digit_sur_p = 0.0;  % Pixel noise at surround object
noise_Pos = 0; %  Positional noise


x_pos_cen = round((img_dim-reimg_dim)/2); x_pos = x_pos_cen+floor(reimg_dim/2);
y_pos_cen = round((img_dim-reimg_dim)/2); y_pos = y_pos_cen+floor(reimg_dim/2);
dot_size_sur = s_dot;
max_Amp_sur = 0.8;

% Type_img = 1;
Type_label = Type_img; % 1: local, 2: global, 3: loc & glob
STR_IMG = {'Shape', 'Position', 'Both'};

%% Network parameter
Xsize = img_dim; Ysize = img_dim;  % size of image
input_cell_num = Xsize*Ysize;    % # of neuron on the input layer

convergence_range = 2; convergence_range_RO = 2;
array_phid = [3]; % The number of input to hid connection; very sparse phid=3 -> p_FF=0.07
pout = 0.9999;
weight_init = 0.05;  % std
TT_iter = 1;

threshold_lrc = 10;
threshold_local = 9;
param_pre = [0.2677, 1.4775]; % [0.2677, 1.4775]; % labmda of length distribution
myfun = @(p, x) (p(1)*exp(-p(2)*x));

num_bin_Rewire = 8;
p_lateral = pLat;

load('Num_Conn_TreeshrewDist_V1_N100.mat','array_V1_ref','array_num_lateral_V1size');

%% Load raw data
array_d_dot2digit = [10];
STR_version = {'version_number'};

for dd = 1:length(array_d_dot2digit)
    versions = STR_version{dd}; d_dot2digit = array_d_dot2digit(dd); dist_digit = [d_dot2digit];
    if switch_save == 1
        dirFoldName = [dirRes,'\Result','_dataType','_',versions];
        if ~exist(dirFoldName,'dir'); mkdir(dirFoldName); end
    end

    %% Image generation
    rng(1);
    num_Train = 10000;
    switch Type_img
        case 1
            [IMAGE,LABEL] = fun_LocF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
                img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
        case 2
            [IMAGE,LABEL] = fun_GloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
                img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
        case 3
            [IMAGE,~,~,LABEL_lg] = fun_LocGloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
                img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
    end

    if Type_img == 3
        switch Type_label % 1: local, 2: global, 3: loc & glob
            case 1
                XTrain = IMAGE{1,1}; YTrain = LABEL_l{1,1};
                XValid = IMAGE{1,2}; YValid = LABEL_l{1,2};
            case 2
                XTrain = IMAGE{1,1}; YTrain = LABEL_g{1,1};
                XValid = IMAGE{1,2}; YValid = LABEL_g{1,2};
            case 3
                XTrain = IMAGE{1,1}; YTrain = LABEL_lg{1,1};
                XValid = IMAGE{1,2}; YValid = LABEL_lg{1,2};
        end
    else
        XTrain = IMAGE{1,1}; YTrain = LABEL{1,1};
        XValid = IMAGE{1,2}; YValid = LABEL{1,2};
    end

    classes = categories(YTrain); numClasses = numel(classes);
    output_cell_num = numClasses;    % # of neuron on the output layer

    %% Network train
    Cell_LAT_MAT = cell(NN,length(array_V1),num_bin_Rewire); Cell_FF_MAT = cell(NN,length(array_V1),3);
    array_conn_num_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3);
    array_C_Tot = zeros(NN,length(array_V1),num_bin_Rewire); array_L_Tot = zeros(NN,length(array_V1),num_bin_Rewire);
    array_C_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire); array_L_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire);
    array_SW_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3); array_SW_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3);

    array_accu_Tot = zeros(NN,length(array_V1),num_bin_Rewire); 
    N_shuf = 10; array_accu_shuf_Tot = zeros(NN,length(array_V1),num_bin_Rewire,N_shuf);

    for nn = 1:NN
        tic
        disp(['%%% Trial : ',num2str(nn)]); %rng(nn)
        for vv = 1:length(array_V1)
            disp(['%% V1 : ',num2str(array_V1(vv))])

            load([dirFoldName,'\Result_V1_',num2str(array_V1(vv)),'_C',num2str(convergence_range),'_hidNum',num2str(array_phid(1)),'_C2',num2str(convergence_range_RO),'_pout',num2str(pout),'_N',num2str(nn),'.mat']);
            load([dirFoldName,'\MAT_V1_',num2str(array_V1(vv)),'_C',num2str(convergence_range),'_hidNum',num2str(array_phid(1)),'_C2',num2str(convergence_range_RO),'_pout',num2str(pout),'_N',num2str(nn),'.mat']);

            Cell_FF_MAT(nn,vv,:) = MAT_ConnFF;
            Cell_LAT_MAT(nn,vv,:) = MAT_ConnLAT; array_conn_num_Tot(nn,vv,:,:) = array_num_conn;
            array_C_Tot(nn,vv,:) = array_C; array_L_Tot(nn,vv,:) = array_L; array_C_rand_Tot(nn,vv,:) = C_rand; array_L_rand_Tot(nn,vv,:) = L_rand;
            array_SW_Tot(nn,vv,:,:) = array_SW; array_SW_rand_Tot(nn,vv,:,:) = array_SW_rand;

            array_accu_Tot(nn,vv,:) = array_accu;

            array_accu_shuf = zeros(num_bin_Rewire,N_shuf);
            for ee = 1:num_bin_Rewire
                tic
                disp(['% Rewiring : ',num2str(ee)])
                net_L3lrc = MAT_ConnNet{ee};
                tmp_YValid = YValid; tmp_XValid = XValid;
                YPred = predict(net_L3lrc,tmp_XValid); [~,idx_ans] = max(YPred,[],2); YYPred = categorical(classes(idx_ans));

                for ss = 1:N_shuf
%                     array_accu_shuf(ee,ss) = mean(tmp_YValid(randperm(length(tmp_YValid))) == YYPred)*100;
                    array_accu_shuf(ee,ss) = mean(categorical(randi(4,size(YYPred))) == YYPred)*100;
                end
                toc
            end
            array_accu_shuf_Tot(nn,vv,:,:) = array_accu_shuf;
        end
        toc
    end

    %% Result
    indNN = NN; indNN_list = setdiff([1:NN],0); indV1 = 1; indSW = 3;

    array_LRCratio = squeeze(array_conn_num_Tot(indNN_list,:,:,3)./array_conn_num_Tot(indNN_list,:,:,1).*100);
    X_LRC = array_LRCratio;
    Y_L = squeeze(1./array_L_Tot(indNN_list,indV1,:));
    Y_C = squeeze(array_C_Tot(indNN_list,indV1,:));
    Y_SW = squeeze(array_SW_Tot(indNN_list,indV1,:,indSW));
    Y_Accu = squeeze(array_accu_Tot(indNN_list,indV1,:));
    Y_Accu_Shuf = squeeze(array_accu_shuf_Tot(indNN_list,indV1,:,:,:));

    %% Save
    if switch_save == 1
        save(['Result_',STR_IMG{Type_img},'_V1_',num2str(array_V1(indV1)),'_p',num2str(pLat),'_IMG_size',num2str(s_dot),'_dist',num2str(d_dot2digit),'.mat'],...
            'X_LRC','Y_C','Y_L','Y_SW','Y_Accu','Y_Accu_Shuf')
    end
end


% %% Summary
% Label_Index = {'C','1/L','SW'};
% 
% figure; set(gcf,'units','normalized','outerposition',[0 0 1 1]);
% sgtitle(['V1 ',num2str(array_V1(indV1)),' p',num2str(pLat),' IMG size',num2str(s_dot),' dist',num2str(d_dot2digit)])
% 
% XX = X_LRC; ZZ = Y_Accu;
% subplot(2,4,1); set(gca, 'XScale', 'log'); hold on;
% errorbar(mean(XX),mean(ZZ),std(ZZ)./sqrt(size(ZZ,1))*1.96,'-or'); ylabel('Accuracy'); xlabel('LRC ratio (%)')
% % shadedErrorBar(mean(XX),mean(ZZ),std(ZZ)./sqrt(size(ZZ,1))*1.96,'lineProps','r'); ylabel('Accuracy'); xlabel('LRC ratio (%)')
% 
% for ii = 1:length(Label_Index)
%     switch ii
%         case 1; YY = Y_C; case 2; YY = Y_L; case 3; YY = Y_SW;
%     end
%     subplot(2,4,ii+1); set(gca, 'XScale', 'log'); hold on; set(gca,'TickDir','out');
%     errorbar(mean(XX),mean(YY),std(YY)./sqrt(size(YY,1))*1.96,'-ok'); ylabel(Label_Index{ii}); xlabel('LRC ratio (%)')
% %     shadedErrorBar(mean(XX),mean(YY),std(YY)./sqrt(size(YY,1))*1.96,'lineProps','k'); ylabel(Label_Index{ii}); xlabel('LRC ratio (%)')
% 
%     subplot(2,4,ii+1+4); hold on; set(gca,'TickDir','out');
%     scatter(YY(:),ZZ(:),'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); xlabel(Label_Index{ii}); ylabel('accuracy')
%     for ee = 1:size(XX,2)
%         meanY = mean(YY(:,ee)); stdY = std(YY(:,ee))./sqrt(size(YY,1))*1.96; 
%         meanZ = mean(ZZ(:,ee)); stdZ = std(ZZ(:,ee))./sqrt(size(ZZ,1))*1.96;
%         errorbar(meanY,meanZ,stdZ,stdZ,stdY,stdY,'ok','MarkerFaceColor',[0 0 0])
%     end
%     xLimits = get(gca,'XLim');
%     
%     meanY = mean(YY,1); meanZ = mean(ZZ,1);
%     [c_mean,p_mean] = corrcoef(meanY,meanZ);
%     
%     myfun = @(p, x) (p(1)*x+p(2));
%     [param, ~] = nlinfit(meanY,meanZ,myfun,[1,1]);
%     xx = [xLimits(1):0.01:xLimits(end)]; yy = myfun(param,xx);
%     line(xLimits,[yy(1) yy(end)])
%     title(['Corr.: r=',num2str(c_mean(1,2)),'; p=',num2str(p_mean(1,2))])
% end
% 
% %% Result 
% Label_Index = {'C','1/L','SW'}; array_d = [4,8,9,10,11,12,16];%[10,11,12]; 
% 
% array_accu_mean = zeros(1,length(array_d)); array_accu_std = zeros(1,length(array_d));
% for dd = 1:length(array_d)
%     load(['Result_',STR_IMG{Type_img},'_V1_',num2str(array_V1(indV1)),'_p',num2str(pLat),'_IMG_size',num2str(s_dot),'_dist',num2str(array_d(dd)),'.mat']);
%     ZZ2 = Y_Accu; mean(ZZ2(:,1))
%     array_accu_mean(dd) = mean(ZZ2(:,1)); array_accu_std(dd) = std(ZZ2(:,1));
% end
% 
% figure;
% hold on; set(gca,'TickDir','out');
% shadedErrorBar(array_d,array_accu_mean,array_accu_std./sqrt(size(ZZ2,1))*1.96,'lineProps','r');
% xlabel('Center - Dot distance'); ylabel('Accuracy on LRC0%')
% xlim([4 16]); ylim([10 110]);
% 
% 
% 
% 
% c_subset = []; c_subset_shuf = [];
% for dd = 1:length(array_d)
%     load(['Result_',STR_IMG{Type_img},'_V1_',num2str(array_V1(indV1)),'_p',num2str(pLat),'_IMG_size',num2str(s_dot),'_dist',num2str(array_d(dd)),'.mat']);
%     XX = X_LRC; YY = Y_L; ZZ = Y_Accu; ZZ2 = Y_Accu; ZZ2_Shuf = Y_Accu_Shuf;
% 
%     meanY = mean(YY); meanZ = mean(ZZ2); [c_mean,p_mean] = corrcoef(meanY,meanZ);
% 
%     c_mean_shuf_Tot =[]; meanZ_shuf = mean(mean(ZZ2_Shuf,3));
%     for ss = 1:100
%         meanZ_shuf = meanZ_shuf(randperm(length(meanZ)));
%         [c_mean_shuf,p_mean_shuf] = corrcoef(meanY,meanZ_shuf);
%         c_mean_shuf_Tot = [c_mean_shuf_Tot, c_mean_shuf(1,2)];
%     end
%     [c_mean_shuf,p_mean_shuf] = corrcoef(meanY,meanZ_shuf);
%     c_subset = [c_subset,c_mean(1,2)]; c_subset_shuf = [c_subset_shuf,mean(c_mean_shuf_Tot)];
% end
% 
% figure;
% hold on; set(gca,'TickDir','out');
% plot(array_d,c_subset,'-or'); 
% plot(array_d,c_subset_shuf,'-ok'); 
% xlabel('Center - Dot distance'); ylabel('correlation')
% xlim([4 16]); ylim([-0.2 1.2])
% 
% figure; hold on; set(gca,'TickDir','out');
% boxplot([c_subset',c_subset_shuf'])
% xlim([0.5 2.5]); ylim([-0.2 1.2]); ylabel('correlation')
% xticklabels({'Trained','Shuffled'})
% ranksum(c_subset,c_subset_shuf)
% 
% % network variation
% c_subset = zeros(NN,length(array_d)); c_subset_shuf = zeros(NN,length(array_d)); 
% 
% for dd = 1:length(array_d)
%     load(['Result_',STR_IMG{Type_img},'_V1_',num2str(array_V1(indV1)),'_p',num2str(pLat),'_IMG_size',num2str(s_dot),'_dist',num2str(array_d(dd)),'.mat']);
%     XX = X_LRC; YY = Y_L; ZZ = Y_Accu; ZZ2 = Y_Accu; ZZ2_Shuf = Y_Accu_Shuf;
%     for nn = 1:NN
%         meanY = mean(YY(nn,:),1); meanZ = mean(ZZ2(nn,:),1); [c_mean,p_mean] = corrcoef(meanY,meanZ);
% 
%         c_mean_shuf_Tot =[]; meanZ_shuf = mean(mean(ZZ2_Shuf(nn,:,:),3),1);
%         for ss = 1:100
%             meanZ_shuf = meanZ_shuf(randperm(length(meanZ)));
%             [c_mean_shuf,p_mean_shuf] = corrcoef(meanY,meanZ_shuf);
%             c_mean_shuf_Tot = [c_mean_shuf_Tot, c_mean_shuf(1,2)];
%         end
% 
%         [c_mean_shuf,p_mean_shuf] = corrcoef(meanY,meanZ_shuf);
%         c_subset(nn,dd) = c_mean(1,2); c_subset_shuf(nn,dd) = mean(c_mean_shuf_Tot);
%     end
% end
% 
% figure;
% hold on; set(gca,'TickDir','out');
% % boxplot([c_subset',c_subset_shuf'])
% shadedErrorBar(array_d,nanmean(c_subset,1),nanstd(c_subset)./sqrt(NN).*1.96,'lineProps','r');
% shadedErrorBar(array_d,nanmean(c_subset_shuf,1),nanstd(c_subset_shuf)./sqrt(NN).*1.96,'lineProps','k'); 
% xlabel('Center - Dot distance'); ylabel('correlation')
% xlim([4 16]); ylim([-0.2 1.2])
% 
% figure; hold on; set(gca,'TickDir','out');
% boxplot([c_subset(:),c_subset_shuf(:)], 'symbol', '')
% xlim([0.5 2.5]); ylim([-0.2 1.2]); ylabel('correlation')
% xticklabels({'Trained','Shuffled'})
% array_p = [];
% for ii = 1:size(ZZ2,3)
%     array_p = [array_p ranksum(c_subset(:,ii),c_subset_shuf(:,ii))];
% end
% max(array_p)
% 
% 
% %% Result - Sample subset accuracy (Position)
% if (Type_img == 2)&&(switch_result == 1)
%     Label_Index = {'C','1/L','SW'};
% %     array_d = [4,8,9,10,11,12,16]; 
%     array_d = [4,8,12,16];
%     cmap = hot(length(array_d)+4);
% 
%     figure; set(gcf,'units','normalized','outerposition',[0 0.5 1 0.5]);
%     for dd = 1:length(array_d)
%         load(['Result_',STR_IMG{Type_img},'_V1_',num2str(array_V1(indV1)),'_p',num2str(pLat),'_IMG_size',num2str(s_dot),'_dist',num2str(array_d(dd)),'.mat']);
%         XX = X_LRC;
%         switch Type_img
%             case 1; YY = Y_C; case 2; YY = Y_L; case 3; YY = Y_SW;
%         end
% 
%         % summaray
%         subplot(1,3,2); set(gca,'TickDir','out'); set(gca, 'XScale', 'log'); hold on;
%         errorbar(mean(XX),mean(YY),std(YY)./sqrt(size(YY,1))*1.96,'-ok'); ylabel(Label_Index{Type_img}); xlabel('LRC ratio (%)')
% 
%         YYs = zeros(length(array_d),size(XX,2)); ZZ2s = zeros(length(array_d),size(XX,2));
% 
%         tmpZZ2 = Y_Accu;
%         subplot(1,3,1); set(gca,'TickDir','out'); set(gca, 'XScale', 'log'); hold on;
%         e1 = errorbar(mean(XX),mean(tmpZZ2),std(tmpZZ2)./sqrt(size(tmpZZ2,1))*1.96,'-o');
%         ylabel('Accuracy'); xlabel('LRC ratio (%)'); e1.Color = cmap(dd,:); ylim([10 110])
% 
%         subplot(1,3,3); set(gca,'TickDir','out'); hold on; 
%         %         scatter(YY(:),tmpZZ2(:),'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); xlabel(Label_Index{ii}); ylabel('accuracy')
%         for ee = 1:size(XX,2)
%             meanY = mean(YY(:,ee)); stdY = std(YY(:,ee))./sqrt(size(YY,1))*1.96;
%             meanZ = mean(tmpZZ2(:,ee)); stdZ = std(tmpZZ2(:,ee))./sqrt(size(tmpZZ2,1))*1.96;
%             e2 = errorbar(meanY,meanZ,stdZ,stdZ,stdY,stdY,'o'); e2.Color = cmap(dd,:);
%             YYs(dd,ee) = meanY; ZZ2s(dd,ee) = meanZ;
%         end
%         xlabel(Label_Index{Type_img}); ylabel('Accuracy'); ylim([10 110])
%     end
%     xLimits = get(gca,'XLim');
%     [c_mean,p_mean] = corrcoef(YYs(:),ZZ2s(:));
%     myfun = @(p, x) (p(1)*x+p(2));
%     [param, ~] = nlinfit(YYs(:),ZZ2s(:),myfun,[1,1]);
%     xx = [xLimits(1):0.01:xLimits(end)]; yy = myfun(param,xx);
%     line(xLimits,[yy(1) yy(end)]); xlim(xLimits)
%     title(['Corr.: r=',num2str(c_mean(1,2)),'; p=',num2str(p_mean(1,2))])
% 
% %     sgtitle(['Dist',num2str(array_d(1)),' / Dist',num2str(array_d(2)),' / Dist',num2str(array_d(3))])
% end