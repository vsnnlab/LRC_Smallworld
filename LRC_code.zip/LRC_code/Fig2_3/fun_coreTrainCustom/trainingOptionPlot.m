function [lineAccuracyTrain,lineLossTrain,...
    lineAccuracyValidation,lineLossValidation] = trainingOptionPlot(flag_valid)

figure
subplot(2,1,1)
lineAccuracyTrain = animatedline('Color',[1 0.7 0.7],'LineWidth',0.5);
xlim([0 inf]);ylim([0 inf])
ylabel("Accuracy (%)")

subplot(2,1,2)
lineLossTrain = animatedline('Color',[0.7 0.7 1],'LineWidth',0.5);
xlabel("Iteration")
ylabel("Loss")
xlim([0 inf]);ylim([0 inf])

if flag_valid
    subplot(2,1,1)
    lineAccuracyValidation = animatedline('Color',[1 0 0],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[1 0 0]);
    
    subplot(2,1,2)
    lineLossValidation = animatedline('Color',[0 0 1],'LineWidth',1.5,'LineStyle','-.','Marker','o','MarkerSize',4,'MarkerFaceColor',[0 0 1]);
end

end