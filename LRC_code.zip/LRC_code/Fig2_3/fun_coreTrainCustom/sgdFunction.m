function parameter = sgdFunction(parameter,gradient,learnRate)
    parameter = parameter - learnRate .* gradient;
end



