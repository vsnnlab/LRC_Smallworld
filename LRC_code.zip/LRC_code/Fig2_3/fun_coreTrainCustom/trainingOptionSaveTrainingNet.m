function [checkpointPath] = trainingOptionSaveTrainingNet(checkfolderName)
    checkpointPath = fullfile(pwd,checkfolderName);
    if ~exist(checkpointPath,"dir"); mkdir(checkpointPath); end
end