classdef CNVGLayer2 < nnet.layer.Layer
    properties
        % Input size
        x1
        x2
        x3
        
        % Output size
        z1
        z2
        
        
        % Weight size
        w1
        w2
    end
    
    properties (Learnable)
        % Layer learnable parameters
            
        % Scaling coefficient
        Weights
    end
    
    methods
        function layer = CNVGLayer2(x1,x2,x3,z1,z2,name)
            % Set layer name
            if nargin == 6
                layer.Name = name;
            end
            
            % Create an examplePreluLayer with numChannels channels
            layer.x1 = x1;	layer.x2 = x2;	layer.x3 = x3; 
            layer.z1 = z1;	layer.z2 = z2;
            layer.w1 = x1*x2;	
            layer.w2 = z1*z2;
            
            layer.Weights = 0.01.*randn(layer.w1,layer.w2);
        end
        
        function Z = predict(layer, X)
            % Forward input data through the layer and output the result
            [~,~,~,Num_batch] = size(X);
            
            X_sprs = sparse(reshape(double(X),[layer.x1*layer.x2*layer.x3,Num_batch]));
            weight_sprs = sparse(double(layer.Weights));
            
            Z = single(full(weight_sprs'*X_sprs));
            Z = reshape(permute(Z,[1,3,4,2]),[layer.z1,layer.z2,1,Num_batch]);
        end
        
        function [dLdX, dLdW] = backward(layer, X, ~, dLdZ, ~)
            % Backward propagate the derivative of the loss function through 
            [~,~,~,Num_batch] = size(X);
            
            weight_sprs = sparse(double(layer.Weights));
            dLdZ_sprs = sparse(reshape(double(dLdZ),[layer.z1*layer.z2,Num_batch]));
            X_sprs = sparse(reshape(double(X),[layer.x1*layer.x2*layer.x3,Num_batch]));
            
            dLdX = single(full(weight_sprs*dLdZ_sprs));
            dLdX = reshape(permute(dLdX,[1,3,4,2]),[layer.x1 layer.x2 layer.x3 Num_batch]);
                    
            dLdW = single(full(X_sprs*dLdZ_sprs'));
            dLdW = reshape(dLdW,[layer.w1, layer.w2]);
            
            dLdW = dLdW .* (layer.Weights~=0);
%             sum(layer.Weight(:)~=0)
        end
    end
end