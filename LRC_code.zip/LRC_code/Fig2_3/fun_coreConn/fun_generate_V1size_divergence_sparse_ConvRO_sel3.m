function [connection_w0,connection_w0_re,connection_w1,connection_w1_re,connection_w2_re] = fun_generate_V1size_divergence_sparse_ConvRO_sel3...
    (input_cell_num,hidden_cell_num,output_cell_num,x_pos,y_pos,convergence_range,convergence_range_RO,num_hid,pout)

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % 동일하게 나눔  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

connection_w0_re = zeros(size(connection_w0));
for hh = 1:hidden_cell_num
    ind = find(connection_w0(hh,:));
    ind = ind(randperm(length(ind),min(round(num_hid/hidden_cell_num),length(ind))));
    connection_w0_re(hh,ind) = 1;
end


%==========================================================================
V1_dim = sqrt(hidden_cell_num);
% Remap_hid_indx = round(linspace(1,sqrt(hidden_cell_num),V1_dim));

connection_w1 = zeros(hidden_cell_num,hidden_cell_num);

for ii = 1:hidden_cell_num
    x_input = floor((ii-1)/sqrt(hidden_cell_num))+1;
    y_input = mod((ii-1),sqrt(hidden_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
%         x_hid = Remap_hid_indx(x_hid);
%         y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % 동일하게 나눔  !!
        connection_w1(hh,ii) = distance_input_hid < convergence_range_RO;
    end
end

connection_w1_re = zeros(size(connection_w1));
for hh = 1:hidden_cell_num
    ind = find(connection_w1(hh,:));
    ind = ind(randperm(length(ind),min(round(pout*length(ind)),length(ind))));
    connection_w1_re(hh,ind) = 1;
end

Remap_in_indx = round(linspace(1,sqrt(hidden_cell_num),sqrt(input_cell_num)));
connection_w2_re = zeros(output_cell_num,hidden_cell_num);
[JJ,II] = meshgrid(-3:3,-3:3); ind_in_pos = sub2ind([sqrt(hidden_cell_num) sqrt(hidden_cell_num)],JJ(:)+Remap_in_indx(x_pos),II(:)+Remap_in_indx(y_pos));
for oo = 1:output_cell_num
    connection_w2_re(oo,ind_in_pos(oo)) = 1;
end
% connection_w2_re(:,ind_in_pos(randperm(length(ind_in_pos),output_cell_num))) = 1;
% connection_w2_re(:,ind_in_pos) = 1;

end