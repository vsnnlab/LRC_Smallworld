function accu_RO = fun_calAccuracyRO(net_L3lrc,XValid,YValid,classes,numClasses)
%%%% RO 별 accuracy
YPred = predict(net_L3lrc,XValid); [~,idx_ans] = max(YPred,[],2); YYPred = categorical(classes(idx_ans));
YValidOneHot = zeros(size(YValid,1),numClasses); YPredOneHot = zeros(size(YPred,1),numClasses);
for ro = 1:length(YValid)
    YValidOneHot(ro,YValid(ro)) = 1;
    YPredOneHot(ro,YYPred(ro)) = 1;
end
accu_RO = sum(YPredOneHot.*YValidOneHot,1)./sum(YValidOneHot,1)*100;
end