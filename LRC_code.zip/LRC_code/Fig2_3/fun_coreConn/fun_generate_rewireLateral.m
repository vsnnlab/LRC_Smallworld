function connection_lateral = fun_generate_rewireLateral(array_connRewire_num,MAT_ConnLAT,ee,connection_local_origin,x_range_local,x_range_lrc,indLRC)
if ee == 1
    connection_lateral = connection_local_origin;
else
    num_rewire = array_connRewire_num(ee)-array_connRewire_num(ee-1);
    connection_lateral_pre = MAT_ConnLAT{ee-1};
    conn_len_pre = fun_cal_len_LRC(connection_lateral_pre,0);
    indLocal_pre = find((conn_len_pre>=x_range_local(1))&(conn_len_pre<x_range_local(end)));
    indLRC_pre = setdiff(indLRC,find((conn_len_pre>=x_range_lrc(1))&(conn_len_pre<x_range_lrc(end))));
    
    indLocal_del = indLocal_pre(randperm(length(indLocal_pre),num_rewire));
    indLRC_add = indLRC_pre(randperm(length(indLRC_pre),num_rewire));
    connection_lateral_pre(indLocal_del) = 0; connection_lateral_pre(indLRC_add) = 1;
    connection_lateral = connection_lateral_pre;
end
end