function L = fun_setLayers(Ysize,Xsize,outYsize,outXsize,numClasses,TT_iter,MAT_ConnW,MAT_ConnFF,ConnLAT)
L = [
    imageInputLayer([Ysize Xsize 1],'Normalization','none','Name','input')
    CNVGLayer2(Ysize,Xsize,1,outYsize,outXsize,'L1') % Weights = [input, hidden]
    CNVGLayer2(outYsize,outXsize,1,outYsize,outXsize,'Llat') % Weights = [input, hidden]
    reluLayer('Name', 'relu1')
    CNVGLayer2(outYsize,outXsize,1,outYsize,outXsize,'fc1') % Weights = [input, hidden]
    fullyConnectedLayer(numClasses,'Name','fc2') % Weights = [out, hidden]
    softmaxLayer('Name','softmax')
    classificationLayer('Name','class')];

L(2).Weights = MAT_ConnW{1}.*MAT_ConnFF{1}'; % define convergence connectivity
switch TT_iter
    case 1
        L(3).Weights = (MAT_ConnW{2}.*ConnLAT'+eye(size(ConnLAT,1)));
    case 2
        L(3).Weights = (MAT_ConnW{2}.*boolean(ConnLAT'*ConnLAT')+eye(size(ConnLAT,1)));
    case 3
        L(3).Weights = (MAT_ConnW{2}.*boolean(ConnLAT'*ConnLAT'*ConnLAT')+eye(size(ConnLAT,1)));
end
L(5).Weights = MAT_ConnW{3}.*MAT_ConnFF{2}'; % hidden - output
L(6).Weights = MAT_ConnFF{3}; % define convergence connectivity
L(6).WeightLearnRateFactor = 0; L(6).BiasLearnRateFactor = 0;
end