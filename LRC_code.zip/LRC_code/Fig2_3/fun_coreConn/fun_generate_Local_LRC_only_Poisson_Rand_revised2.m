function [connection_local_origin, connection_lrc_origin] = fun_generate_Local_LRC_only_Poisson_Rand_revised2(length_matrix_initial,x_range_local,x_range_lrc,nn)

% local only
tmp_len_mat = length_matrix_initial; 
tmp_len_mat(tmp_len_mat>=x_range_local(end)) = nan; tmp_len_mat(find(eye(size(tmp_len_mat)))) = nan;
p_len = tmp_len_mat; p_len(isnan(p_len)) = 0;
rng(nn); connection_local_origin_tmp = rand(size(p_len))<p_len;

% lrc only
tmp_len_mat = length_matrix_initial; 
tmp_len_mat(tmp_len_mat<x_range_lrc(1)) = nan; tmp_len_mat(find(eye(size(tmp_len_mat)))) = nan;
p_len = tmp_len_mat; p_len(isnan(p_len)) = 0;
rng(nn); connection_lrc_origin_tmp = rand(size(p_len))<p_len;

% control number of connections
connection_local_origin = zeros(size(connection_local_origin_tmp)); connection_lrc_origin = zeros(size(connection_lrc_origin_tmp));
indLocal = find(connection_local_origin_tmp); %indLocal = indLocal(randperm(length(indLocal),num_lateral));
indLRC = find(connection_lrc_origin_tmp); %indLRC = indLRC(randperm(length(indLRC),num_lateral));
connection_local_origin(indLocal) = 1; connection_lrc_origin(indLRC) = 1;

end