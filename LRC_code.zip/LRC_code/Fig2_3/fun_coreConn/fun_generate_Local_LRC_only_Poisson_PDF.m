function [connection_local_origin, connection_lrc_origin] = fun_generate_Local_LRC_only_Poisson_PDF(length_matrix_initial,x_range_local,x_range_lrc,param_local,param_lrc,myfun,threshold_lrc,num_lateral)

% local only
tmp_len_mat = length_matrix_initial; tmp_len_mat(tmp_len_mat>=x_range_local(end)) = inf;
p_len = myfun(param_local,tmp_len_mat./threshold_lrc);
p_len(p_len == max(max(p_len))) = 0;
connection_local_origin_tmp = rand(size(p_len))<p_len;

% lrc only
tmp_len_mat = length_matrix_initial; tmp_len_mat(tmp_len_mat<x_range_lrc(1)) = inf;
p_len = myfun(param_lrc,tmp_len_mat./threshold_lrc);
p_len(p_len == max(max(p_len))) = 0;
connection_lrc_origin_tmp = rand(size(p_len))<p_len;

% control number of connections
connection_local_origin = zeros(size(connection_local_origin_tmp)); connection_lrc_origin = zeros(size(connection_lrc_origin_tmp));
indLocal = find(connection_local_origin_tmp); indLocal = indLocal(randperm(length(indLocal),num_lateral));
indLRC = find(connection_lrc_origin_tmp); indLRC = indLRC(randperm(length(indLRC),num_lateral));
connection_local_origin(indLocal) = 1; connection_lrc_origin(indLRC) = 1;

end