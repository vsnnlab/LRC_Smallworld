function fun_figIO(f,array_V1,IOmap,nn,vv,ee,array_connRewire_num,array_num_connBack,num_bin_Rewire)
for ro = 1:size(IOmap,1)
    set(0,'CurrentFigure',f)
    subplot(num_bin_Rewire,size(IOmap,1),size(IOmap,1)*(ee-1)+ro)
    imagesc(reshape(IOmap(ro,:),[sqrt(size(IOmap,2)) sqrt(size(IOmap,2))])); axis image off; caxis([0 5]); drawnow;
    title(array_connRewire_num(ee)./array_num_connBack(3)*100)
end
sgtitle(['IO map; ','V1 = ',num2str(array_V1(vv)),'; N = ',num2str(nn)]);
end