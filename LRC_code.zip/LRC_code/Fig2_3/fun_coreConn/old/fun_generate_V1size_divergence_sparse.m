function [connection_w0,connection_w1] = fun_generate_V1size_divergence_sparse(input_cell_num,hidden_cell_num,output_cell_num,convergence_range,phid,pout)

% input_cell_num = 32*32;
% hidden_cell_num = 32*32;
% output_cell_num = 10;
% convergence_range = 5;
% phid = 0.1;
% pout = 1;

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);
connection_w1 = double(rand(output_cell_num,hidden_cell_num)<pout);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % �����ϰ� ����  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

%
ind = find(connection_w0);
numDel = length(ind)-floor(length(ind)*phid);
ind_del = ind(randperm(length(ind),numDel));
connection_w0(ind_del) = 0;

end
                                                             