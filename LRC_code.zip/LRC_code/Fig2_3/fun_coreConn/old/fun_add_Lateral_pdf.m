function connection_lrc = fun_add_Lateral_pdf(length_matrix,addNumLength)

[s1,s2] = size(length_matrix);
connection_lrc = zeros(s1,s2);

for ii = 1:length(addNumLength)
    Num_length = addNumLength(ii);
    if Num_length == 0; continue; end
    
    ind_length = find(length_matrix == ii);
    ind_add_length = ind_length(randperm(length(ind_length),min(Num_length,length(ind_length))));
    connection_lrc(ind_add_length) = 1;
end
connection_lrc = reshape(connection_lrc,s1,s2);

end