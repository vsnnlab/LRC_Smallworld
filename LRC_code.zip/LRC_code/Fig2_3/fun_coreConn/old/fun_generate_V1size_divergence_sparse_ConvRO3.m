function [connection_w0,connection_w0_re,connection_w1,connection_w1_re] = fun_generate_V1size_divergence_sparse_ConvRO3...
    (input_cell_num,hidden_cell_num,convergence_range,convergence_range_RO,numhid,numhid2)

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % �����ϰ� ����  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

connection_w0_re = zeros(size(connection_w0));
for hh = 1:hidden_cell_num
    ind = find(connection_w0(hh,:));
    ind = ind(randperm(length(ind),min(numhid/hidden_cell_num,length(ind))));
    connection_w0_re(hh,ind) = 1;
end

% ind = find(connection_w0);
% numDel = length(ind)-numhid;
% ind_del = ind(randperm(length(ind),numDel));
% connection_w0(ind_del) = 0;

%==========================================================================
V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(hidden_cell_num),V1_dim));

connection_w1 = zeros(hidden_cell_num,hidden_cell_num);

for ii = 1:hidden_cell_num
    x_input = floor((ii-1)/sqrt(hidden_cell_num))+1;
    y_input = mod((ii-1),sqrt(hidden_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % �����ϰ� ����  !!
        connection_w1(hh,ii) = distance_input_hid < convergence_range_RO;
    end
end

connection_w1_re = zeros(size(connection_w1));
for hh = 1:hidden_cell_num
    ind = find(connection_w1(hh,:));
    ind = ind(randperm(length(ind),min(numhid2/hidden_cell_num,length(ind))));
    connection_w1_re(hh,ind) = 1;
end

end