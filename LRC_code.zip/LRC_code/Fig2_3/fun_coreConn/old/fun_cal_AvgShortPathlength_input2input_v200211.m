function L = fun_cal_AvgShortPathlength_input2input_v200211(MAT_connectivity)
%% parameter
connection_w0 = MAT_connectivity{1};
connection_lrc = MAT_connectivity{2};

input_cell_num = size(connection_w0,2);


pos_only_lateral = 1-diag(ones(1,size(connection_lrc,1)));
connection_lrc = connection_lrc.*pos_only_lateral;
connection_w0_NET = double((connection_w0 + connection_lrc * connection_w0)>0);

connection_input_1mode = zeros(input_cell_num,input_cell_num);
for ii=1:input_cell_num
    for jj=1:input_cell_num
        connection_input_1mode(ii,jj) = sum (and (connection_w0_NET(:,ii) , connection_w0_NET(:,jj))) > 0;
    end
    connection_input_1mode(ii,ii) = 0;
end


G_one_mode = graph(connection_input_1mode);
d = distances(G_one_mode);
d(find(diag(ones(1,size(connection_w0,2))))) = []; % �ڱ��ڽ����� ���°� �����ϱ� ���ؼ� 
d(d == inf) = [];
L = sum(sum(d)) / (length(d));

end