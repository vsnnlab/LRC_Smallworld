function [connection_w0,connection_w1] = fun_generate_V1size_divergence_sparse_ConvRO(input_cell_num,hidden_cell_num,output_cell_num,convergence_range,phid,pout,rCIFAR)

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % �����ϰ� ����  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

ind = find(connection_w0);
numDel = length(ind)-floor(length(ind)*phid);
ind_del = ind(randperm(length(ind),numDel));
connection_w0(ind_del) = 0;

%==========================================================================
% convergence_range_OR = round(rCIFAR+0.5-convergence_range);
convergence_range_OR = rCIFAR;

connection_w1 = zeros(output_cell_num,hidden_cell_num);
tmp_len = round(fun_cal_len_LRC(ones(hidden_cell_num,hidden_cell_num),0));
tmp_len = tmp_len < convergence_range_OR;
indRO = tmp_len(V1_dim*(floor(V1_dim/2))+(floor(V1_dim/2)),:);
connection_w1(:,indRO) = 1;

ind = find(connection_w1);
numDel = length(ind)-floor(length(ind)*pout);
ind_del = ind(randperm(length(ind),numDel));
connection_w1(ind_del) = 0;

end
                                                             