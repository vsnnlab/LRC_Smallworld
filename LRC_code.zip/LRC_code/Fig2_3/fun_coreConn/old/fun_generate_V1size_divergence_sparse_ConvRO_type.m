function [connection_w0,connection_w0_re,connection_w1] = fun_generate_V1size_divergence_sparse_ConvRO_type...
    (input_cell_num,hidden_cell_num,output_cell_num,convergence_range,numhid,pout,rCIFAR,Type_RO)

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % �����ϰ� ����  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

connection_w0_re = zeros(size(connection_w0));
for hh = 1:hidden_cell_num
    ind = find(connection_w0(hh,:));
    ind = ind(randperm(length(ind),min(numhid/hidden_cell_num,length(ind))));
    connection_w0_re(hh,ind) = 1;
end

% ind = find(connection_w0);
% numDel = length(ind)-numhid;
% ind_del = ind(randperm(length(ind),numDel));
% connection_w0(ind_del) = 0;

%==========================================================================
% convergence_range_OR = round(rCIFAR+0.5-convergence_range);
convergence_range_OR = rCIFAR;

rspace = [1:sqrt(hidden_cell_num)];
switch Type_RO
    case 1
        p_X = normpdf(rspace,8,1); %p_X = poisspdf(rspace,8);
        p_Y = ones(1,length(rspace))./length(rspace);
        p_Y([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_Y = p_Y./sum(p_Y);
    case 2
        p_Y = normpdf(rspace,8,1); %p_Y = poisspdf(rspace,8);
        p_X = ones(1,length(rspace))./length(rspace);
        p_X([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_X = p_X./sum(p_X);
    case 3
        p_X = normpdf(rspace,24,1); %p_X = poisspdf(rspace,24);
        p_Y = ones(1,length(rspace))./length(rspace);
        p_Y([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_Y = p_Y./sum(p_Y);
    case 4
        p_Y = normpdf(rspace,24,1); %p_Y = poisspdf(rspace,24);
        p_X = ones(1,length(rspace))./length(rspace);
        p_X([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_X = p_X./sum(p_X);
    case 5
        p_X = ones(1,length(rspace))./length(rspace); p_Y = ones(1,length(rspace))./length(rspace);
        p_Y([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_Y = p_Y./sum(p_Y);
        p_X([1:2*rCIFAR, length(rspace)-2*rCIFAR+1:length(rspace)]) = 0; p_X = p_X./sum(p_X);
end
p_XY = p_Y'*p_X; p_XY = p_XY./sum(p_XY,'all');

%         figure;
%         subplot(1,3,1); plot(rspace,p_X); xlim([1 32]); ylim([0 0.3]);
%         subplot(1,3,2); plot(rspace,p_Y); xlim([1 32]); ylim([0 0.3]);
%         subplot(1,3,3); imagesc(p_XY); axis image;

connection_w1 = zeros(output_cell_num,hidden_cell_num);

for ii = 1:output_cell_num
    tmp_XY = floor(p_XY.*numel(p_XY));
    tmp_ind = find(tmp_XY); tmp_ind = tmp_ind(randperm(numel(tmp_ind),1));
    [y_hid, x_hid] = ind2sub(size(p_XY),tmp_ind);
    for jj = 1:hidden_cell_num
        x_input = floor((jj-1)/sqrt(hidden_cell_num))+1;
        y_input = mod((jj-1),sqrt(hidden_cell_num))+1;
        distance_input_hid = sqrt((x_input-x_hid)^2+(y_input-y_hid)^2);
        connection_w1(ii,jj) = distance_input_hid < convergence_range_OR;
    end
end

%         figure;
%         subplot(1,4,1); imagesc(reshape(connection_RO(1,:),[32 32])); axis image;
%         subplot(1,4,2); imagesc(reshape(connection_RO(2,:),[32 32])); axis image;
%         subplot(1,4,3); imagesc(reshape(connection_RO(3,:),[32 32])); axis image;
%         subplot(1,4,4); imagesc(reshape(connection_RO(4,:),[32 32])); axis image;

ind = find(connection_w1);
numDel = length(ind)-floor(length(ind)*pout);
ind_del = ind(randperm(length(ind),numDel));
connection_w1(ind_del) = 0;

end