function [C] = fun_cal_AvgClusteringCoeff_projLRC_noStride(MAT_connectivity)

% MAT_connectivity = {MAT_conn_array{1,vv,1,ll,1},MAT_conn_array{1,vv,1,ll,2},MAT_conn_array{1,vv,1,ll,3}};
%% parameter
connection_w0 = MAT_connectivity{1};
connection_lrc = MAT_connectivity{2};
if connection_lrc == 0
    connection_lrc = zeros(size(connection_w0,1),size(connection_w0,1));
end
connection_w1 = MAT_connectivity{3};

input_cell_num = size(connection_w0,2);
hidden_cell_num = size(connection_lrc,1);
output_cell_num = size(connection_w1,1);

V1_dim = round(sqrt(hidden_cell_num));
stride = round(sqrt(input_cell_num)/(V1_dim));

%% Calculate local efficient ( clustering coefficient )
% hidden node 
% array_local_efficieny = zeros(1,hidden_cell_num+output_cell_num);
array_local_efficieny = zeros(1,hidden_cell_num);
% array_lengthsum = zeros(2,hidden_cell_num);

for hh = 1:hidden_cell_num
    % input-hidden
    ind_neighbor1 = find(connection_w0(hh,:) == 1);
    array_neighbor_pair1 = zeros(length(ind_neighbor1),2);
    if length(ind_neighbor1) > 1 % �̿����� �Ÿ��� �ּ� �̿��� 2�� �̻� �־�� ���� ����
        for nn = 1:length(ind_neighbor1)
            array_neighbor_pair1(nn,1) = floor((ind_neighbor1(nn)-1)/sqrt(input_cell_num))+1;
            array_neighbor_pair1(nn,2) = mod(ind_neighbor1(nn)-1,sqrt(input_cell_num))+1;
        end 
    else
        array_neighbor_pair1 = [];
    end

    hid_pos = (sqrt(input_cell_num)-(V1_dim))/2;
    % hidden-hidden 
    ind_neighbor2 = find(connection_lrc(hh,:) == 1);
    array_neighbor_pair2 = zeros(length(ind_neighbor2),2);
    if length(ind_neighbor2) > 1 % �̿����� �Ÿ��� �ּ� �̿��� 2�� �̻� �־�� ���� ����
        for nn = 1:length(ind_neighbor2)
            array_neighbor_pair2(nn,1) = (floor((ind_neighbor2(nn)-1)/sqrt(hidden_cell_num))+1)+hid_pos; % hidden layer --> input layer coordinate
            array_neighbor_pair2(nn,2) = (mod(ind_neighbor2(nn)-1,sqrt(hidden_cell_num))+1)+hid_pos; % hidden layer --> input layer coordinate
        end
    else
        array_neighbor_pair2 = [];
    end
    
    total_array_neighbor = [array_neighbor_pair1;array_neighbor_pair2];
    
    if size(total_array_neighbor,1) > 1
        dist = 1./pdist(total_array_neighbor); % random �ϰ� ������ LRC �� FF �� ��ĥ ��� !!!! -> pdist = 0
        dist(isinf(dist)) = [];
        lengthsum = mean(sum(sum(dist,1),2)/2);
    else
        lengthsum = 0;
    end
    array_local_efficieny(hh) = lengthsum;
%     if size(total_array_neighbor,1) > 1
%         lengthsum = mean(sum(sum(pdist(total_array_neighbor),1),2)/2);
%     else
%         lengthsum = inf;
%     end
%     array_local_efficieny(hh) = lengthsum;

end

C = mean(array_local_efficieny);
% C = mean(1./array_local_efficieny);
end