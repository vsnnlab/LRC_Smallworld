function fun_figAccuConnPoint(f,array_V1,numplot,vv,ee,array_connRewire_num,array_num_connBack,array_accu,array_C,array_L)
set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+1); hold on; title(['V1 ',num2str(array_V1(vv))]);
scatter(array_connRewire_num(ee)/array_num_connBack(3)*100,array_accu,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.7,0,0]);
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('Accuracy'); xlim([-inf 100]); ylim([0 100]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+2); hold on;
scatter(array_connRewire_num(ee)/array_num_connBack(3)*100,array_C,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]);
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('C'); xlim([-inf 100]); ylim([-inf inf]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+3); hold on;
scatter(array_connRewire_num(ee)/array_num_connBack(3)*100,1./array_L,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); drawnow;
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('1/L'); xlim([-inf 100]); ylim([-inf inf]); drawnow;
end