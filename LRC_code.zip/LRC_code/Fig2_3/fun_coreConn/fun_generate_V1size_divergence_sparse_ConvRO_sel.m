function [connection_w0,connection_w0_re,connection_w1,connection_w1_re,connection_w2_re] = fun_generate_V1size_divergence_sparse_ConvRO_sel...
    (input_cell_num,hidden_cell_num,output_cell_num,x_pos,y_pos,convergence_range,convergence_range_RO,num_hid,pout)

V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(input_cell_num),V1_dim));

connection_w0 = zeros(hidden_cell_num,input_cell_num);

for ii = 1:input_cell_num
    x_input = floor((ii-1)/sqrt(input_cell_num))+1;
    y_input = mod((ii-1),sqrt(input_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % 동일하게 나눔  !!
        connection_w0(hh,ii) = distance_input_hid < convergence_range;
    end
end

connection_w0_re = zeros(size(connection_w0));
for hh = 1:hidden_cell_num
    ind = find(connection_w0(hh,:));
    ind = ind(randperm(length(ind),min(num_hid/hidden_cell_num,length(ind))));
    connection_w0_re(hh,ind) = 1;
end

% ind = find(connection_w0);
% numDel = length(ind)-numhid;
% ind_del = ind(randperm(length(ind),numDel));
% connection_w0(ind_del) = 0;

%==========================================================================
V1_dim = sqrt(hidden_cell_num);
Remap_hid_indx = round(linspace(1,sqrt(hidden_cell_num),V1_dim));

connection_w1 = zeros(hidden_cell_num,hidden_cell_num);

for ii = 1:hidden_cell_num
    x_input = floor((ii-1)/sqrt(hidden_cell_num))+1;
    y_input = mod((ii-1),sqrt(hidden_cell_num))+1;
    for hh = 1:hidden_cell_num
        
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        x_hid = Remap_hid_indx(x_hid);
        y_hid = Remap_hid_indx(y_hid);
        
        distance_input_hid = sqrt((x_input-(x_hid))^2+(y_input-(y_hid))^2); % 동일하게 나눔  !!
        connection_w1(hh,ii) = distance_input_hid < convergence_range_RO;
    end
end

connection_w1_re = zeros(size(connection_w1));
for hh = 1:hidden_cell_num
    ind = find(connection_w1(hh,:));
    ind = ind(randperm(length(ind),min(round(pout*length(ind)),length(ind))));
    connection_w1_re(hh,ind) = 1;
end

connection_w2_re = zeros(output_cell_num,hidden_cell_num);
FFmap = connection_w1_re*connection_w0_re;
[JJ,II] = meshgrid(-1:1,-1:1); ind_in_pos = sub2ind([sqrt(input_cell_num) sqrt(input_cell_num)],JJ(:)+x_pos,II(:)+y_pos);
list_conn_amp = unique(FFmap(:,ind_in_pos)); ind_hid2in_pos = []; amp_hid2in_pos = [];
for io = 1:length(ind_in_pos)
    ind_hid2in_pos = [ind_hid2in_pos; find(FFmap(:,ind_in_pos(io)))];
    amp_hid2in_pos = [amp_hid2in_pos; FFmap(find(FFmap(:,ind_in_pos(io))),ind_in_pos(io))];
end
ind_hid2in_pos_uni = unique(ind_hid2in_pos); amp_hid2in_pos_uni = [];
for iou = 1:length(ind_hid2in_pos_uni)
    tmpIND = find(ind_hid2in_pos == ind_hid2in_pos_uni(iou));
    amp_hid2in_pos_uni = [amp_hid2in_pos_uni;amp_hid2in_pos(tmpIND(1))];
end
[~,amp_order] = sort(amp_hid2in_pos_uni,'descend');
ind_hid2in_pos_uni = ind_hid2in_pos_uni(amp_order(1:output_cell_num));
ind_hid2in_pos_uni = ind_hid2in_pos_uni(randperm(length(ind_hid2in_pos_uni)));

for ro = 1:output_cell_num
    connection_w2_re(ro,ind_hid2in_pos_uni(ro)) = 1;
end
end