function fun_figAccuConnLine(f,array_V1,numplot,vv,array_connRewire_num,array_num_connBack,array_accu,array_C,array_L,array_SW,array_SW_rand)
set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+1); hold on; title(['V1 ',num2str(array_V1(vv))]);
plot(array_connRewire_num/array_num_connBack(3)*100,array_accu,'-or');
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('Accuracy'); xlim([-inf 100]); ylim([0 100]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+2); hold on;
plot(array_connRewire_num/array_num_connBack(3)*100,array_C,'-ok');
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('C'); xlim([-inf 100]); ylim([-inf inf]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+3); hold on;
plot(array_connRewire_num/array_num_connBack(3)*100,1./array_L,'-ok'); drawnow;
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('1/L'); xlim([-inf 100]); ylim([-inf inf]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+4); hold on;
plot(array_connRewire_num/array_num_connBack(3)*100,array_SW,'-ok'); drawnow;
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('SW'); xlim([-inf 100]); ylim([-inf inf]); drawnow;

set(0,'CurrentFigure',f)
subplot(length(array_V1),numplot,numplot*(vv-1)+5); hold on;
plot(array_connRewire_num/array_num_connBack(3)*100,array_SW_rand,'-ok'); drawnow;
set(gca, 'XScale', 'log'); set(gca,'TickDir','out'); xlabel('LRC ratio'); ylabel('SW rand'); xlim([-inf 100]); ylim([-inf inf]); drawnow;
end