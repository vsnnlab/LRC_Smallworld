function [SW,SW_rand] = fun_cal_SWindex(array_C,array_L,C_rand,L_rand)
SW1 = (array_C./array_C(end))./(array_L./array_L(end)); 
SW2 = ((array_L-array_L(1))./(array_L(end)-array_L(1))).*((array_C-array_C(end))./(array_C(1)-array_C(end)));

dC = (array_C(1)-array_C)./(array_C(1)-array_C(end));
dL = (array_L-array_L(end))./(array_L(1)-array_L(end));
SW3 = 1-sqrt((dC.^2+dL.^2)./2);


SW1_rand = (array_C./C_rand)./(array_L./L_rand); 
SW2_rand = ((array_L-array_L(1))./(L_rand-array_L(1))).*((array_C-C_rand)./(array_C(1)-C_rand));

dC_rand = (array_C(1)-array_C)./(array_C(1)-C_rand);
dL_rand = (array_L-L_rand)./(array_L(1)-L_rand);
SW3_rand = 1-sqrt((dC_rand.^2+dL_rand.^2)./2);

SW = [SW1, SW2, SW3];
SW_rand = [SW1_rand, SW2_rand, SW3_rand];
end