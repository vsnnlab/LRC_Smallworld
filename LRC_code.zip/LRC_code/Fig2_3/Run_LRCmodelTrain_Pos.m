
clc; clear; %close all;
%% Preprocess
addpath('Run_BioParam'); load('V1size_dim32.mat')
addpath('fun_coreConn'); addpath('fun_coreTrainCustom'); 
addpath('fun_stimulus\MNIST');

nameIMG = 'MNIST_LocGlo';
dirRes = ['Res_',nameIMG]; 
versions = 'version_number';

switch_pdf = 1;
switch_learning = 0;
switch_showTrainCurve = 0;

switch_figure = 0; if switch_figure == 1; numplot = 5; end
switch_figure_IMG = 1;
switch_figureIO = 0;

switch_save = 0; if switch_save == 1; if ~exist(dirRes,'dir'); mkdir(dirRes); end; end

%% Image parameter
dirIMG = 'fun_stimulus\MNIST';

img_dim = 32; % full width or height of a image
reimg_dim = 5; % width or height of small mnist
noise_Back_Amp = 0.00; % Background noise
noise_Digit_cen_p = 0.0;  % Pixel noise at center object
noise_Digit_sur_p = 0.0;  % Pixel noise at surround object
noise_Pos = 0; %  Positional noise
dist_digit = [10];  % distance from center to dot center

x_pos_cen = round((img_dim-reimg_dim)/2); x_pos = x_pos_cen+floor(reimg_dim/2);
y_pos_cen = round((img_dim-reimg_dim)/2); y_pos = y_pos_cen+floor(reimg_dim/2);
dot_size_sur = 3.0;
max_Amp_sur = 0.8;

idx_Loc = [0,1,7,9];

Type_img = 2;
Type_label = Type_img; % 1: local, 2: global, 3: loc & glob
STR_IMG = {'Shape', 'Position', 'Both'};
array_numSubClass = [length(idx_Loc) 4 length(idx_Loc)*4]; %numClasses = array_numSubClass(Type_data);
numTrainPerSubClass = 1000;

%% Image generation
num_Train = numTrainPerSubClass*array_numSubClass(Type_label);
switch Type_img
    case 1
        [IMAGE,LABEL] = fun_LocF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
    case 2
        [IMAGE,LABEL] = fun_GloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
    case 3
         [IMAGE,~,~,LABEL_lg] = fun_LocGloF_revised_DotPos(num_Train,num_Train/5,num_Train/5,...
            img_dim,reimg_dim,idx_Loc,noise_Digit_cen_p,noise_Digit_sur_p,noise_Back_Amp,noise_Pos,dist_digit,x_pos_cen,y_pos_cen,dot_size_sur,max_Amp_sur,dirIMG);
end

if Type_img == 3
    switch Type_label % 1: local, 2: global, 3: loc & glob
        case 1
            XTrain = IMAGE{1,1}; YTrain = LABEL_l{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_l{1,2};
        case 2
            XTrain = IMAGE{1,1}; YTrain = LABEL_g{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_g{1,2};
        case 3
            XTrain = IMAGE{1,1}; YTrain = LABEL_lg{1,1};
            XValid = IMAGE{1,2}; YValid = LABEL_lg{1,2};
    end
else
    XTrain = IMAGE{1,1}; YTrain = LABEL{1,1};
    XValid = IMAGE{1,2}; YValid = LABEL{1,2};
end

classes = categories(YTrain); numClasses = numel(classes);

if switch_figure_IMG == 1
    %visualizing
    figure('units','normalized','outerposition',[0 0 1 1]); sgtitle(STR_IMG{Type_label});
    for c = 1:numClasses
        ind = find(double(YTrain) == c); ind = ind(randperm(length(ind),length(ind)));
        for i = 1:8
            %         iStep = iStep+1;
            subplot(8,numClasses,numClasses*(i-1)+c)
            imagesc(1-XTrain(:,:,:,ind(i))); axis image off; colormap(gray);
        end
    end
end

%% Train parameter
numEpochs = 500;
learnRate = 0.1;
l2Regularization = 0;

miniBatchSizePerClass = 256/4;
miniBatchSize = miniBatchSizePerClass*array_numSubClass(Type_label);
numObservations = numel(YTrain);
numIterationsPerEpoch = floor(numObservations./miniBatchSize);

if switch_save == 1
    dirFoldName = [dirRes,'\Result','_dataType','_',versions]; 
    if ~exist(dirFoldName,'dir'); mkdir(dirFoldName); end
end

if switch_figure == 1; f1 = figure; sgtitle(STR_IMG{Type_label}); set(gcf,'units','normalized','outerposition',[0 0.5 1 0.5]); end
if switch_figureIO == 1; f2 = figure; sgtitle('IO map'); set(gcf,'units','normalized','outerposition',[0 0 1 1]); end

%% Network parameter
Xsize = img_dim; Ysize = img_dim;  % size of image
input_cell_num = Xsize*Ysize;    % # of neuron on the input layer
output_cell_num = numClasses;    % # of neuron on the output layer
convergence_range = 2; convergence_range_RO = 2;
array_phid = [3]; % The number of input to hid connection; very sparse phid=3 -> p_FF=0.07
pout = 0.9999;
weight_init = 0.05;  % std
TT_iter = 1;

threshold_lrc = 10;
threshold_local = 9;
param_pre = [0.2677, 1.4775]; % [0.2677, 1.4775]; % labmda of length distribution
myfun = @(p, x) (p(1)*exp(-p(2)*x));

num_bin_Rewire = 8;
p_lateral = 0.5;

% indV1 = [19]; array_V1 = array_V1_model_dim(indV1); % array_V1_real_size
% indV1 = [5:1:27,28,29]; array_V1 = array_V1_model_dim(indV1); % array_V1_real_size
% indV1 = [1:29]; array_V1 = array_V1_model_dim(indV1); % array_V1_real_size
load('Num_Conn_TreeshrewDist_V1_N100.mat','array_V1_ref','array_num_lateral_V1size');
array_V1 = [32];

%% Network train 
NN = 20;
Cell_LAT_MAT = cell(NN,length(array_V1),num_bin_Rewire); Cell_FF_MAT = cell(NN,length(array_V1),3);
array_conn_num_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3);
array_C_Tot = zeros(NN,length(array_V1),num_bin_Rewire); array_L_Tot = zeros(NN,length(array_V1),num_bin_Rewire);
array_C_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire); array_L_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire);
array_SW_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3); array_SW_rand_Tot = zeros(NN,length(array_V1),num_bin_Rewire,3);
array_accu_Tot = zeros(NN,length(array_V1),num_bin_Rewire);

array_numLat_ori_Tot = zeros(NN,length(array_V1),2); 
for nn = 1:NN
    tic
    disp(['%%% Trial : ',num2str(nn)]); 
    % set trainingOptions
    options = fun_setTrainingOptions(switch_showTrainCurve,learnRate,numEpochs,miniBatchSize,l2Regularization,XValid, YValid,numIterationsPerEpoch);
    
    for vv = 1:length(array_V1)
        disp(['%% V1 : ',num2str(array_V1(vv))])
        array_accu = zeros(num_bin_Rewire,1); array_accuRO = zeros(num_bin_Rewire,output_cell_num);
        array_num_connBack = zeros(1,4); array_num_conn = zeros(num_bin_Rewire,3); 
        array_C = zeros(num_bin_Rewire,1); array_L = zeros(num_bin_Rewire,1);
        MAT_ConnNet = cell(num_bin_Rewire,1); MAT_Tr = cell(num_bin_Rewire,1);
        MAT_ConnFF = cell(3,1); MAT_ConnLAT = cell(num_bin_Rewire,1);
        
        % set FF
        outXsize = array_V1(vv); outYsize = outXsize;
        hidden_cell_num = outXsize*outYsize;   % # of neuron on the hidden layer
        
        init_w0 = randn(input_cell_num,hidden_cell_num).*weight_init;
        init_wlrc = randn(hidden_cell_num,hidden_cell_num).*weight_init;
        init_w1 = randn(hidden_cell_num,hidden_cell_num).*weight_init;
        MAT_ConnW = {init_w0;init_wlrc;init_w1};
        
        num_hid = array_phid(1)*array_V1(vv)^2;
        [connection_FF_origin,connection_FF,connection_RO_origin,connection_RO,connection_RO2] = fun_generate_V1size_divergence_sparse_ConvRO_sel2(input_cell_num,hidden_cell_num,output_cell_num,x_pos,y_pos,...
            convergence_range,convergence_range_RO,num_hid,pout);
        MAT_ConnFF{1} = connection_FF; MAT_ConnFF{2} = connection_RO; MAT_ConnFF{3} = connection_RO2;
        
        % set lateral connectivity
        param_pre_ori = [param_pre(1) 1.4775];
        x_range = [1:ceil(array_V1(vv)*sqrt(2))]; x_range_lrc = [threshold_lrc:ceil(array_V1(vv)*sqrt(2))]; x_range_local = [1:threshold_local]; 
        p_pre = myfun(param_pre_ori,x_range_local./threshold_lrc); p_local = p_pre./sum(p_pre); [param_local, ~] = nlinfit(x_range_local./threshold_lrc,p_local,myfun,param_pre_ori);
%         p_pre = myfun(param_pre,x_range_local./threshold_lrc); p_local = p_pre./sum(p_pre); [param_local, ~] = nlinfit(x_range_local./threshold_lrc,p_local,myfun,param_pre);
        p_pre = myfun(param_pre,x_range_lrc./threshold_lrc); p_lrc = p_pre./sum(p_pre); [param_lrc, ~] = nlinfit(x_range_lrc./threshold_lrc,p_lrc,myfun,param_pre);

        length_matrix_initial = fun_cal_len_LRC(ones(hidden_cell_num,hidden_cell_num),0);
        if switch_pdf == 1
            [connection_local_origin_tmp, connection_lrc_origin_tmp] = fun_generate_Local_LRC_only_Poisson_PDF_revised2(length_matrix_initial,x_range_local,x_range_lrc,param_local,param_lrc,myfun,threshold_lrc,nn);
        else
            [connection_local_origin_tmp, connection_lrc_origin_tmp] = fun_generate_Local_LRC_only_Poisson_Rand_revised2(length_matrix_initial,x_range_local,x_range_lrc,nn);
        end
        indLocal_woNumConst = find(connection_local_origin_tmp); 
        indLRC_woNumConst = find(connection_lrc_origin_tmp); 
        array_numLat_ori_Tot(nn,vv,1) = length(indLocal_woNumConst); array_numLat_ori_Tot(nn,vv,2) = length(indLRC_woNumConst);
        
        % control number of connections
        num_lateral = floor(p_lateral*array_num_lateral_V1size(find(array_V1_ref == array_V1(vv))));
        connection_local_origin = zeros(size(connection_local_origin_tmp)); 
        indLocal_woNumConst = indLocal_woNumConst(randperm(length(indLocal_woNumConst),num_lateral)); connection_local_origin(indLocal_woNumConst) = 1;
        connection_lrc_origin = zeros(size(connection_lrc_origin_tmp)); 
        indLRC_woNumConst = indLRC_woNumConst(randperm(length(indLRC_woNumConst),num_lateral)); connection_lrc_origin(indLRC_woNumConst) = 1;
        indLocal = find(connection_local_origin); indLRC = find(connection_lrc_origin);
        
        array_num_connBack(1) = length(find(connection_FF_origin)); array_num_connBack(2) = length(find(connection_FF));
        array_num_connBack(3) = length(find(connection_local_origin)); array_num_connBack(4) = length(find(connection_RO));
        
        array_connRewire_num_front = logspace(log10(max(num_lateral*0.001,1)),log10(num_lateral*0.1),floor(num_bin_Rewire*0.4));
        array_connRewire_num_back = linspace(num_lateral*0.1,num_lateral-1,num_bin_Rewire-floor(num_bin_Rewire*0.4));
        array_connRewire_num = floor([0, array_connRewire_num_front(1:end-1), array_connRewire_num_back(1:end)]);

        % dis-connected distance at a V1 size 
        tmpD = distance_bin(connection_local_origin); tmpD(isinf(tmpD)) = 0;
        tmp_inf_dist = max(max(tmpD));
%         tmp_inf_dist = inf;

        % rewiring lateral connections
        for ee = 1:length(array_connRewire_num)
            connection_lateral = fun_generate_rewireLateral(array_connRewire_num,MAT_ConnLAT,ee,connection_local_origin,x_range_local,x_range_lrc,indLRC);
            MAT_ConnLAT{ee} = connection_lateral;
            
            conn_len_re = fun_cal_len_LRC(connection_lateral,0);
            array_num_conn(ee,1) = length(find(connection_lateral));
            array_num_conn(ee,2) = length(find((conn_len_re>=x_range_local(1))&(conn_len_re<x_range_local(end))));
            array_num_conn(ee,3) = length(find((conn_len_re>=x_range_lrc(1))&(conn_len_re<x_range_lrc(end))));
            
            array_C(ee) = mean(clustering_coef_bd(connection_lateral));
            tmpD = distance_bin(connection_lateral); tmpD(isinf(distance_bin(connection_lateral))) = tmp_inf_dist;
            array_L(ee) = charpath(tmpD,0,0);

            tic
            % train network
            if (switch_learning==1)&&((e==1)||(e==5))
                L = fun_setLayers(Ysize,Xsize,outYsize,outXsize,numClasses,TT_iter,MAT_ConnW,MAT_ConnFF,MAT_ConnLAT{ee});
                [net_L3lrc,tr_L3lrc] = trainNetwork(XTrain,YTrain,L,options);
                disp(['% 3 layer+LRC ',num2str(array_connRewire_num(ee)/array_num_connBack(3)*100),' accuracy = ',num2str(tr_L3lrc.ValidationAccuracy(end))])
                array_accu(ee,1) = tr_L3lrc.ValidationAccuracy(end);
                array_accuRO(ee,:) = fun_calAccuracyRO(net_L3lrc,XValid,YValid,classes,numClasses);
                MAT_ConnNet{ee} = net_L3lrc; MAT_Tr{ee} = tr_L3lrc;
            end
            toc
            
            % show figures (point)
            if switch_figure == 1
                fun_figAccuConnPoint(f1,array_V1,numplot,vv,ee,array_connRewire_num,array_num_connBack,array_accu(ee),array_C(ee),array_L(ee))
            end
            if (switch_figureIO == 1)&&(nn == 1)
                set(0,'CurrentFigure',f2)
                IOmap = MAT_ConnFF{3}*MAT_ConnFF{2}*(MAT_ConnLAT{ee}*MAT_ConnFF{1}+MAT_ConnFF{1});
                fun_figIO(f2,array_V1,IOmap,nn,vv,ee,array_connRewire_num,array_num_connBack,num_bin_Rewire)
            end
        end
        
        % calculate SW
        connection_lateral_rand = zeros(size(connection_lateral));
        ind_lat_rand = randperm(numel(connection_lateral_rand), length(find(connection_lateral)));connection_lateral_rand(ind_lat_rand) = 1; 
        C_rand = mean(clustering_coef_bd(connection_lateral_rand)); 
        tmpD_rand = distance_bin(connection_lateral_rand); tmpD_rand(isinf(tmpD_rand)) = tmp_inf_dist;
        L_rand = charpath(tmpD_rand,0,0); 
        [array_SW,array_SW_rand] = fun_cal_SWindex(array_C,array_L,C_rand,L_rand);
        
        % show figures (line)
        if switch_figure == 1
            fun_figAccuConnLine(f1,array_V1,numplot,vv,array_connRewire_num,array_num_connBack,array_accu,array_C,array_L,array_SW(:,end),array_SW_rand(:,end))
        end
        
        % save
        if switch_save == 1
            save([dirFoldName,'\Result_V1_',num2str(array_V1(vv)),'_C',num2str(convergence_range),'_hidNum',num2str(array_phid(1)),'_C2',num2str(convergence_range_RO),'_pout',num2str(pout),'_N',num2str(nn),'.mat'],...
                'array_num_conn','array_num_connBack','array_accu','array_accuRO','array_C','array_L','C_rand','L_rand','array_SW','array_SW_rand','-v7.3');
            save([dirFoldName,'\MAT_V1_',num2str(array_V1(vv)),'_C',num2str(convergence_range),'_hidNum',num2str(array_phid(1)),'_C2',num2str(convergence_range_RO),'_pout',num2str(pout),'_N',num2str(nn),'.mat'],...
                'MAT_ConnW','MAT_ConnFF','MAT_ConnLAT','MAT_ConnNet','MAT_Tr','-v7.3');
        end
        
        Cell_FF_MAT(nn,vv,:) = MAT_ConnFF;
        Cell_LAT_MAT(nn,vv,:) = MAT_ConnLAT; array_conn_num_Tot(nn,vv,:,:) = array_num_conn;
        array_C_Tot(nn,vv,:) = array_C; array_L_Tot(nn,vv,:) = array_L; array_C_rand_Tot(nn,vv,:) = C_rand; array_L_rand_Tot(nn,vv,:) = L_rand;
        array_SW_Tot(nn,vv,:,:) = array_SW; array_SW_rand_Tot(nn,vv,:,:) = array_SW_rand;
        
        array_accu_Tot(nn,vv,:) = array_accu;
    end
    toc
end
if switch_save == 1
    save([dirFoldName,'\Result_V1_',num2str(array_V1(vv)),'_C',num2str(convergence_range),'_hidNum',num2str(array_phid(1)),'_C2',num2str(convergence_range_RO),'_pout',num2str(pout),'_All.mat'],...
                'Cell_LAT_MAT','Cell_FF_MAT','array_conn_num_Tot','array_C_Tot','array_L_Tot','array_C_rand_Tot','array_L_rand_Tot','array_SW_Tot','array_SW_rand_Tot','array_accu_Tot','-v7.3');
end

% %% Result
% indNN = NN; indV1 = 1; 
% array_LRCratio = array_conn_num_Tot(1:indNN,:,:,3)./array_conn_num_Tot(1:indNN,:,:,1).*100;
% 
% % number of connections
% figure; hold on; %set(gca, 'XScale', 'log')
% errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),mean(squeeze(array_conn_num_Tot(1:indNN,indV1,:,1)),1),std(squeeze(array_conn_num_Tot(1:indNN,indV1,:,1)),1),'--k')
% errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),mean(squeeze(array_conn_num_Tot(1:indNN,indV1,:,2)),1),std(squeeze(array_conn_num_Tot(1:indNN,indV1,:,2)),1),'b')
% errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),mean(squeeze(array_conn_num_Tot(1:indNN,indV1,:,3)),1),std(squeeze(array_conn_num_Tot(1:indNN,indV1,:,3)),1),'r')
% title(['V1 size = ', num2str(array_V1(indV1)), ' p = ',num2str(p_lateral)])
% % ylim([0 1.3e4]); %xlim([1e-2 1e2]); 
% 
% % length distribution
% figure; set(gcf,'units','normalized','outerposition',[0 0.5 1 0.5]);
% for vv = 1:length(array_V1)
%     x_range = [1:floor(array_V1(vv)*sqrt(2))];
%     for ee = 1:num_bin_Rewire
%         subplot(length(array_V1),num_bin_Rewire,ee+(vv-1)*num_bin_Rewire)
%         conn_len_tmp = fun_cal_len_LRC(Cell_LAT_MAT{1,vv,ee},0);
%         histogram(conn_len_tmp(conn_len_tmp>0),x_range,'normalization','probability'); xlim([0 45]); ylim([0 0.6]);
% %         histogram(conn_len_tmp(conn_len_tmp>0),x_range); xlim([0 45]); ylim([0 3000]);
%         if vv == 1; title([num2str(array_connRewire_num(ee)./num_lateral.*100),' %']); end
%     end
% end
% 
% % IO map
% idx_ro = 4;
% figure; set(gcf,'units','normalized','outerposition',[0 0 1 0.5]);
% for vv = 1:length(array_V1)
%     x_range = [1:floor(array_V1(vv)*sqrt(2))];
%     for ee = 1:num_bin_Rewire
%         subplot(length(array_V1),num_bin_Rewire,ee+(vv-1)*num_bin_Rewire)
%         IOmap = Cell_FF_MAT{1,vv,3}*Cell_FF_MAT{1,vv,2}*(Cell_LAT_MAT{1,vv,ee}*Cell_FF_MAT{1,vv,1}+Cell_FF_MAT{1,vv,1});
%         imagesc(reshape(IOmap(idx_ro,:),[sqrt(size(IOmap,2)) sqrt(size(IOmap,2))])); axis image off; caxis([0 5]); drawnow;
%         if vv == 1; title([num2str(array_connRewire_num(ee)./num_lateral.*100),' %']); end
%     end
% end
% 
% % network index 
% indSW = 3;  x_axis_lim = [5*1e-2 1.5*1e2];
% figure; set(gcf,'units','normalized','outerposition',[0 0 1 1]);
% for vv = 1:length(array_V1)
%     indV1 = vv;
%     subplot(3,length(array_V1),vv); hold on; set(gca, 'XScale', 'log'); xlim([x_axis_lim(1) x_axis_lim(2)])
%     % errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(array_C_Tot(1:indNN,indV1,:)./array_C_Tot(1:indNN,indV1,1),1)),squeeze(std(array_C_Tot(1:indNN,indV1,:)./array_C_Tot(1:indNN,indV1,1),1)),'-ok'); xlabel('LRC ratio'); ylabel('C')
%     errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(array_C_Tot(1:indNN,indV1,:),1)),squeeze(std(array_C_Tot(1:indNN,indV1,:),1)),'-ok'); xlabel('LRC ratio'); ylabel('C')
%     errorbar(x_axis_lim(1),squeeze(mean(array_C_Tot(1:indNN,indV1,1),1)),squeeze(std(array_C_Tot(1:indNN,indV1,1),1)),'-ok'); xlabel('LRC ratio'); ylabel('C')
%     title(['V1 size = ', num2str(array_V1(indV1)), ' p = ',num2str(p_lateral)])
% 
%     subplot(3,length(array_V1),vv+length(array_V1)); hold on; set(gca, 'XScale', 'log'); xlim([x_axis_lim(1) x_axis_lim(2)])
%     % errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(1./(array_L_Tot(1:indNN,indV1,:)./array_L_Tot(1:indNN,indV1,end)),1)),squeeze(std(1./(array_L_Tot(1:indNN,indV1,:)./array_L_Tot(1:indNN,indV1,end)),1)),'-ok'); xlabel('LRC ratio'); ylabel('1/L')
%     errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(1./(array_L_Tot(1:indNN,indV1,:)),1)),squeeze(std(1./(array_L_Tot(1:indNN,indV1,:)),1)),'-ok'); xlabel('LRC ratio'); ylabel('1/L')
%     errorbar(x_axis_lim(1),squeeze(mean(1./(array_L_Tot(1:indNN,indV1,1)),1)),squeeze(std(1./(array_L_Tot(1:indNN,indV1,1)),1)),'-ok'); xlabel('LRC ratio'); ylabel('1/L')
% 
%     % errorbar(mean(array_LRCratio,1),squeeze(mean((array_L_Tot(1:indNN,indV1,:)./array_L_Tot(1:indNN,indV1,1)),1)),squeeze(std((array_L_Tot(1:indNN,indV1,:)./array_L_Tot(1:indNN,indV1,1)),1)),'-ok'); xlabel('LRC ratio'); ylabel('L')
%     % errorbar(mean(array_LRCratio,1),squeeze(mean((array_L_Tot(1:indNN,indV1,:)),1)),squeeze(std((array_L_Tot(1:indNN,indV1,:)),1)),'-ok'); xlabel('LRC ratio'); ylabel('L')
%     
%     subplot(3,length(array_V1),vv+2*length(array_V1)); hold on; set(gca, 'XScale', 'log'); xlim([x_axis_lim(1) x_axis_lim(2)])
% %     errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(array_SW_Tot(1:indNN,indV1,:,indSW),1)),squeeze(std(array_SW_Tot(1:indNN,indV1,:,indSW),1)),'-ok'); xlabel('LRC ratio'); ylabel('SW')
% %     errorbar(x_axis_lim(1),squeeze(mean(array_SW_Tot(1:indNN,indV1,1,indSW),1)),squeeze(std(array_SW_Tot(1:indNN,indV1,1,indSW),1)),'-ok'); xlabel('LRC ratio'); ylabel('SW')
%     errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(array_SW_rand_Tot(1:indNN,indV1,:,indSW),1)),squeeze(std(array_SW_rand_Tot(1:indNN,indV1,:,indSW),1)),'-ok'); xlabel('LRC ratio'); ylabel('SW')
%     errorbar(x_axis_lim(1),squeeze(mean(array_SW_rand_Tot(1:indNN,indV1,1,indSW),1)),squeeze(std(array_SW_rand_Tot(1:indNN,indV1,1,indSW),1)),'-ok'); xlabel('LRC ratio'); ylabel('SW')
% end
% 
% % network accuracy, correlation
% indSW = 3;  x_axis_lim = [5*1e-2 1.5*1e2];
% figure; set(gcf,'units','normalized','outerposition',[0 0 1 1]);
% for vv = 1:length(array_V1)
%     indV1 = vv;
%     subplot(4,length(array_V1),vv); hold on; set(gca, 'XScale', 'log'); xlim([x_axis_lim(1) x_axis_lim(2)])
%     errorbar(mean(squeeze(array_LRCratio(:,indV1,:)),1),squeeze(mean(array_accu_Tot(1:indNN,indV1,:),1)),squeeze(std(array_accu_Tot(1:indNN,indV1,:),1)),'-or'); xlabel('LRC ratio'); ylabel('accuracy')
%     title(['V1 size = ', num2str(array_V1(indV1)), ' p = ',num2str(p_lateral)])
%     
%     subplot(4,length(array_V1),vv+length(array_V1)); hold on;
%     X = squeeze(array_C_Tot(1:indNN,indV1,:)); %X = X(:);
%     Y = squeeze(array_accu_Tot(1:indNN,indV1,:)); %Y = Y(:);
%     scatter(X,Y,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); xlabel('C'); ylabel('accuracy')
%     for ee = 1:num_bin_Rewire
%         meanX = mean(squeeze(array_C_Tot(1:indNN,indV1,ee))); stdX = std(squeeze(array_C_Tot(1:indNN,indV1,ee)));
%         meanY = mean(squeeze(array_accu_Tot(1:indNN,indV1,ee))); stdY = std(squeeze(array_accu_Tot(1:indNN,indV1,ee)));
%         errorbar(meanX,meanY,stdY,stdY,stdX,stdX,'ok','MarkerFaceColor',[0 0 0])
%     end
%     [r,p] = corrcoef(mean(X,1),mean(Y,1));
%     title(['r = ',num2str(r(1,2)),', p = ',num2str(p(1,2))])
%     
%     subplot(4,length(array_V1),vv+2*length(array_V1)); hold on;
%     X = squeeze(1./array_L_Tot(1:indNN,indV1,:)); %X = X(:);
%     Y = squeeze(array_accu_Tot(1:indNN,indV1,:)); %Y = Y(:);
%     scatter(X,Y,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); xlabel('1/L'); ylabel('accuracy')
%     for ee = 1:num_bin_Rewire
%         meanX = mean(squeeze(1./array_L_Tot(1:indNN,indV1,ee))); stdX = std(squeeze(1./array_L_Tot(1:indNN,indV1,ee)));
%         meanY = mean(squeeze(array_accu_Tot(1:indNN,indV1,ee))); stdY = std(squeeze(array_accu_Tot(1:indNN,indV1,ee)));
%         errorbar(meanX,meanY,stdY,stdY,stdX,stdX,'ok','MarkerFaceColor',[0 0 0])
%     end
%     [r,p] = corrcoef(mean(X,1),mean(Y,1));
%     title(['r = ',num2str(r(1,2)),', p = ',num2str(p(1,2))])
%     
%     
%     subplot(4,length(array_V1),vv+3*length(array_V1)); hold on;
%     X = squeeze(array_SW_rand_Tot(1:indNN,indV1,:,indSW)); %Y = Y(:);
%     Y = squeeze(array_accu_Tot(1:indNN,indV1,:)); %Y = Y(:);
%     scatter(X,Y,'filled','MarkerEdgeColor','none','MarkerFaceColor',[0.5,0.5,0.5]); xlabel('SW'); ylabel('accuracy')
%     for ee = 1:num_bin_Rewire
%         meanX = mean(squeeze(array_SW_rand_Tot(1:indNN,indV1,ee,indSW))); stdX = std(squeeze(array_SW_rand_Tot(1:indNN,indV1,ee,indSW)));
%         meanY = mean(squeeze(array_accu_Tot(1:indNN,indV1,ee))); stdY = std(squeeze(array_accu_Tot(1:indNN,indV1,ee)));
%         errorbar(meanX,meanY,stdY,stdY,stdX,stdX,'ok','MarkerFaceColor',[0 0 0])
%     end
%     [r,p] = corrcoef(mean(X,1),mean(Y,1));
%     title(['r = ',num2str(r(1,2)),', p = ',num2str(p(1,2))])
% end