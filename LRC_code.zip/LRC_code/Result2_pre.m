%% Result 2 : Long-Range Connections Integrate Global Features (Figure 3)


%% Classification performance for each dataset with a variation of the LRC ratio (Figure 3c)
disp('=================================================================')
disp('Result2 : Accuracy for ''Shape'',''Position'',''Shape Position''')
disp('=================================================================')
%% Set parameter 

MaxEpoch = 2000;
img_str = {'Shape','Position','Shape-Position'};
load('pretrainedNet\Result2\array_rewiring_accu_trial.mat')

%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
sgtitle({'Classification accuracy for each datasets';'with variation of LRC ratios (Figure 3c)'},'FontSize',fontSize_title) 
subplot(1,3,1)
hold on
bar([1],array_rewiring_accu_trial(1,1,1,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,1,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,1,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)

subplot(1,3,2)
hold on
bar([1],array_rewiring_accu_trial(1,1,2,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,2,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,2,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)

subplot(1,3,3)
hold on
bar([1],array_rewiring_accu_trial(1,1,3,end),'FaceColor','k')
bar([2],array_rewiring_accu_trial(1,2,3,end),'FaceColor','b')
bar([3],array_rewiring_accu_trial(1,3,3,end),'FaceColor','r')
ylim([20 90]); xticks([1:3]); xlim([0.5 3.5]); xticklabels(img_str); xtickangle(45)

