%% Result 3 : Long-Range Connections for Balancing Performance and Wiring Cost (Figure 4)

%% Generate dataset
if ~exist('IMAGE_nat')
    tic
    disp('generating gray-scale CIFAR-10 ...(~ 1 min)')
    img_dim = x_dim;
    [IMAGE_nat,LABEL_nat] = fun_generate_grayCIFAR10(img_dim,numTrain_nat);
    toc
end

%% Show dataset
disp('Showing stimulus (Classs X Examples) ... (~ 2 sec)')
tic
imagesPerClass = 5;
imagesInMontage = cell(imagesPerClass,numClass_mod);
img = IMAGE_nat{1,1}; lab = LABEL_nat{1,1};

figure('units','normalized','outerposition',[0 0 0.5 1])
for cc = 1:numClass_nat
    idx = find(double(lab) == cc);
    ind_pick = idx(randperm(length(idx),imagesPerClass));
    
    for ii = 1:imagesPerClass
        subplot(numClass_nat,imagesPerClass,ii+(cc-1)*imagesPerClass)
        imshow(img(:,:,1,ind_pick(ii)))
    end
end
sgtitle('Grayscale CIFAR-10','FontSize',15)
toc
% ============================================================================================================

%% Changes of classification accuracy and the total connection length during the training (Figure 4b)
%% The ratio of LRCs converged to the nonzero value (red curve) with length penalty. (Figure 4d)
disp('=================================================================')
disp('Result3 : LRCs for balancing performance and wiring cost')
disp('=================================================================')
%% Set parameter 
output_cell_num_nat = numClass_nat;

MaxEpoch = 3000;
MiniBatchSize = 1000;
Valid_f = numTrain_nat/MiniBatchSize;
array_penalty_lambda = [0 1e-3];
array_penalty_accu_trial = zeros(N_trial,length(array_penalty_lambda),MaxEpoch+1);

%% Generate model & Train networks
disp('Generate model & Train networks...');
curr_path = strcat(pwd,'\MyCheckpoint');
for nn = 1:N_trial
    disp(['%% Trial : ',num2str(nn)]);
    
    ori_weight_w0 = (randn(hidden_cell_num, input_cell_num) * 0.05);
    ori_weight_wh = (randn(hidden_cell_num, hidden_cell_num) * 1);
    ori_weight_w1 = (randn(output_cell_num_nat, hidden_cell_num) * 0.05);
    
    p_lateral = 0.5;
    [connection_w0, connection_w0_len,...
        connection_lrc, connection_lrc_len, ~, ~,...
        connection_w1, ~] = fun_generate_conn_conv_addLRC_SRC_random(input_cell_num, hidden_cell_num, output_cell_num_nat,...
        convergence_range,V1_dim,...
        p_lateral,threshold_lrc,1);
    
    for ll = 1:length(array_penalty_lambda)
        disp(['length penalty = ',num2str(array_penalty_lambda(ll))]);
        
        total_norm = norm(connection_w0_len) + norm(connection_lrc_len);
        MAT_conn = {connection_w0,connection_lrc,connection_w1,total_norm};
        save('connectivity.mat','MAT_conn');
        
        layers = [...
            imageInputLayer([y_dim x_dim 1],'Normalization','none') % Normalization -> zerocenter
            
            fullyConnectedLayer(hidden_cell_num)
            
            fullyConnectedLayer(hidden_cell_num)
            reluLayer
            
            fullyConnectedLayer(output_cell_num_nat)
            softmaxLayer
            classificationLayer];
        layers(2).Weights = (ori_weight_w0).*connection_w0;
        layers(3).Weights = (ori_weight_wh).*(connection_lrc + diag(ones(1,hidden_cell_num)));
        layers(5).Weights = (ori_weight_w1).*connection_w1;
        
        new_dir = strcat('LRC_len_',num2str(array_penalty_lambda(ll)),'trial_',num2str(nn));
        mkdir(strcat('MyCheckpoint','LRC_len_',num2str(array_penalty_lambda(ll)),'trial_',num2str(nn)));
        
        dirr = strcat(curr_path,new_dir);
        opts = trainingOptions2('sgdm_conv3_LRC',...
            'MaxEpochs',MaxEpoch,'MiniBatchSize',MiniBatchSize,'Shuffle','every-epoch',...
            'ValidationData',{IMAGE_nat{1,2},LABEL_nat{1,2}},'ValidationFrequency',Valid_f,'ValidationPatience',Inf,... % early stopping
            'InitialLearnRate',0.1,...
            'L2Regularization',array_penalty_lambda(ll),'Momentum',0,...
            'CheckpointPath',dirr ,... % save network as mat file after each epoch
            'ExecutionEnvironment',enVirn,...
            'Verbose',false);
        
        [net, tr] = trainNetwork2(IMAGE_nat{1,1},LABEL_nat{1,1},layers,opts);
        ind = [1 opts.ValidationFrequency:opts.ValidationFrequency:Valid_f*MaxEpoch];
        array_va_iter = tr.ValidationAccuracy; array_va_epoch = array_va_iter(ind);
        array_penalty_accu_trial(nn,ll,:) = array_va_epoch;
        disp(['Accuracy : ',num2str(array_va_epoch(end))]);
    end
end

disp('Connectivity analysis...');
dd = 1;
weight_thr = 1e-2;
array_TotLength_trial = zeros(2,N_trial,length(image_str),length(array_penalty_lambda),MaxEpoch);
array_num_LatConn_trial = zeros(2,N_trial,length(image_str),length(array_penalty_lambda),MaxEpoch);

for nn = 1:N_trial
    disp(['Trial : ',num2str(nn)]);
    for ll = 1:length(array_penalty_lambda)
        disp(['lambda = ',num2str(array_penalty_lambda(ll))]);
        new_dir = strcat('LRC_len_',lambda_str{ll},'trial_',num2str(nn));
        dirr = strcat(curr_path,new_dir);
        list = dir(dirr);
        
        for ee = 1:MaxEpoch
%             if mod(ee,100) == 0
%                 disp(['%%',num2str(ee)])
%             end
            
            ind = 2+ee;
            dir_name = list(ind).name;
            temp_list = split(dir_name,'__');
            load(strcat(dirr,'\',dir_name))
            
            temp_input_mat = fun_cal_len_input(net.Layers(2).Weights,weight_thr);
            temp_lateral_mat = fun_cal_len_LRC(net.Layers(3).Weights,weight_thr);
            
            % # of conn
            array_num_LatConn_trial(1,nn,ll,round(str2double(temp_list{2})/Valid_f)) = length(find(temp_lateral_mat>threshold_lrc));
            array_num_LatConn_trial(2,nn,ll,round(str2double(temp_list{2})/Valid_f)) = length(find((temp_lateral_mat<=threshold_lrc)&(temp_lateral_mat>0)));
            
            % length
            array_TotLength_trial(1,nn,ll,round(str2double(temp_list{2})/Valid_f)) = sum(sum(temp_input_mat,1),2);
            array_TotLength_trial(2,nn,ll,round(str2double(temp_list{2})/Valid_f)) = sum(sum(temp_lateral_mat,1),2);
        end
    end
end

%% Plot figure
fontSize_label = 14; fontSize_title = 15; fontSize_legend = 12;
pixel2mm = 0.1;
figure('units','normalized','outerposition',[0 0 0.5 1])
sgtitle({'Changes of accuracy and the lateral connection length';'during the training (Figure 4b)'},'FontSize',fontSize_title) 
subplot(2,1,1)
hold on
plot(0:MaxEpoch,squeeze(array_penalty_accu_trial(1,1,:)),'-k','linewidth',3)
plot(0:MaxEpoch,squeeze(array_penalty_accu_trial(1,2,:)),'-r','linewidth',3)
ylim([10 40]); xlim([0 3000]);
ylabel('Accuracy (%)','FontSize',fontSize_label)
legend('No length penalty','Length penalty','fontsize',fontSize_legend,'Location','southeast')
subplot(2,1,2)
hold on
plot(1:MaxEpoch,squeeze(sum(array_TotLength_trial(2,1,1,:),1)).*pixel2mm,'-k','linewidth',3)
plot(1:MaxEpoch,squeeze(sum(array_TotLength_trial(2,1,2,:),1)).*pixel2mm,'-r','linewidth',3)
xlim([0 3000]);
ylabel('Total length (mm)','FontSize',fontSize_label)
xlabel('Training epoch','FontSize',fontSize_label)


figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Change of ratio of LRCs';'during the training with length penalty (Figure 4d)'},'FontSize',fontSize_title) 
hold on
plot(1:MaxEpoch,squeeze(array_num_LatConn_trial(1,1,2,:))./squeeze(sum(array_num_LatConn_trial(:,1,2,:),1)),'-r','linewidth',3)  
ylabel('LRC ratio (LRCs/All lateral)','fontsize',fontSize_label)
xlabel('Training epoch','FontSize',fontSize_label)

