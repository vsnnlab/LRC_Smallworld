%% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)

%% Generate dataset
if ~exist('IMAGE_mod')
    tic
    disp('generating modified MNIST ...(~ 30 sec)')

    [IMAGE_mod,LABEL_mod] = fun_generate_mMNIST(numTrain_mod);
    toc
end

%% Show dataset
ind_img = 3;
disp('Showing stimulus (Classs X Examples) ... (~ 2 sec)')
tic
imagesPerClass = 5;
imagesInMontage = cell(imagesPerClass,numClass_mod);
img = IMAGE_mod{ind_img,1}; lab = LABEL_mod{ind_img,1};

figure('units','normalized','outerposition',[0 0 0.5 1])
for cc = 1:numClass_mod
    idx = find(double(lab) == cc);
    ind_pick = idx(randperm(length(idx),imagesPerClass));
    
    for ii = 1:imagesPerClass
        subplot(numClass_mod,imagesPerClass,ii+(cc-1)*imagesPerClass)
        imshow(1-img(:,:,1,ind_pick(ii)))
    end
end
sgtitle('Modified MNIST - Type 3 : Shape-position','FontSize',15)
toc

% ============================================================================================================

%% Add LRC vs Add Local & Fully-connected networks (Figure 2d)
disp('=================================================================')
disp('Result1_1 : Add LRC vs Add Local & Fully-connected networks')
disp('=================================================================')
%% Set parameter 
output_cell_num_mod = numClass_mod;

MaxEpoch = 2000;
MiniBatchSize = 1000;
Valid_f = numTrain_mod/MiniBatchSize;
array_penalty_lambda = [0];
conn_str = {'FF','LRC','Local','FC'};
edge = [1:40];

ind_img = 3;

array_conn_num = [1*1e+1 1*1e+2 1*1e+3 1*1e+4 2*1e+4 4*1e+4 8*1e+4]; 
array_addconn_accu_trial = zeros(N_trial,length(conn_str),length(array_conn_num),MaxEpoch+1);

%% Generate model & Train networks
disp('Generate model & Train networks...');
for nn = 1:N_trial
    disp(['%% Trial : ',num2str(nn)]);
    
    ori_weight_w0 = (randn(hidden_cell_num, input_cell_num) * 0.05);
    ori_weight_wh = (randn(hidden_cell_num, hidden_cell_num) * 1);
    ori_weight_w1 = (randn(output_cell_num_mod, hidden_cell_num) * 0.05);
    
    [connection_w0_ori, ~, ...
        ~,~,~,~,...
        connection_w1,~] = fun_generate_conn_conv_rewireLRC_SRC_LSp(input_cell_num,hidden_cell_num,output_cell_num_mod,...
        convergence_range,3,V1_dim,...
        0,threshold_lrc,...
        p_total_conn,1);
    
    for cc = 1:length(conn_str)
        disp(['addconn conn type : ',conn_str{cc}]);
        switch cc
            case 1
                ind_connRange = 2; ind_pdf = 2; ind_addconn = 1;
            case 2
                ind_connRange = 2; ind_pdf = 2; ind_addconn = length(array_conn_num);
            case 3
                ind_connRange = 3; ind_pdf = 2; ind_addconn = length(array_conn_num);
            case 4
                ind_connRange = 1; ind_pdf = 2; ind_addconn = 1;
        end
        y = fun_generate_connRange_pdf2(ind_connRange,ind_pdf,edge,convergence_range);
        
        for ll = 1:length(array_conn_num(1:ind_addconn))
            switch cc
                case 1
                    p_lateral = 0;
                case 4
                    p_lateral = 2*1e+6;
                otherwise
                    p_lateral = array_conn_num(ll);
            end
            disp(['# of conn : ',num2str(p_lateral)]);
            addNumLength = floor(y.*p_lateral);
            connection_lrc = fun_add_Lateral_pdf(length_matrix,addNumLength);

            connection_w0 = connection_w0_ori;

            MAT_conn = {connection_w0,connection_lrc,connection_w1,0};
            save('connectivity.mat','MAT_conn');

            layers = [...
                imageInputLayer([x_dim y_dim 1],'Normalization','none') % Normalization -> zerocenter
                
                fullyConnectedLayer(hidden_cell_num)
                
                fullyConnectedLayer(hidden_cell_num)
                reluLayer
                
                fullyConnectedLayer(output_cell_num_mod)
                softmaxLayer
                classificationLayer];
            layers(2).Weights = (ori_weight_w0).*connection_w0;
            layers(3).Weights = (ori_weight_wh).*(connection_lrc + diag(ones(1,hidden_cell_num)));
            layers(5).Weights = (ori_weight_w1).*connection_w1;
            
            opts = trainingOptions2('sgdm_conv3_LRC',...
                'MaxEpochs',MaxEpoch,'MiniBatchSize',MiniBatchSize,'Shuffle','every-epoch',...
                'ValidationData',{IMAGE_mod{ind_img,2},LABEL_mod{ind_img,2}},'ValidationFrequency',Valid_f,'ValidationPatience',Inf,... % early stopping
                'InitialLearnRate',0.1,...
                'L2Regularization',array_penalty_lambda(1),'Momentum',0,...
                'ExecutionEnvironment',enVirn,...
                'Verbose',false);

            [net, tr] = trainNetwork2(IMAGE_mod{ind_img,1},LABEL_mod{ind_img,1},layers,opts);

            ind = [1 opts.ValidationFrequency:opts.ValidationFrequency:Valid_f*MaxEpoch];
            array_va_iter = tr.ValidationAccuracy; array_va_epoch = array_va_iter(ind);
            
            array_addconn_accu_trial(nn,cc,ll,:) = array_va_epoch;
            disp(['Accuracy : ',num2str(array_va_epoch(end))]);
        end
    end
end


%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Classification accuracy of networks'; 'with various types of lateral connections (Figure 2d)'},'FontSize',fontSize_title) 
hold on
line([0 array_conn_num(end)],[array_addconn_accu_trial(1,1,1,end) array_addconn_accu_trial(1,1,1,end)],'Color','k','LineStyle',':');
line([0 array_conn_num(end)],[array_addconn_accu_trial(1,4,1,end) array_addconn_accu_trial(1,4,1,end)],'Color','k','LineStyle','--');
plot([0,array_conn_num],[squeeze(array_addconn_accu_trial(1,1,1,end)) squeeze(array_addconn_accu_trial(1,2,:,end))'],'r','linewidth',3);
plot([0,array_conn_num],[squeeze(array_addconn_accu_trial(1,1,1,end)) squeeze(array_addconn_accu_trial(1,3,:,end))'],'k','linewidth',3);
xlim([0 8*1e+4]); ylim([20 90]) 
xlabel('Number of lateral connections added (count)','FontSize',fontSize_label)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)
legend('FF only','FF','FF+LRC','FF+Local','fontsize',fontSize_legend,'Location','southeast')
