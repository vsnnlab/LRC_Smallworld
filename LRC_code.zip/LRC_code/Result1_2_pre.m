%% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)
% ============================================================================================================

%% Add LRC vs Add Layers (Figure 2g)
disp('=================================================================')
disp('Result1_2 : Add LRC vs Add Layers')
disp('=================================================================')
%% Set parameter 
MaxEpoch = 2000;
load('pretrainedNet\Result1_2\array_addlayer_accu_trial.mat')

%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Classification accuracy of networks'; 'with various types of hierachical structures (Figure 2g)'},'FontSize',fontSize_title) 
hold on
plot(0:MaxEpoch,squeeze(array_addconn_accu_trial(1,1,1,:)),'k','linewidth',3)
plot(0:MaxEpoch,squeeze(array_addconn_accu_trial(1,2,find(array_conn_num == 1e+4),:)),'r','linewidth',3)
plot(0:MaxEpoch,squeeze(array_addlayer_accu_trial(1,1,:)),'b','linewidth',3);
plot(0:MaxEpoch,squeeze(array_addlayer_accu_trial(1,2,:)),'color',[0 0.9 0.9],'linewidth',3);
xlim([0 MaxEpoch]); xticks([0:500:MaxEpoch]); ylim([10 90]) 
xlabel('Training epoch','FontSize',fontSize_label)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)
legend('3layer','3layer + LRC','4layer','5layer','FontSize',fontSize_legend,'Location','southeast')
