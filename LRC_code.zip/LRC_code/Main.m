%% Demo code ver. 02/17/2020
%=============================================================================================================
% A brain-inspired architecture for cost-efficient object recognition in shallow neural networks

% Prerequirement 
% 1) MATLAB 2018b or later version is recommended.
% 2) Install deeplearning toolbox.

% Installation (link : https://doi.org/10.5281/zenodo.3668670 )
% 1) Download "LRC_021820.zip" and unzip the file.
% 2) Download "DATASET_ori.zip","pretrainedNet.zip" and unzip on same file.
% 3) Choose the proper subfolder of 'fun_modifed_toolbox' which is match to your matlab version and
%    Move each files to proper directory
% 4) By running "Main.m" and selecting figure option (see line 33 on the Main.m)
%
% Output of the code
% 1) Result1 : Accuracy of the networks - FF vs FF+Local vs FF+LRC vs FC (Figure 2d)
%            : Accuracy of the networks - 3layer vs 3layer+LRC vs 4layer vs 5layer (Figure 2g)                                      
% 3) Result2 : Accuracy for each dataset with a variation of the LRC ratio - LRC ratio 0%, 20%, 97% (Figure 3c) 
% 4) Result3 : Accuracy and total connection length during the training - w/ and w/o length penalty (Figure 3b) 
%            : The ratio of LRCs during the training (Figure 3d) 
%=============================================================================================================

close all;clc;clear;
rng('default')                                              % fixed random seed for regenerating same result
Release = toolbox_chk;                                      % checking matlab version and toolbox

% ============================================================================================================
flg_ShowRes = 0;                                            % flg_ShowRes = 1 : Show the result figure of demo code using a randomly initialized network
flg_Demo = 1;                                               % flg_Demo = 1 : Run the demo code using a randomly initialized network
                                                            % flg_Demo = 0 : Do not run the demo code
flg1 = 1; flg2 = 0; flg3 = 0;                               % flg1 : flag of code for Result1 / flg1 : flag of code for Result2 / flg1 : flag of code for Result3

% ============================================================================================================
%% Show pretrained result 
% Show the result figure of demo code using a randomly initialized network without training
tic
if flg_ShowRes ~= 0
    disp('=================================================================')
    disp('Show pretrained result')
    disp('=================================================================')
    addpath('pretrainedNet');
    if flg1+flg2+flg3 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Step 1. Loading the original image dataset
        disp('%% STEP 1 : Downloading the original dataset ')
        disp(['Download the pretrained data from ... '])
        disp('<a href = "https://doi.org/10.5281/zenodo.3668670">https://doi.org/10.5281/zenodo.3668670</a>')
        % Download 'DATASET_ori.zip' and upzip in the same directory
        % (link : https://zenodo.org/deposit?page=1&size=20)
        % contents : pretrained network (e.g. net_LRC_...mat)
        %          : result matrix (e.g. array_..._accu_trial.mat)
        if ~exist('pretrainedNet')
             warning('pretrainedNet must be downloaded and unziped in the same directory')
        end
        
        if flg1 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)
            disp('Result 1 ... (~ 1 h)')
            tic
            Result1_1_pre;                                                % code for Figure 2d : accuracy of the networks - FF vs FF+Local vs FF+LRC vs FC
            Result1_2_pre;                                                % code for Figure 2g : accuracy of the networks - 3layer vs 3layer+LRC vs 4layer vs 5layer
            toc
        end
        
        if flg2 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 2 : Long-Range Connections Integrate Global Features (Figure 3)
            disp(['Result 2... (~ 30 min)'])
            tic
            Result2_pre;                                                  % code for Figure 3b : accuracy for each dataset with a variation of the LRC ratio
            toc
        end
        
        if flg3 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 3 : Long-Range Connections for Balancing Performance and Wiring Cost (Figure 4)
            disp(['Result 3...(~ 1 min)'])
            tic
            Result3_pre;                                                  % code for Figure 4b,d : Accuracy, total connection length and LRC ratio during the training
            toc
        end
        
    end
end

%% Demo code
tic
if flg_Demo ~= 0
    disp('=================================================================')
    disp('Demo trial')
    disp('=================================================================')
    addpath('fun_genDATASET'); addpath('fun_coreFunc');
    if flg1+flg2+flg3 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %% Step 0. Setting the environment
        disp('%% STEP 0 : Setting the enviroment')
        disp(['choose ',Release,' subfolder of ''fun_modifed_toolbox'' and move each files to proper directory'])
        % 1) check your matlab release version
        % 2) choose the proper subfolder of fun_modifed_toolbox which is match to your matlab version
        % 3) move each files to proper directory
        % (see the comment in line 4 of each file for proper directory  e.g. 'dir = C:\Program Files\MATLAB\...')
        
        %% Step 1. Loading the original image dataset
        disp('%% STEP 1 : Downloading the original dataset ')
        disp(['Download the original dataset from ... '])
        disp('<a href = "https://doi.org/10.5281/zenodo.3668670">https://doi.org/10.5281/zenodo.3668670</a>')
        % Download 'DATASET_ori.zip' and upzip in the same directory
        % (link : https://zenodo.org/deposit?page=1&size=20)
        % contents : MNIST (http://yann.lecun.com/exdb/mnist/)
        %          : CIFAR10 (https://www.cs.toronto.edu/~kriz/cifar.html)
        
        if ~exist('DATASET_ori')
             warning('DATASET_ori must be downloaded and unziped in the same directory')
        end
        
        %% Step 2. Setting the parameter
        N_trial = 1;                                                       % # of trail
        
        enVirn = 'auto';                                                   % execution environment
                                                                           %- 'auto' - (default) Use a GPU if it is available, otherwise use the CPU.
                                                                           %- 'gpu' - Use the GPU.
                                                                           %- 'cpu' - Use the CPU.
                                                                           %- 'multi-gpu' - Use multiple GPUs on one machine, using a local parallel pool.

        numTrain_mod = 8000; numClass_mod = 8;                             % # of training images and classes for grayscale CIFAR-10
        numTrain_nat = 10000; numClass_nat = 10;                           % # of training images and classes for each type of modified MNIST
        
        x_dim = 28; y_dim = 28;                                            % width and hieght of images
        input_cell_num = x_dim*y_dim;                                      % # of neuron on the input layer
        hidden_cell_num = x_dim*y_dim;                                     % # of neuron on the hidden layer
        
        convergence_range = 4;                                             % convergence range of feedforward connection btw input and hidden layer
        V1_dim = x_dim;                                                    % width of hidden layer
        threshold_lrc = 2*convergence_range;                               % miminal range of LRCs
        p_total_conn = 0.9999;                                             % connection probability of feedforward connection 
        
        temp_connection_lrc = ones(V1_dim^2,V1_dim^2);
        length_matrix = round(fun_cal_len_LRC(temp_connection_lrc,0));     % length matrix of all possible lateral connections 

        if flg1 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)
            disp('Result 1 ... (~ 1 h)')
            tic
            Result1_1_demo;                                                % code for Figure 2d : accuracy of the networks - FF vs FF+Local vs FF+LRC vs FC
            Result1_2_demo;                                                % code for Figure 2g : accuracy of the networks - 3layer vs 3layer+LRC vs 4layer vs 5layer
            toc
        end
        
        if flg2 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 2 : Long-Range Connections Integrate Global Features (Figure 3)
            disp(['Result 2... (~ 30 min)'])
            tic
            Result2_demo;                                                  % code for Figure 3b : accuracy for each dataset with a variation of the LRC ratio
            toc
        end
        
        if flg3 ~= 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Result 3 : Long-Range Connections for Balancing Performance and Wiring Cost (Figure 4)
            disp(['Result 3...(~ 1 min)'])
            tic
            Result3_demo;                                                  % code for Figure 4b,d : Accuracy, total connection length and LRC ratio during the training
            toc
        end
    end
end
toc