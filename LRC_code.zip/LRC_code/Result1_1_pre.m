%% Result 1 : Long-Range Connections Enhance Object Recognition in Shallow Networks (Figure 2)

% ============================================================================================================

%% Add LRC vs Add Local & Fully-connected networks (Figure 2d)
disp('=================================================================')
disp('Result1_1 : Add LRC vs Add Local & Fully-connected networks')
disp('=================================================================')
%% Set parameter 
MaxEpoch = 2000;
array_conn_num = [1*1e+4 2*1e+4 4*1e+4 8*1e+4]; 
load('pretrainedNet\Result1_1\array_addconn_accu_trial.mat')


%% Plot figure
fontSize_label = 15; fontSize_title = 15; fontSize_legend = 12;
figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Classification accuracy of networks'; 'with various types of lateral connections (Figure 2d)'},'FontSize',fontSize_title) 
hold on
line([0 array_conn_num(end)],[array_addconn_accu_trial(1,1,1,end) array_addconn_accu_trial(1,1,1,end)],'Color','k','LineStyle',':');
line([0 array_conn_num(end)],[array_addconn_accu_trial(1,4,1,end) array_addconn_accu_trial(1,4,1,end)],'Color','k','LineStyle','--');
plot([0,array_conn_num],[squeeze(array_addconn_accu_trial(1,1,1,end)) squeeze(array_addconn_accu_trial(1,2,:,end))'],'r','linewidth',3);
plot([0,array_conn_num],[squeeze(array_addconn_accu_trial(1,1,1,end)) squeeze(array_addconn_accu_trial(1,3,:,end))'],'k','linewidth',3);
xlim([0 8*1e+4]); ylim([20 90]) 
xlabel('Number of lateral connections added (count)','FontSize',fontSize_label)
ylabel('Classification accuracy (%)','FontSize',fontSize_label)
legend('FF only','FF','FF+LRC','FF+Local','fontsize',fontSize_legend,'Location','southeast')
