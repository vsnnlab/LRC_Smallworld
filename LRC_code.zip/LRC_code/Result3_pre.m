%% Result 3 : Long-Range Connections for Balancing Performance and Wiring Cost (Figure 4)

%% Changes of classification accuracy and the total connection length during the training (Figure 4b)
%% The ratio of LRCs converged to the nonzero value (red curve) with length penalty. (Figure 4d)
disp('=================================================================')
disp('Result3 : LRCs for balancing performance and wiring cost')
disp('=================================================================')
%% Set parameter 
MaxEpoch = 3000;

load('pretrainedNet\Result3\array_TotLength_trial.mat')
load('pretrainedNet\Result3\array_penalty_accu_trial.mat')
load('pretrainedNet\Result3\array_num_LatConn_trial.mat')

%% Plot figure
fontSize_label = 14; fontSize_title = 15; fontSize_legend = 12;
pixel2mm = 0.1;
figure('units','normalized','outerposition',[0 0 0.5 1])
sgtitle({'Changes of accuracy and the lateral connection length';'during the training (Figure 4b)'},'FontSize',fontSize_title) 
subplot(2,1,1)
hold on
plot(0:MaxEpoch,squeeze(array_penalty_accu_trial(1,1,:)),'-k','linewidth',3)
plot(0:MaxEpoch,squeeze(array_penalty_accu_trial(1,2,:)),'-r','linewidth',3)
ylim([10 40]); xlim([0 3000]);
ylabel('Accuracy (%)','FontSize',fontSize_label)
legend('No length penalty','Length penalty','fontsize',fontSize_legend,'Location','southeast')
subplot(2,1,2)
hold on
plot(1:MaxEpoch,squeeze(sum(array_TotLength_trial(2,1,1,:),1)).*pixel2mm,'-k','linewidth',3)
plot(1:MaxEpoch,squeeze(sum(array_TotLength_trial(2,1,2,:),1)).*pixel2mm,'-r','linewidth',3)
xlim([0 3000]);
ylabel('Total length (mm)','FontSize',fontSize_label)
xlabel('Training epoch','FontSize',fontSize_label)


figure('units','normalized','outerposition',[0 0 0.5 1])
title({'Change of ratio of LRCs';'during the training with length penalty (Figure 4d)'},'FontSize',fontSize_title) 
hold on
plot(1:MaxEpoch,squeeze(array_num_LatConn_trial(1,1,2,:))./squeeze(sum(array_num_LatConn_trial(:,1,2,:),1)),'-r','linewidth',3)  
ylabel('LRC ratio (LRCs/All lateral)','fontsize',fontSize_label)
xlabel('Training epoch','FontSize',fontSize_label)
