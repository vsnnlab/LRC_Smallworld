function [IMAGE,LABEL] = fun_generate_grayCIFAR10(redim,numTrain)

%% load cifar
IMAGE = cell(1,3);
LABEL = cell(1,3);
array_num_train = [numTrain];
%=========================================================================
imsetTrain = imageSet('DATASET_ori\CIFAR10\cifar10Train','recursive'); 

x_dim = 32; y_dim = 32;
num_channel = 1;

trainNames = {imsetTrain.Description};
ratio_Train2Total = 0.8;
ratio_Vaild2Total = 0.2;

XTrain = zeros(y_dim,x_dim,num_channel,sum(ratio_Train2Total.*[imsetTrain.Count]));
YTrain = categorical(discretize((1:sum(ratio_Train2Total.*[imsetTrain.Count]))',...
    [0,cumsum(ratio_Train2Total.*[imsetTrain.Count])]+1,'categorical',trainNames)); % class ������� 

XValid = zeros(y_dim,x_dim,num_channel,sum(ratio_Vaild2Total.*[imsetTrain.Count]));
YValid = categorical(discretize((1:sum(ratio_Vaild2Total.*[imsetTrain.Count]))',...
    [0,cumsum(ratio_Vaild2Total.*[imsetTrain.Count])]+1,'categorical',trainNames)); % class ������� 

tic;
% disp(['preparing training & validating image']);
array_idx_train_inc = [0,cumsum(ratio_Train2Total.*[imsetTrain(1:end-1).Count])];
array_idx_valid_inc = [0,cumsum(ratio_Vaild2Total.*[imsetTrain(1:end-1).Count])];
for c = 1:length(imsetTrain)
    % disp(['Class : ',trainNames{c}]);
    for i = 1:imsetTrain(c).Count
        idx_train = array_idx_train_inc(c);
        idx_valid = array_idx_valid_inc(c);
        if i<= ratio_Train2Total*imsetTrain(c).Count
            temp = im2double(rgb2gray(read(imsetTrain(c),i)));
            XTrain(:,:,1,i+idx_train) = temp; % num_channel = 1 : grayscale
        else
            temp = im2double(rgb2gray(read(imsetTrain(c),i)));
            XValid(:,:,1,(i-ratio_Train2Total*imsetTrain(c).Count)+idx_valid) = temp; % num_channel = 1 : grayscale
        end
    end
end

%% Load Test Data
% disp(['preparing testing image']);
imsetTest = imageSet('DATASET_ori\CIFAR10\cifar10Train','recursive');
testNames = {imsetTest.Description};
XTest = zeros(y_dim,x_dim,num_channel,sum([imsetTest.Count]));
YTest = categorical(discretize((1:sum([imsetTest.Count]))',...
    [0,cumsum([imsetTest.Count])]+1,'categorical',testNames));
j = 0;
tic;
for c = 1:length(imsetTest)
    % disp(['Class : ',testNames{c}]);
    for i = 1:imsetTest(c).Count
        temp = im2double(rgb2gray(read(imsetTest(c),i)));
        XTest(:,:,1,i+j) = temp;
%         XTest(:,:,:,i+j) = read(imsetTest(c),i);
    end
    j = j + imsetTest(c).Count;
end
toc;

%% sampling image data for test (reducing learning time)
numClass = 10;
for ii = 1:size(IMAGE,2)
    switch ii
        case 1
            temp_ind = 1:array_num_train(1)/numClass;
            Train_ind = repmat(temp_ind,numClass,1)+repmat([0:size(XTrain,4)/numClass:size(XTrain,4)-size(XTrain,4)/numClass]',1,length(temp_ind));
            Train_ind = transpose(Train_ind); Train_ind = Train_ind(:);
            IMAGE{1,ii} = XTrain(:,:,:,Train_ind); LABEL{1,ii} = YTrain(Train_ind);
        case 2
            temp_ind = 1:array_num_train(1)/numClass/5;
            Valid_ind = repmat(temp_ind,numClass,1)+repmat([0:size(XValid,4)/numClass:size(XValid,4)-size(XValid,4)/numClass]',1,length(temp_ind));
            Valid_ind = transpose(Valid_ind); Valid_ind = Valid_ind(:);
            IMAGE{1,ii} = XValid(:,:,:,Valid_ind); LABEL{1,ii} = YValid(Valid_ind);
        case 3
            temp_ind = 1:array_num_train(1)/numClass/5;
            Test_ind = repmat(temp_ind,numClass,1)+repmat([0:size(XTest,4)/numClass:size(XTest,4)-size(XTest,4)/numClass]',1,length(temp_ind));
            Test_ind = transpose(Test_ind); Test_ind = Test_ind(:);
            IMAGE{1,ii} = XTest(:,:,:,Test_ind); LABEL{1,ii} = YTest(Test_ind);
    end
end
%=========================================================================
imgs = IMAGE{1,1};
temp_imgs = zeros(redim,redim,size(imgs,3),size(imgs,4));
for ii = 1:size(IMAGE{1,1},4)
    temp_imgs(:,:,:,ii) = imresize(imgs(:,:,1,ii),[redim redim]);
end
IMAGE{1,1} = temp_imgs;

imgs = IMAGE{1,2};
temp_imgs = zeros(redim,redim,size(imgs,3),size(imgs,4));
for ii = 1:size(IMAGE{1,2},4)
    temp_imgs(:,:,:,ii) = imresize(imgs(:,:,1,ii),[redim redim]);
end
IMAGE{1,2} = temp_imgs;

imgs = IMAGE{1,3};
temp_imgs = zeros(redim,redim,size(imgs,3),size(imgs,4));
for ii = 1:size(IMAGE{1,3},4)
    temp_imgs(:,:,:,ii) = imresize(imgs(:,:,1,ii),[redim redim]);
end
IMAGE{1,3} = temp_imgs;
end