function [IMAGE,LABEL]=fun_load_smnist_prep_backNoise_pos(train_num,valid_num,test_num,redim,max_Amp,pos_noise)

   %% parameter setting
    x_dim = 28;
    y_dim = 28;
    img_total_num = 60000;
    train_set_num = train_num;
    valid_set_num = valid_num;
    test_set_num = test_num;
    
    %% load image
    images = loadMNISTImages('DATASET_ori\MNIST\train-images-idx3-ubyte');
    images = reshape(images, x_dim,y_dim,img_total_num);
    labels = loadMNISTLabels('DATASET_ori\MNIST\train-labels-idx1-ubyte');
    labels(labels==0) = 10;
    
    ind_over = find((labels == 9)|(labels == 10));
    images(:,:,ind_over) = [];
    labels(ind_over) = [];
    train_idx = 1:train_set_num;
    valid_idx = train_set_num+1:train_set_num+valid_set_num;
    test_idx = length(labels)-test_set_num+1:length(labels);
    
    train_imgs(:,:,1,:) = reshape(images(:,:,train_idx),[x_dim,y_dim,1,train_set_num]);
    valid_imgs(:,:,1,:) = reshape(images(:,:,valid_idx),[x_dim,y_dim,1,valid_set_num]);
    test_imgs(:,:,1,:) = reshape(images(:,:,test_idx),[x_dim,y_dim,1,test_set_num]);
    train_labels = labels(train_idx,:);
    valid_labels = labels(valid_idx,:);   
    test_labels = labels(test_idx,:);     
%         
    %% mnist resize and randomly position 
    % train
    for ii = 1:train_set_num
        temp_zero = zeros(y_dim,x_dim);
        temp = imresize(train_imgs(:,:,ii),'Outputsize',[redim redim]);
        neg_ind = find(temp<0);
        temp(neg_ind)=0;
        temp = reshape(temp,redim,redim)/max(max(temp));
        
        y_pos = round((y_dim-redim)/2); 
        x_pos = round((x_dim-redim)/2); 
        
        [J,I]= meshgrid(1:redim,1:redim);
        II = I+y_pos+randi([-pos_noise pos_noise]); JJ = J+x_pos+randi([-pos_noise pos_noise]);
        I=I(:); J=J(:);
        II=II(:); JJ=JJ(:);
        
        temp_zero(II,JJ) = temp(I,J);
        
        temp_zero = temp_zero + max_Amp.*rand(size(temp_zero,1),size(temp_zero,2));
        temp_zero = temp_zero./max(max(temp_zero));
        
        train_imgs(:,:,1,ii) = reshape(temp_zero,[x_dim,y_dim,1,1]);
    end
    % valid
    for ii = 1:valid_set_num
        temp_zero2 = zeros(y_dim,x_dim);
        temp2 = imresize(valid_imgs(:,:,ii),'Outputsize',[redim redim]);
        neg_ind = find(temp2<0);
        temp2(neg_ind)=0;
        temp2 = reshape(temp2,redim,redim)/max(max(temp2));

        y_pos2 = round((y_dim-redim)/2); 
        x_pos2 = round((x_dim-redim)/2); 
        
        [J,I]= meshgrid(1:redim,1:redim);
        II = I+y_pos2+randi([-pos_noise pos_noise]); JJ = J+x_pos2+randi([-pos_noise pos_noise]);
        I=I(:); J=J(:);
        II=II(:); JJ=JJ(:);
        
        temp_zero2(II,JJ) = temp2(I,J);
        
        temp_zero2 = temp_zero2 + max_Amp.*rand(size(temp_zero2,1),size(temp_zero2,2));
        temp_zero2 = temp_zero2./max(max(temp_zero2));
        
        valid_imgs(:,:,1,ii) = reshape(temp_zero2,[x_dim,y_dim,1,1]);
    end
    
    % test 
    for ii = 1:test_set_num
        temp_zero2 = zeros(y_dim,x_dim);
        temp2 = imresize(test_imgs(:,:,ii),'Outputsize',[redim redim]);
        neg_ind = find(temp2<0);
        temp2(neg_ind)=0;
        temp2 = reshape(temp2,redim,redim)/max(max(temp2));

        y_pos2 = round((y_dim-redim)/2); 
        x_pos2 = round((x_dim-redim)/2); 
        
        [J,I]= meshgrid(1:redim,1:redim);
        II = I+y_pos2+randi([-pos_noise pos_noise]); JJ = J+x_pos2+randi([-pos_noise pos_noise]);
        I=I(:); J=J(:);
        II=II(:); JJ=JJ(:);
        
        temp_zero2(II,JJ) = temp2(I,J);
        
        temp_zero2 = temp_zero2 + max_Amp.*rand(size(temp_zero2,1),size(temp_zero2,2));
        temp_zero2 = temp_zero2./max(max(temp_zero2));
        
        test_imgs(:,:,1,ii) = reshape(temp_zero2,[x_dim,y_dim,1,1]);
    end

    IMAGE = {train_imgs; valid_imgs; test_imgs};
    LABEL = {categorical(train_labels); categorical(valid_labels); categorical(test_labels)};
end 