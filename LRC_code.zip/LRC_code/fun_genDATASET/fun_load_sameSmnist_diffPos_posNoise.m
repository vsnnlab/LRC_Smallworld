function [IMAGE,LABEL] = fun_load_sameSmnist_diffPos_posNoise(num_train,num_valid,num_test,redim, pos_noise, max_Amp)

XTrain = loadMNISTImages('DATASET_ori\MNIST\train-images-idx3-ubyte');
XTest = loadMNISTImages('DATASET_ori\MNIST\t10k-images-idx3-ubyte');

YTrain = loadMNISTLabels('DATASET_ori\MNIST\train-labels-idx1-ubyte');
YTest = loadMNISTLabels('DATASET_ori\MNIST\t10k-labels-idx1-ubyte');

% normalized
XTrain = double(XTrain)./255 ;
% YTrain = categorical(YTrain);
XTest = double(XTest)./255;
% YTest = categorical(YTest);

%% parameter setting
x_dim = size(XTrain,1);
y_dim = size(XTrain,2);
num_pos_type = 8;


%% image matrix
train_imgs = zeros(x_dim,y_dim,1,num_train);
train_labels = zeros(num_train,1);

valid_imgs = zeros(x_dim,y_dim,1,num_valid);
valid_labels = zeros(num_valid,1);

test_imgs = zeros(x_dim,y_dim,1,num_test);
test_labels = zeros(num_test,1);


    %% mnist resize and randomly position 
%     type_list = 1:num_pos_type;
    for ii = 1:num_train
        type_num = mod(ii-1,num_pos_type)+1;
        if type_num == 1
            ind_num = find(YTrain == (randi(9)));
            train_ind = ind_num(randi(length(ind_num)));
        end
        
        
                
        switch type_num
            case 1
%                 ind = randperm(length(train_ind_7),2);
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));

                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 2
                
                init1_y = round((28-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((28-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 3

                init1_y = 14+round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 4
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;

                
            case 5
                init1_y = round((14-redim)/2); init1_x = round((28-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((28-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
                
            case 6
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 7
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 8
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,train_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
        end
        
        temp_zero = zeros(y_dim,x_dim);
        temp_zero2 = zeros(y_dim,x_dim);
        
        [J,I]= meshgrid(1:redim,1:redim);
        
        II1 = I+y_pos1+randi([-pos_noise pos_noise]); JJ1 = J+x_pos1+randi([-pos_noise pos_noise]);
        II1=II1(:); JJ1=JJ1(:);
        
        II2 = I+y_pos2+randi([-pos_noise pos_noise]); JJ2 = J+x_pos2+randi([-pos_noise pos_noise]);
        II2=II2(:); JJ2=JJ2(:);
        
        I=I(:); J=J(:);
        temp_zero(II1,JJ1) = temp1(I,J);
        temp_zero2(II2,JJ2) = temp2(I,J);
        
        temp_zero = temp_zero+temp_zero2;
        temp_zero(temp_zero>1)=1;
        
        temp_zero = temp_zero + max_Amp.*rand(size(temp_zero,1),size(temp_zero,2));
        temp_zero = temp_zero./max(max(temp_zero));
        
        train_imgs(:,:,:,ii) = temp_zero;

        train_labels(ii) = type_num;
        
    end
    
    for jj = 1:num_valid
        type_num = mod(jj-1,num_pos_type)+1;
        if type_num == 1
            ind_num = find(YTrain == (randi(9)));
            valid_ind = ind_num(randi(length(ind_num)));
        end
        
        switch type_num
            case 1
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));

                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 2
                init1_y = round((28-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((28-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 3
                init1_y = 14+round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;

                
            case 4
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 5
                init1_y = round((14-redim)/2); init1_x = round((28-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((28-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 6
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 7
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 8
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                
                temp1 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTrain(:,:,1,valid_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
        end
        
        temp_zero = zeros(y_dim,x_dim);
        temp_zero2 = zeros(y_dim,x_dim);
         
        
        [J,I]= meshgrid(1:redim,1:redim);
        
        II1 = I+y_pos1+randi([-pos_noise pos_noise]); JJ1 = J+x_pos1+randi([-pos_noise pos_noise]);
        II1=II1(:); JJ1=JJ1(:);
        
        II2 = I+y_pos2+randi([-pos_noise pos_noise]); JJ2 = J+x_pos2+randi([-pos_noise pos_noise]);
        II2=II2(:); JJ2=JJ2(:);
        
        I=I(:); J=J(:);
        temp_zero(II1,JJ1) = temp1(I,J);
        temp_zero2(II2,JJ2) = temp2(I,J);
        
        temp_zero = temp_zero+temp_zero2;
        temp_zero(temp_zero>1)=1;
        
        temp_zero = temp_zero + max_Amp.*rand(size(temp_zero,1),size(temp_zero,2));
        temp_zero = temp_zero./max(max(temp_zero));
        
        valid_imgs(:,:,1,jj) = temp_zero;
        
        valid_labels(jj) = type_num;
        
    end
    
    for jj = 1:num_test
        type_num = mod(jj-1,num_pos_type)+1;
        if type_num == 1
            ind_num = find(YTest == (randi(9)));
            test_ind = ind_num(randi(length(ind_num)));
        end
%         type_num = mod(jj,num_pos_type)+1;
        
        switch type_num
            case 1
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));

                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 2
                init1_y = round((28-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((28-redim)/2); init2_x = 14+round((14-redim)/2);
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 3
                init1_y = 14+round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = 14+round((14-redim)/2);
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 4
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 5
                init1_y = round((14-redim)/2); init1_x = round((28-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((28-redim)/2);
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 6
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 7
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2);
                init2_y = round((14-redim)/2)+14; init2_x = round((14-redim)/2)+14;
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
            case 8
                init1_y = round((14-redim)/2); init1_x = round((14-redim)/2)+14;
                init2_y = 14+round((14-redim)/2); init2_x = round((14-redim)/2);
                
                temp1 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp1<0);
                temp1(neg_ind)=0;
                temp1 = reshape(temp1,redim,redim)/max(max(temp1));
                
                temp2 = imresize(XTest(:,:,1,test_ind),'Outputsize',[redim redim]);
                neg_ind = find(temp2<0);
                temp2(neg_ind)=0;
                temp2 = reshape(temp2,redim,redim)/max(max(temp2));
                
                y_pos1 = init1_y; x_pos1 = init1_x;
                y_pos2 = init2_y; x_pos2 = init2_x;
                
        end
        
        temp_zero = zeros(y_dim,x_dim);
        temp_zero2 = zeros(y_dim,x_dim);
         
        
        [J,I]= meshgrid(1:redim,1:redim);
        
        II1 = I+y_pos1+randi([-pos_noise pos_noise]); JJ1 = J+x_pos1+randi([-pos_noise pos_noise]);
%         II1 = I+y_pos1; JJ1 = J+x_pos1;
        II1=II1(:); JJ1=JJ1(:);
        
        II2 = I+y_pos2+randi([-pos_noise pos_noise]); JJ2 = J+x_pos2+randi([-pos_noise pos_noise]);
%         II2 = I+y_pos2; JJ2 = J+x_pos2;
        II2=II2(:); JJ2=JJ2(:);
        
        I=I(:); J=J(:);
        temp_zero(II1,JJ1) = temp1(I,J);
        temp_zero2(II2,JJ2) = temp2(I,J);
        
        temp_zero = temp_zero+temp_zero2;
        temp_zero(temp_zero>1)=1;
        
        temp_zero = temp_zero + max_Amp.*rand(size(temp_zero,1),size(temp_zero,2));
        temp_zero = temp_zero./max(max(temp_zero));
        
        test_imgs(:,:,1,jj) = temp_zero;
        test_labels(jj) = type_num;
        
    end
    
    IMAGE = {train_imgs; valid_imgs; test_imgs};
    LABEL = {categorical(train_labels); categorical(valid_labels); categorical(test_labels)};
    
end