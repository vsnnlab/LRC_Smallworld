function [IMAGE,LABEL] = fun_generate_mMNIST(numTrain)
%% load image
%=========================================================================
array_num_train = [numTrain numTrain numTrain];
IMAGE = cell(length(array_num_train),3);
LABEL = cell(length(array_num_train),3);

%% Type 1 : shape
max_Amp = 0.0;pos_noise = 1;ind_img = 1;redim = 6;
[IMAGE(ind_img,:),LABEL(ind_img,:)] = fun_load_smnist_prep_backNoise_pos(array_num_train(ind_img),array_num_train(ind_img)/4,array_num_train(ind_img)/4,...
    redim,max_Amp,pos_noise);

%% Type 2 : postion
max_Amp = 0.5;pos_noise = 4;ind_img = 2;redim = 6;
[IMAGE(ind_img,:),LABEL(ind_img,:)] = fun_load_sameSmnist_diffPos_posNoise(array_num_train(ind_img),array_num_train(ind_img)/4,array_num_train(ind_img)/4, ...
    redim,pos_noise,max_Amp);

%% Type 3 : shape_position  
max_Amp = 0.0;pos_noise = 1;ind_img = 3;array_k = [14];redim = 8;
[IMAGE(ind_img,:),LABEL(ind_img,:)] = fun_small_multi_num_pos_noise_L8_backNoise_pos(array_num_train(ind_img),array_num_train(ind_img)/4,array_num_train(ind_img)/4,...
    redim,max_Amp,pos_noise,array_k);
end
