classdef SolverSGDM_conv5 < nnet.internal.cnn.solver.Solver
    
    % ====================================================
    % dir = C:\Program Files\MATLAB\R2019a\toolbox\nnet\cnn\+nnet\+internal\+cnn\+solver
    % ====================================================
    
    % SolverSGDM   Stochastic gradient descent with momentum (SGDM) solver.
    
    %   Copyright 2017 The MathWorks, Inc.
    
    properties
        % Momentum   Momentum for SGDM update.
        %   A real scalar in [0,1] specifying the coefficient of the
        %   momentum term in SGDM update.
        Momentum
    end
    
    properties(Access=protected)
        % PreviousVelocities   Previous update steps in SGDM.
        %   A cell array of length NumLearnableParameters. Each element of
        %   the cell array contains the update step computed in the
        %   previous iteration of SGDM for that learnable parameter.
        PreviousVelocities
    end
    
    methods(Hidden)
        function this = SolverSGDM_conv5(learnableParameters,precision,options)
            % this = SolverSGDM(learnableParameters,precision,options)
            % creates a SolverSGDM object for optimizing parameters in
            % learnableParameters using floating point precision specified
            % in precision. The class of inputs is as follows:
            %
            %    learnableParameters - an array of objects of type nnet.internal.cnn.layer.learnable.LearnableParameter
            %    precision           - an object of type nnet.internal.cnn.util.Precision
            %    options             - an object of type nnet.cnn.TrainingOptionsSGDM
            
            this = this@nnet.internal.cnn.solver.Solver(learnableParameters,precision);
            this.Momentum = precision.cast(options.Momentum);
            initializeState(this);
        end
    end
    
    methods(Access=protected)
        function initializeState(this)
            % initializeState(this) sets the state of the solver to its
            % initial state.
            
            this.PreviousVelocities = iInitializeVelocities(this.NumLearnableParameters,this.Precision);
        end
    end
    
    methods
        function step = calculateUpdate(this,gradients,globalLearnRate)
            % step = calculateUpdate(this,gradients,globalLearnRate)
            % calculates the update for learnable parameters by applying
            % one step of SGDM solver. Input gradients is a cell array
            % where each element is the total gradient of the objective
            % (loss + regularization) with respect to one learnable
            % parameter. Input globalLearnRate specifies the global
            % learning rate to use for calculating the update step. The
            % length of gradients must equal NumLearnableParameters.
            
            load('connectivity.mat');
            
            localLearnRates = this.LocalLearnRates;
            numLearnableParameters = this.NumLearnableParameters;
            momentum = this.Momentum;
            
            step = cell(1,numLearnableParameters);
            for i = 1:numLearnableParameters
                % No update needed for parameters that are not learning
                if localLearnRates{i} ~= 0 && ~isempty(gradients{i})
                    effectiveLearningRate = globalLearnRate.*localLearnRates{i};
                    switch i
                        case 1
                            conn = transpose(MAT_conn{1});
                            this.PreviousVelocities{i} = momentum.*this.PreviousVelocities{i} ...
                                - effectiveLearningRate.*gradients{i}.*reshape(conn,[sqrt(size(MAT_conn{1},1)) sqrt(size(MAT_conn{1},2)) 1 size(conn,2)]);
                        case 3
                            conn = transpose(MAT_conn{2});
                            this.PreviousVelocities{i} = momentum.*this.PreviousVelocities{i} ...
                                - effectiveLearningRate.*gradients{i}.*reshape(conn,[1 1 size(conn,1) size(conn,2)]);
                        case 5
                            conn = transpose(MAT_conn{3});
                            this.PreviousVelocities{i} = momentum.*this.PreviousVelocities{i} ...
                                - effectiveLearningRate.*gradients{i}.*reshape(conn,[1 1 size(conn,1) size(conn,2)]);
                        case 7
                            conn = transpose(MAT_conn{4});
                            this.PreviousVelocities{i} = momentum.*this.PreviousVelocities{i} ...
                                - effectiveLearningRate.*gradients{i}.*reshape(conn,[1 1 size(conn,1) size(conn,2)]);
                        otherwise
                            this.PreviousVelocities{i} = momentum.*this.PreviousVelocities{i} - effectiveLearningRate.*gradients{i};
                    end
                    step{i} = this.PreviousVelocities{i};
                end
            end
            
            clear MAT_conn conn
        end
    end
end

function velocities = iInitializeVelocities(numLearnableParameters,precision)
velocities = cell(1,numLearnableParameters);
for i = 1:numLearnableParameters
    velocities{i} = precision.zeros(1);
end
end