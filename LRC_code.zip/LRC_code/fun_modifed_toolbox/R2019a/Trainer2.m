classdef Trainer2 < handle
    % Trainer   Class for training a network
    % =================================================
    % dir = C:\Program Files\MATLAB\R2019a\toolbox\nnet\cnn\+nnet\+internal\+cnn
    % =================================================
    %   Copyright 2015-2018 The MathWorks, Inc.
    
    properties(Access = protected)
        Options
        Schedule
        Precision
        Reporter
        SummaryFcn
        ExecutionStrategy
        StopTrainingFlag
        StopReason
        InterruptException
    end
    
    methods
        function this = Trainer2( ...
                opts, precision, reporter, executionSettings, summaryFcn)
            % Trainer    Constructor for a network trainer
            %
            % opts - training options (nnet.cnn.TrainingOptionsSGDM)
            % precision - data precision
            this.Options = opts;
            scheduleArguments = iGetArgumentsForScheduleCreation(opts.LearnRateScheduleSettings);
            this.Schedule = nnet.internal.cnn.LearnRateScheduleFactory.create(scheduleArguments{:});
            this.Precision = precision;
            this.Reporter = reporter;
            this.SummaryFcn = summaryFcn;
            % Declare execution strategy
            if ismember( executionSettings.executionEnvironment, {'gpu'} )
                this.ExecutionStrategy = nnet.internal.cnn.TrainerGPUStrategy;
            else
                this.ExecutionStrategy = nnet.internal.cnn.TrainerHostStrategy;
            end
            
            % Print execution environment if in verbose mode
            iPrintExecutionEnvironment(opts, executionSettings);
            
            % Register a listener to detect requests to terminate training
            addlistener( reporter, ...
                'TrainingInterruptEvent', @this.stopTrainingCallback);
        end
        
        function net = initializeNetwork(this, net, data, networkInfo)
            % Perform any initialization steps required by the input and
            % output layers
            
            % Setup reporters
            this.Reporter.setup();

            % Store any classification labels or response names in the
            % appropriate output layers.
            net = storeResponseData(net, data.ResponseMetaData);
            
            if networkInfo.ShouldInputLayersBeInitialized
                if this.Options.Verbose
                    iPrintMessage('nnet_cnn:internal:cnn:Trainer:InitializingInputNormalization');
                end 

                % Always use 'truncateLast' as we want to process all the data we have.
                savedEndOfEpoch = data.EndOfEpoch;
                data.EndOfEpoch = 'truncateLast';

                % Perform initialization steps on host or in distributed
                % environment
                net = this.initializeInEnvironment(net, data);

                data.EndOfEpoch = savedEndOfEpoch;
            end
        end
                
        function net = train(this, net, data)
            % train   Train a network
            %
            % Inputs
            %    net -- network to train
            %    data -- data encapsulated in a data dispatcher
            % Outputs
            %    net -- trained network
            reporter = this.Reporter;
            schedule = this.Schedule;
            prms = collectSettings(this, net);
            data.start();
            summary = this.SummaryFcn(data, prms.maxEpochs);
            
            regularizer = iCreateRegularizer('l2_len',net.LearnableParameters,this.Precision,this.Options);
            
            solver = iCreateSolver(net.LearnableParameters,this.Precision,this.Options);
            
            trainingTimer = tic;
            
            reporter.start();
            iteration = 0;
            this.StopTrainingFlag = false;
            this.StopReason = nnet.internal.cnn.util.TrainingStopReason.FinalIteration;
            gradientThresholdOptions = struct('Method', this.Options.GradientThresholdMethod,...
                'Threshold', this.Options.GradientThreshold);
            gradThresholder = nnet.internal.cnn.GradientThresholder(gradientThresholdOptions);
            learnRate = initializeLearning(this);
            
            needsStatefulTraining = iNeedsStatefulTraining(data, net);
            for epoch = 1:prms.maxEpochs
                this.shuffle( data, prms.shuffleOption, epoch );
                data.start();
                while ~data.IsDone && ~this.StopTrainingFlag
                    [X, response] = data.next();
                    % Cast data to appropriate execution environment for
                    % training and apply transforms
                    X = this.ExecutionStrategy.environment(X);
                    response = this.ExecutionStrategy.environment(response);
                    
                    propagateState = iNeedsToPropagateState(data);
                    [gradients, predictions, states] = this.computeGradients(net, X, response, needsStatefulTraining, propagateState);
                    
                    % Reuse the layers outputs to compute loss
                    miniBatchLoss = net.loss( predictions, response );
                    
                    gradients = regularizer.regularizeGradients(gradients,net.LearnableParameters);
                    
                    gradients = thresholdGradients(gradThresholder,gradients);
                    
                    velocity = solver.calculateUpdate(gradients,learnRate);
                    
                    net = net.updateLearnableParameters(velocity);
                    
                    net = net.updateNetworkState(states, needsStatefulTraining);
                    
                    elapsedTime = toc(trainingTimer);
                    
                    iteration = iteration + 1;
                    summary.update(predictions, response, epoch, iteration, elapsedTime, miniBatchLoss, learnRate, data.IsDone);
                    % It is important that computeIteration is called
                    % before reportIteration, so that the summary is
                    % correctly updated before being reported
                    reporter.computeIteration( summary, net );
                    reporter.reportIteration( summary );
                end
                learnRate = schedule.update(learnRate, epoch);
                
                reporter.reportEpoch( epoch, iteration, net );
                
                % If an interrupt request has been made, break out of the
                % epoch loop
                if this.StopTrainingFlag
                    break;
                end
            end
            reporter.computeFinish( summary, net );
            reporter.finish( summary, this.StopReason );
        end

        function net = finalizeNetwork(this, net, data)
            % Perform any finalization steps required by the layers
            
            % Always use 'truncateLast' as we want to process all the data we have.
            savedEndOfEpoch = data.EndOfEpoch;
            data.EndOfEpoch = 'truncateLast';
            
            % Call shared implementation
            net = this.doFinalize(net, data);
            
            data.EndOfEpoch = savedEndOfEpoch;
        end
    end

    methods(Access = protected)
        function stopTrainingCallback(this, ~, evtData)
            % stopTraining  Callback triggered by interrupt events that
            % want to request training to stop
            this.StopTrainingFlag = true;
            this.StopReason = evtData.TrainingStopReason;
        end

        function settings = collectSettings(this, net)
            % collectSettings  Collect together fixed settings from the
            % Trainer and the data and put in the correct form.
            settings.maxEpochs = this.Options.MaxEpochs;
            settings.lossFunctionType = iGetLossFunctionType(net);
            settings.shuffleOption = this.Options.Shuffle;
            settings.numOutputs = numel(net.OutputSizes);
            settings.InputObservationDim = cellfun(@(sz)numel(sz)+1, net.InputSizes, 'UniformOutput', false);
            settings.OutputObservationDim = cellfun(@(sz)numel(sz)+1, net.OutputSizes, 'UniformOutput', false);
        end

        function learnRate = initializeLearning(this)
            % initializeLearning  Set initial learning rate.
            learnRate = this.Precision.cast( this.Options.InitialLearnRate );
        end

        function [gradients, predictions, states] = computeGradients(~, net, X, Y, needsStatefulTraining, propagateState)
            % computeGradients   Compute the gradients of the network. This
            % function returns also the network output so that we will not
            % need to perform the forward propagation step again.
            [gradients, predictions, states] = net.computeGradientsForTraining(X, Y, needsStatefulTraining, propagateState);
        end

        function net = initializeInEnvironment(this, net, data)
            % Initialization steps running on the host
            net = resetNetworkInitialization(net);
            net = doInitialize(this, net, data);
            net = finishNetworkInitialization(net,this.Precision);
        end
        
        function net = doInitialize(this, net, data)
            % Perform any initialization steps required by the layers
            % Do one epoch
            data.start();
            while ~data.IsDone
                X = data.next();
                if ~isempty(X) % In the parallel case X can be empty
                    % Cast data to appropriate execution environment for
                    % initialization
                    X = this.ExecutionStrategy.environment(X);
                    
                    % Ask the network to initialize
                    net = initializeNetwork(net, X);
                end
            end
        end
        
        function net = doFinalize(this, net, data)
            % Perform any finalization steps required by the layers
            isFinalizable = @(l)isa(l,'nnet.internal.cnn.layer.Finalizable') && ...
                                    l.NeedsFinalize;
            needsFinalize = cellfun(isFinalizable, net.Layers);
            if any(needsFinalize)
                % Do one final epoch
                data.start();
                while ~data.IsDone
                    X = data.next();
                    if ~isempty(X) % In the parallel case X can be empty
                        % Cast data to appropriate execution environment for
                        % training and apply transforms
                        X = this.ExecutionStrategy.environment(X);

                        % Ask the network to finalize
                        net = finalizeNetwork(net, X);
                    end
                end
                
            end
        end
    end
    
    methods(Access = protected)
        function shuffle(~, data, shuffleOption, epoch)
            % shuffle   Shuffle the data as per training options
            if ~isequal(shuffleOption, 'never') && ...
                    ( epoch == 1 || isequal(shuffleOption, 'every-epoch') )
                data.shuffle();
            end
        end
    end
end

function regularizer = iCreateRegularizer(name,learnableParameters,precision,regularizationOptions)
regularizer = nnet.internal.cnn.regularizer.RegularizerFactory2.create(name,learnableParameters,precision,regularizationOptions);
end

function solver = iCreateSolver(learnableParameters,precision,trainingOptions)
solver = nnet.internal.cnn.solver.SolverFactory2.create(learnableParameters,precision,trainingOptions);
end

function tf = iNeedsToPropagateState(data)
tf = isa(data,'nnet.internal.cnn.SequenceDispatcher') && data.IsNextMiniBatchSameObs;
end

function tf = iNeedsStatefulTraining(data,net)
% iNeedsStatefulTraining   tf is a logical array of length numel(
% net.Layers ). tf(ii) is true if the iith layer requires a stateful update
% during training.
isStatefulLayer = nnet.internal.cnn.util.isStatefulLayer( net.SortedLayers );
haveSequenceDispatcher = isa(data,'nnet.internal.cnn.SequenceDispatcher');
tf = isStatefulLayer & haveSequenceDispatcher;
end

function t = iGetLossFunctionType(net)
if isempty(net.Layers)
    t = 'nnet.internal.cnn.layer.NullLayer';
else
    t = class(net.Layers{end});
end
end

function scheduleArguments = iGetArgumentsForScheduleCreation(learnRateScheduleSettings)
scheduleArguments = struct2cell(learnRateScheduleSettings);
end

function iPrintMessage(messageID, varargin)
string = getString(message(messageID, varargin{:}));
fprintf( '%s\n', string );
end

function iPrintExecutionEnvironment(opts, executionSettings)
% Print execution environment if in 'auto' mode
if opts.Verbose
    if ismember(opts.ExecutionEnvironment, {'auto'})
        if ismember(executionSettings.executionEnvironment, {'cpu'})
            iPrintMessage( ...
                'nnet_cnn:internal:cnn:Trainer:TrainingInSerialOnCPU');
        elseif ismember(executionSettings.executionEnvironment, {'gpu'})
            iPrintMessage( ...
                'nnet_cnn:internal:cnn:Trainer:TrainingInSerialOnGPU');
        end
    elseif ismember(opts.ExecutionEnvironment, {'parallel'})
        if ismember(executionSettings.executionEnvironment, {'cpu'})
            iPrintMessage( ...
                'nnet_cnn:internal:cnn:Trainer:TrainingInParallelOnCPUs');
        elseif ismember(executionSettings.executionEnvironment, {'gpu'})
            iPrintMessage( ...
                'nnet_cnn:internal:cnn:Trainer:TrainingInParallelOnGPUs');
        end
    end
end
end