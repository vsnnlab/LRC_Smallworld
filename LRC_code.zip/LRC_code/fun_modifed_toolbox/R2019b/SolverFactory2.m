classdef SolverFactory2
    
    % ==================================================
    % dir = C:\Program Files\MATLAB\R2019b\toolbox\nnet\cnn\+nnet\+internal\+cnn\+solver
    % ==================================================
    % SolverFactory   Class for creating solvers.
    
    %   Copyright 2017 The MathWorks, Inc.
    
    methods(Static)
        function solver = create(learnableParameters,precision,solverOptions)
            % solver = create(learnableParameters,precision,solverOptions)
            % creates a Solver object for optimizing parameters in
            % learnableParameters using floating point precision specified
            % in precision and solver options specified in solverOptions.
            % The class of inputs is as follows:
            %
            %    learnableParameters - an array of objects of type nnet.internal.cnn.layer.learnable.LearnableParameter
            %    precision           - an object of type nnet.internal.cnn.util.Precision
            %    solverOptions       - an object of a subclass of nnet.cnn.TrainingOptions
            
            if iIsSolverSGDM(solverOptions)
                solver = nnet.internal.cnn.solver.SolverSGDM(learnableParameters,precision,solverOptions);
            elseif iIsSolverSGDM_conv3(solverOptions)
                solver = nnet.internal.cnn.solver.SolverSGDM_conv3(learnableParameters,precision,solverOptions);
            elseif iIsSolverSGDM_conv3_LRC(solverOptions)
                solver = nnet.internal.cnn.solver.SolverSGDM_conv3_LRC(learnableParameters,precision,solverOptions);
            elseif iIsSolverSGDM_conv4(solverOptions)
                solver = nnet.internal.cnn.solver.SolverSGDM_conv4(learnableParameters,precision,solverOptions);
            elseif iIsSolverSGDM_conv5(solverOptions)
                solver = nnet.internal.cnn.solver.SolverSGDM_conv5(learnableParameters,precision,solverOptions);
            elseif iIsSolverADAM(solverOptions)
                solver = nnet.internal.cnn.solver.SolverADAM(learnableParameters,precision,solverOptions);
            elseif iIsSolverRMSProp(solverOptions)
                solver = nnet.internal.cnn.solver.SolverRMSProp(learnableParameters,precision,solverOptions);
            else
                error('Unsupported solver.');
            end
        end
    end
end

function tf = iIsSolverSGDM(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsSGDM');
end

function tf = iIsSolverSGDM_conv3(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsSGDM_conv3');
end

function tf = iIsSolverSGDM_conv3_LRC(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsSGDM_conv3_LRC');
end

function tf = iIsSolverSGDM_conv4(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsSGDM_conv4');
end

function tf = iIsSolverSGDM_conv5(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsSGDM_conv5');
end

function tf = iIsSolverADAM(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsADAM');
end

function tf = iIsSolverRMSProp(solverOptions)
tf = isa(solverOptions,'nnet.cnn.TrainingOptionsRMSProp');
end