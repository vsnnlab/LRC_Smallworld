clc;clear; close all;

currentFolder_tmp = split(pwd,'\');
currentFolder = currentFolder_tmp{1};
for ii = 1:length(currentFolder_tmp)-2
    currentFolder = [currentFolder,'\',currentFolder_tmp{ii+1}];
end

addpath([currentFolder,'\Data\Fig1\'])

%% Data
load('DATA_treeshrew_Bosking1997.mat'); % Data from Bosking, 1997
x_DATA_t = DATA_treeshrew{1}; y_DATA_t = DATA_treeshrew{4}; 
y_DATA_t = y_DATA_t(1:length(x_DATA_t)); y_DATA_t_norm = y_DATA_t./sum(y_DATA_t);

load('DATA_mouse_Seeman2018.mat'); % Data from Seeman, 2018
x_DATA_m = DATA_mouse(1,:).*1000;
y_DATA_m = DATA_mouse(2,:); y_DATA_m_norm = y_DATA_m./sum(y_DATA_m);

load('DATA_rat_Burkhalter1990.mat'); % Data from Burkhalter, 1990
x_DATA_r = x;
y_DATA_r = y; y_DATA_r_norm = y_DATA_r./sum(y_DATA_r)-0.075;

load('DATA_primate_Liu2014.mat'); % Data from Liu, 2014
x_DATA_p = x;
y_DATA_p = y; y_DATA_p_norm = y_DATA_p./sum(y_DATA_p);

%% Length distribution
x_range = [0:0.1:5];
myfun = @(p, x) (p(1)*exp(-p(2)*x));

[param_t, ~] = nlinfit(x_DATA_t',y_DATA_t_norm,myfun,[1,1]); 
fit_t = myfun(param_t,x_range);

[param_m, ~] = nlinfit(x_DATA_m,y_DATA_m_norm,myfun,[1,1]); 
fit_m = myfun(param_m,x_range);

[param_r, ~] = nlinfit(x_DATA_r,y_DATA_r_norm,myfun,[1,1]); 
fit_r = myfun(param_r,x_range);

[param_p, ~] = nlinfit(x_DATA_p,y_DATA_p_norm,myfun,[1,1]); 
fit_p = myfun(param_p,x_range);

ccmap = hot(7);
figure; hold on; set(gca,'TickDir','out');

plot(x_DATA_m,y_DATA_m_norm,'o','linewidth',1,'Color',[0 0 0])
plot(x_range,fit_m,'--','linewidth',1.5,'Color',[0 0 0])

plot(x_DATA_r,y_DATA_r_norm,'o','linewidth',1,'Color',ccmap(1,:))
plot(x_range,fit_r,'--','linewidth',1.5,'Color',ccmap(1,:))

plot(x_DATA_t,y_DATA_t_norm,'o','linewidth',1,'Color',ccmap(2,:))
plot(x_range,fit_t,'--','linewidth',1.5,'Color',ccmap(2,:))

plot(x_DATA_p,y_DATA_p_norm,'o','linewidth',1,'Color',ccmap(3,:))
plot(x_range,fit_p,'--','linewidth',1.5,'Color',ccmap(3,:))

xlabel('Length (mm)','FontSize',12)
ylabel('Connection probability','FontSize',12)
xlim([0 3]); ylim([0 0.5])
