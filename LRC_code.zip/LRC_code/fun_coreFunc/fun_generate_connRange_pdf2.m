function y = fun_generate_connRange_pdf2(ind_connRange,ind_pdf,edge,convergence_range)

    switch ind_connRange
        case 1 % rand ( = all range )
            switch ind_pdf
                case 1 % uniform
                    x = edge;
                    pd = makedist('Uniform','Lower',x(1),'Upper',x(end));
                    y= pdf(pd,x);
                case 2 % exponential
                    x = edge;
                    pd = makedist('Exponential','mu',mean(x));
                    y = pdf(pd,x);
                case 3 % normal
                    x = edge;
                    pd = makedist('normal','mu',mean(x),'sigma',2.2*convergence_range);
                    y= pdf(pd,x); y = y./sum(y);
                case 4 % inverse exponential
                    x = edge;
                    pd = makedist('Exponential','mu',mean(x));
                    y = fliplr(pdf(pd,x));
            end
        case 2 % LRC
            temp_x = [1:40]-2*convergence_range;
            temp_x = temp_x(temp_x>=0);
            switch ind_pdf
                case 1 % uniform
                    pd = makedist('Uniform','Lower',temp_x(1),'Upper',temp_x(end));
                    y = pdf(pd,temp_x);
                case 2 % exponential
                    pd = makedist('Exponential','mu',mean(temp_x));
                    y = pdf(pd,temp_x);
                case 3 % normal
                    pd = makedist('normal','mu',mean(temp_x),'sigma',1.65*convergence_range);
                    y= pdf(pd,temp_x); y = y./sum(y);
                case 4 % inverse exponential
                    pd = makedist('Exponential','mu',mean(temp_x));
                    y = fliplr(pdf(pd,temp_x));
            end
            y = [zeros(1,length(edge)-length(y)),y];
            
        case 3 % SRC
            convergence_range = 2;
            temp_x = [1:40];
            temp_x = temp_x(temp_x<=convergence_range);
            switch ind_pdf
                case 1 % uniform
                    pd = makedist('Uniform','Lower',temp_x(1),'Upper',temp_x(end));
                    y= pdf(pd,temp_x); % y2 = y2./sum(y2);
                case 2 % exponential
                    pd = makedist('Exponential','mu',mean(temp_x-1));
                    y = pdf(pd,temp_x-1); % y3 = y3./sum(y3);
                case 3 % normal
                    pd = makedist('normal','mu',mean(temp_x),'sigma',0.33*convergence_range);
                    y= pdf(pd,temp_x); y = y./sum(y);
                case 4 % inverse exponential
                    pd = makedist('Exponential','mu',mean(temp_x-1));
                    y = fliplr(pdf(pd,temp_x-1)); % y4 = y4./sum(y4);
            end
            y = [y,zeros(1,length(edge)-length(y))];
    end
end