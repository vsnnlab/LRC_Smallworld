function [connection_w0_rewire,connection_lateral_rewire] = fun_delFF_rewireLRC(connection_w0_ori,length_matrix,...
    p_lateral,convergence_range,edge,ind_connRange,ind_pdf)

%% add lateral connection
p_rewiring = floor(p_lateral*length(find(connection_w0_ori)));
y = fun_generate_connRange_pdf2(ind_connRange,ind_pdf,edge,convergence_range);
rewireNumLength = floor(y.*p_rewiring);
connection_lateral_rewire = fun_add_Lateral_pdf(length_matrix,rewireNumLength);

%% delete ff 
connection_w0_rewire = connection_w0_ori;
[s1,s2] = size(connection_w0_ori); 

ind_del = find(connection_w0_ori(:)==1);
ind_del = ind_del(randperm(length(ind_del),p_rewiring));
connection_w0_rewire(ind_del) = 0;
connection_w0_rewire = reshape(connection_w0_rewire,s1,s2);

end
