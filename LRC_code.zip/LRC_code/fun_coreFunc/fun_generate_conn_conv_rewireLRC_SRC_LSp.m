function [connection_w0, connection_w0_len, ...
          connection_long_range_hidden1, connection_long_range_len,num_LRC,num_SRC,...
          connection_w1, connection_w1_len] = fun_generate_conn_conv_rewireLRC_SRC_LSp(input_cell_num,hidden_cell_num,output_cell_num,...
                                                                      convergence_range,convergence_range_out,V1_dim,...
                                                                     p_long_range,threshold_lrc,...
                                                                      p_sampling,p_LS)
switch_local_ff_connection = 1;
padding = 9;
V1_dimen = V1_dim;


if switch_local_ff_connection==1
    connection_w0 = zeros(hidden_cell_num,input_cell_num);
    connection_w0_len = zeros(hidden_cell_num,input_cell_num);
    connection_w1 = zeros(output_cell_num,hidden_cell_num);
    connection_w1_len = zeros(output_cell_num,hidden_cell_num);
    
    hidden_layer_area = V1_dim^2;
    
    for hh = 1:hidden_layer_area
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        for ii = 1:input_cell_num
            x_input = floor((ii-1)/sqrt(input_cell_num))+1;
            y_input = mod((ii-1),sqrt(input_cell_num))+1;
            
            if floor(sqrt(input_cell_num)/(V1_dim+1)) > 1
                distance_input_hid = sqrt((x_input-floor(sqrt(input_cell_num)/(V1_dim+1))*x_hid)^2 + (y_input-floor(sqrt(input_cell_num)/(V1_dim+1))*y_hid)^2);
            else
                distance_input_hid = sqrt((x_input-floor((sqrt(input_cell_num)-V1_dim)/2)-x_hid)^2 + (y_input-floor((sqrt(input_cell_num)-V1_dim)/2)-y_hid)^2);
            end
            connection_w0(sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2),ii) = distance_input_hid < convergence_range;
            connection_w0_len(sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2),ii) = sqrt((distance_input_hid)^2);
        end
    end
    connection_w0_len = connection_w0_len.*connection_w0;
    output_candidate = randperm((28-(2*padding))^2,output_cell_num); 
    for oo=1:output_cell_num

        x_out = floor((output_candidate(oo)-1)/(sqrt(input_cell_num)-(2*padding)))+1+padding;
        y_out = mod((output_candidate(oo)-1),sqrt(input_cell_num)-(2*padding))+1+padding;

        
        hidden_layer_area = V1_dim^2;
        for hh=1:hidden_layer_area
            x_hid = floor((hh-1)/V1_dim)+1;
            y_hid = mod((hh-1),V1_dim)+1;
            
            if floor(sqrt(input_cell_num)/(V1_dim+1)) > 1
                distance_input_hid = sqrt((x_out-floor(sqrt(input_cell_num)/(V1_dim+1))*x_hid)^2 + (y_out-floor(sqrt(input_cell_num)/(V1_dim+1))*y_hid)^2);
            else
                distance_input_hid = sqrt((x_out-floor((sqrt(input_cell_num)-V1_dim)/2)-x_hid)^2 + (y_out-floor((sqrt(input_cell_num)-V1_dim)/2)-y_hid)^2);
            end
            connection_w1(oo,sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2)) = distance_input_hid < convergence_range_out;
            connection_w1_len(oo,sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2)) = sqrt((distance_input_hid)^2); 
        end
    end
    connection_w1_len = connection_w1_len.*connection_w1;

else
    connection_w0 = zeros(hidden_cell_num,input_cell_num);
    connection_w1 = zeros(output_cell_num,hidden_cell_num);
    
    hidden_layer_area = V1_dim^2;
    
    for hh = 1:hidden_layer_area
        x_hid = floor((hh-1)/V1_dim)+1;
        y_hid = mod((hh-1),V1_dim)+1;
        for ii = 1:input_cell_num
            connection_w0(sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2),ii) = 1 ;
        end
    end
    
    for oo=1:output_cell_num
        hidden_layer_area = V1_dim^2;
        
        for hh=1:hidden_layer_area
            x_hid = floor((hh-1)/V1_dim)+1;
            y_hid = mod((hh-1),V1_dim)+1;
            
            connection_w1(oo,sqrt(input_cell_num)*(x_hid+floor((sqrt(input_cell_num)-V1_dim)/2)-1)+y_hid+floor((sqrt(input_cell_num)-V1_dim)/2)) = 1;
        end
    end
end

%% sampling FF conn
N_FF_sampling_w0 = length(find(connection_w0));

if p_sampling < 1
    N_FF_delte_sampling_w0 = round(N_FF_sampling_w0*(1-p_sampling));
else
    N_FF_delte_sampling_w0 = N_FF_sampling_w0-p_sampling;
end

connection_w0 = connection_w0(:);
ind = find(connection_w0);
if length(ind)>=N_FF_delte_sampling_w0
    ind_ind = randperm(length(ind),N_FF_delte_sampling_w0);
    ind = ind(ind_ind);
    
    for ii = 1:length(ind)
        connection_w0(ind(ii)) = 0;
    end
    connection_w0 = reshape(connection_w0, hidden_cell_num,input_cell_num);
    connection_w0_len = connection_w0_len.*connection_w0;
end


% long range connections
if p_long_range > 0
    if p_LS>0
        connection_long_range_hidden1 = zeros(hidden_cell_num, hidden_cell_num);
        connection_long_range_len = zeros(hidden_cell_num, hidden_cell_num);

        V1_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        boolean_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        for hh1=1:hidden_layer_area
            x_hid1 = floor((hh1-1)/V1_dimen)+1; 
            y_hid1 = mod((hh1-1),V1_dimen)+1;
            for hh2=1:hidden_layer_area
                x_hid2 = floor((hh2-1)/V1_dimen)+1;
                y_hid2 = mod((hh2-1),V1_dimen)+1;
                
                distance_hid1_hid2 = sqrt(((x_hid1-x_hid2)^2 + (y_hid1-y_hid2)^2));
                boolean_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = distance_hid1_hid2 > threshold_lrc; 
                V1_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = 1;
                connection_long_range_len...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = distance_hid1_hid2;
            end
            
        end
        boolean_long_range_candidate = boolean_long_range_candidate.*V1_long_range_candidate;
        
        index2_candidate = find(boolean_long_range_candidate);
        if p_long_range <= 1
            num_LRC = round((length(find(connection_w0)))*p_long_range*p_LS); 
        else
            num_LRC = round(p_long_range*p_LS); 
        end

        if length(index2_candidate)>=num_LRC
            temp_index = randperm(length(index2_candidate),num_LRC);
            index2_candidate = index2_candidate(temp_index);

            for ll2 = 1:length(index2_candidate)
                connection_long_range_hidden1(mod((index2_candidate(ll2)-1),hidden_cell_num)+1,floor((index2_candidate(ll2)-1)/hidden_cell_num)+1) = 1;
            end
            
        end

        V1_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        boolean_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        for hh1=1:hidden_layer_area
            x_hid1 = floor((hh1-1)/V1_dimen)+1; 
            y_hid1 = mod((hh1-1),V1_dimen)+1;
            for hh2=1:hidden_layer_area
                x_hid2 = floor((hh2-1)/V1_dimen)+1;
                y_hid2 = mod((hh2-1),V1_dimen)+1;
                
                distance_hid1_hid2 = sqrt(((x_hid1-x_hid2)^2 + (y_hid1-y_hid2)^2));
                boolean_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = (distance_hid1_hid2 < threshold_lrc)&(distance_hid1_hid2 > 0); 
                V1_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = 1;
                connection_long_range_len...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = distance_hid1_hid2;
            end
            
        end
        boolean_long_range_candidate = boolean_long_range_candidate.*V1_long_range_candidate;
        
        index2_candidate = find(boolean_long_range_candidate);
        if p_long_range <= 1
            num_SRC = round((length(find(connection_w0)))*p_long_range*(1-p_LS)); 
        else
            num_SRC = p_long_range-round(p_long_range*p_LS);
        end
        if length(index2_candidate)>=num_SRC
            temp_index = randperm(length(index2_candidate),num_SRC);
            index2_candidate = index2_candidate(temp_index);
            
            for ll2 = 1:length(index2_candidate)
                connection_long_range_hidden1(mod((index2_candidate(ll2)-1),hidden_cell_num)+1,floor((index2_candidate(ll2)-1)/hidden_cell_num)+1) = 1;
            end
        end
        connection_long_range_len = connection_long_range_len.*connection_long_range_hidden1;
    else
        disp('LRC SRC random')
        connection_long_range_hidden1 = zeros(hidden_cell_num, hidden_cell_num);
        connection_long_range_len = zeros(hidden_cell_num, hidden_cell_num);

        V1_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        boolean_long_range_candidate = zeros(hidden_cell_num,hidden_cell_num);
        for hh1=1:hidden_layer_area
            x_hid1 = floor((hh1-1)/V1_dimen)+1; 
            y_hid1 = mod((hh1-1),V1_dimen)+1;
            for hh2=1:hidden_layer_area
                x_hid2 = floor((hh2-1)/V1_dimen)+1;
                y_hid2 = mod((hh2-1),V1_dimen)+1;
                
                distance_hid1_hid2 = sqrt(((x_hid1-x_hid2)^2 + (y_hid1-y_hid2)^2));
                boolean_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = 1; 
                V1_long_range_candidate...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = 1;
                connection_long_range_len...
                    (sqrt(input_cell_num)*(x_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid1+floor((sqrt(input_cell_num)-V1_dimen)/2),...
                    sqrt(input_cell_num)*(x_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2-1))+y_hid2+floor((sqrt(input_cell_num)-V1_dimen)/2)) = distance_hid1_hid2;
            end
            
        end
        boolean_long_range_candidate = boolean_long_range_candidate.*V1_long_range_candidate;
        
        index2_candidate = find(boolean_long_range_candidate);
        
        if p_long_range <= 1
            num_lateral = round((length(find(connection_w0)))*p_long_range); 
        else
            num_lateral = p_long_range-round(p_long_range); 
        end
        if length(index2_candidate)>=num_lateral
            temp_index = randperm(length(index2_candidate),num_lateral);
            index2_candidate = index2_candidate(temp_index);
            
            for ll2 = 1:length(index2_candidate)
                connection_long_range_hidden1(mod((index2_candidate(ll2)-1),hidden_cell_num)+1,floor((index2_candidate(ll2)-1)/hidden_cell_num)+1) = 1;
            end
        end
        
        connection_long_range_len = connection_long_range_len.*connection_long_range_hidden1;
        num_LRC = length(find(connection_long_range_len > threshold_lrc));
        num_SRC = length(find((connection_long_range_len < threshold_lrc)&(connection_long_range_len>0)));
    end
else
    connection_long_range_hidden1= zeros(hidden_cell_num, hidden_cell_num);
    connection_long_range_len = zeros(hidden_cell_num, hidden_cell_num);
    num_LRC = 0;
    num_SRC = 0;
end

%% rewiring normalization 
N_FF = length(find(connection_w0));
if p_long_range > 1
    N_FF_delte = p_long_range; 
else
    N_FF_delte = round(N_FF*p_long_range); 
end

connection_w0 = connection_w0(:);
ind = find(connection_w0);
if length(ind)>=N_FF_delte
    ind_ind = randperm(length(ind),N_FF_delte);
    ind = ind(ind_ind);
    
    for ii = 1:length(ind)
        connection_w0(ind(ii)) = 0;
    end
    connection_w0 = reshape(connection_w0, hidden_cell_num,input_cell_num);
    connection_w0_len = connection_w0_len.*connection_w0;
end

end