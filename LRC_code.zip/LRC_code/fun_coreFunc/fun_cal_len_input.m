function len_MAT = fun_cal_len_input(MAT,thr)

ind_conn = find(abs(MAT)>thr);
len_MAT = zeros(size(MAT,1),size(MAT,2));

for ii = 1:length(ind_conn)
    input_pos = floor((ind_conn(ii)-1)/size(MAT,1))+1;
    input_xpos = floor((input_pos-1)/sqrt(size(MAT,1)))+1;
    input_ypos = mod(input_pos-1,sqrt(size(MAT,1)))+1;
    
    output_pos = mod(ind_conn(ii)-1,size(MAT,1))+1;
    output_xpos = floor((output_pos-1)/sqrt(size(MAT,1)))+1;
    output_ypos = mod(output_pos-1,sqrt(size(MAT,1)))+1;
    
    len_MAT(output_pos, input_pos) = sqrt((output_xpos - input_xpos)^2 + (output_ypos - input_ypos)^2);
end 

end